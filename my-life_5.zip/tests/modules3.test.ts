// Pruebas de la 2.1: migración 4, Feed (fuentes y orden), pendientes, sueldo e inflación, feriados, transporte, alarmas, monedas y Nova.

import { test, before } from 'node:test';
import assert from 'node:assert/strict';
import { setDb, migrate, getDb, SCHEMA_VERSION, MIGRATIONS } from '../src/db/db';
import { openNodeDb } from './nodeDb';
import {
  profilesRepo, feedRepo, feedSourcesRepo, watchlistRepo, salariesRepo, inflationRepo, holidaysRepo, dollarRepo, financeRepo, remindersRepo,
} from '../src/db/repos';
import { defaultSettings, mergeSettings } from '../src/db/defaults';
import { exportProfile, restoreProfile } from '../src/db/backup';
import { rankFeed, feedSummary, timeAgo, compactNumber, filterFeed, kindDef } from '../src/logic/feed';
import { parseAuthorFeed, parseSearchPosts, parseActors, normalizeHandle, postUrl } from '../src/logic/sources/bluesky';
import { parseChannelFeed, channelIdFromHtml, normalizeChannelInput, looksLikeShort } from '../src/logic/sources/youtube';
import { parsePodcastSearch, parsePodcastRss, parseArtistReleases, durationLabel, bigArtwork } from '../src/logic/sources/itunes';
import { parseScoreboard, parseTeams, leagueDef } from '../src/logic/sources/espn';
import { parseStoreSearch, parseAppDetails, parseFeatured, priceItem, formatCents } from '../src/logic/sources/steam';
import { parseGames, releaseItem } from '../src/logic/sources/rawg';
import { parseSearch as parseTmdbSearch, parseDetail, showItems, genreNames } from '../src/logic/sources/tmdb';
import { parseMarkets, parseSearch as parseCoinSearch, formatUsd } from '../src/logic/sources/coingecko';
import { parseInflation, parseHolidays } from '../src/logic/sources/argentinadatos';
import { buildSalaryRows, cumulativeInflation, rateForMonth, salaryVerdict } from '../src/logic/salary';
import { longWeekends, nextHoliday, nextLongWeekend, daysUntil } from '../src/logic/holidays';
import { isTransport, transportSeries, transportBreakdown } from '../src/logic/transport';
import { parseWatchQuery, suggest, suggestionText } from '../src/logic/watchlist';
import { decideAlarm, repeatTriggers, baseId, repeatId, snoozeId, alarmChannelId, LEGACY_ALARM_CHANNEL_IDS } from '../src/logic/alarms';
import { parseCotizaciones, parseArgentinaDatos, formatRate, CASA_LABELS } from '../src/logic/dollar';
import { parseIntent } from '../src/assistant/intents';
import { loadAssistantData, respond } from '../src/assistant/engine';
import type { FeedItem, Profile } from '../src/types';

let A = 0;
let B = 0;
const mk = (name: string) => profilesRepo.create({ name, birthDate: null, age: null, avatarColor: '#8B5CF6', answers: {}, settings: { ...defaultSettings(), modules: { countdown: true, routines: true, dollar: true, subscriptions: true, feed: true, assistant: true, salary: true, holidays: true, transport: true, watchlist: true } }, securityQuestion: 'q' });

before(async () => {
  const db = openNodeDb();
  setDb(db);
  await migrate(db);
  A = await mk('Ana');
  B = await mk('Beto');
});

// ---------- Migración 4 ----------

test('migra una base de la 2.0 (v3) sin perder datos: Descubrir pasa al Feed y el esquema queda en 4', async () => {
  const old = openNodeDb();
  // Esquema de la 2.0 = migraciones 1, 2 y 3 tal cual (nunca se modifican)
  await old.exec('PRAGMA foreign_keys = ON;');
  for (const v of [1, 2, 3]) await old.exec(MIGRATIONS[v]);
  await old.exec('PRAGMA user_version = 3;');
  await old.run("INSERT INTO profiles (name, birth_date, age, avatar_color, answers, settings, security_question, created_at) VALUES ('Viejo', NULL, NULL, '#000', '{}', ?, 'q', '2026-01-01')", [JSON.stringify({ ...defaultSettings(), modules: { countdown: true, routines: true, dollar: true, subscriptions: false, discover: true, assistant: false } })]);
  const pid = (await old.first<{ id: number }>('SELECT id FROM profiles'))!.id;
  await old.run("INSERT INTO discover_items (profile_id, topic, title, summary, url, source, image_url, published_at, saved, hidden, opened, fetched_at) VALUES (?, 'UFC', 'Pelea', 'resumen', 'https://x/1', 'Olé', NULL, '2026-11-01T00:00:00.000Z', 1, 0, 0, '2026-11-01 00:00:00')", [pid]);
  await migrate(old);
  assert.equal((await old.first<{ user_version: number }>('PRAGMA user_version'))?.user_version, SCHEMA_VERSION);
  assert.equal(SCHEMA_VERSION, 4);
  const feed = await old.all<any>('SELECT * FROM feed_items WHERE profile_id = ?', [pid]);
  assert.equal(feed.length, 1);
  assert.equal(feed[0].external_id, 'news:https://x/1');
  assert.equal(feed[0].saved, 1);
  for (const t of ['feed_sources', 'watchlist', 'salaries', 'inflation_rates', 'holidays']) assert.ok(await old.first(`SELECT name FROM sqlite_master WHERE type='table' AND name='${t}'`), t);
  // La configuración vieja ("discover") se entiende como "feed"
  const row = await old.first<{ settings: string }>('SELECT settings FROM profiles WHERE id = ?', [pid]);
  const s = mergeSettings(JSON.parse(row!.settings));
  assert.equal(s.modules.feed, true);
  assert.equal(s.notifications.alarms.reminders.alarm, true);
  assert.deepEqual(s.dollarCasas, defaultSettings().dollarCasas);
  assert.ok(await old.first("SELECT 1 FROM pragma_table_info('profiles') WHERE name = 'last_login_at'"));
});

test('mergeSettings tolera basura y respeta lo guardado', () => {
  const s = mergeSettings({ feed: { tabs: { post: false, crypto: true, nada: true } as any, spoilerFree: true }, dollarCasas: ['eur', 'inventada', 'blue'] as any, notifications: { alarms: { tasks: { alarm: true, sound: 'raro', repeat: 'si' } } } as any, transport: { rechargeDay: 40 } as any });
  assert.equal(s.feed.tabs.post, false);
  assert.equal(s.feed.tabs.crypto, true);
  assert.equal(s.feed.spoilerFree, true);
  assert.deepEqual(s.dollarCasas, ['eur', 'blue']);
  assert.equal(s.notifications.alarms.tasks.alarm, true);
  assert.equal(s.notifications.alarms.tasks.sound, 'chime');
  assert.equal(s.notifications.alarms.tasks.repeat, false);
  assert.equal(s.transport.rechargeDay, null);
});

test('perfiles: última entrada y perfiles activos; sin límite de cantidad', async () => {
  const ids: number[] = [];
  for (let i = 0; i < 25; i++) ids.push(await mk(`Persona ${i}`));
  assert.ok((await profilesRepo.list()).length >= 27);
  await profilesRepo.touch(A);
  const a = await profilesRepo.get(A);
  assert.ok(a?.lastLoginAt);
  const active = await profilesRepo.active(7);
  assert.ok(active.some((p) => p.id === A));
  for (const id of ids) await profilesRepo.remove(id);
});

// ---------- Feed: repos ----------

test('feed: fuentes por perfil, silenciar y quitar', async () => {
  await feedSourcesRepo.add(A, { kind: 'bluesky', externalId: 'pepe.bsky.social', name: 'Pepe' });
  await feedSourcesRepo.add(A, { kind: 'bluesky', externalId: 'pepe.bsky.social', name: 'Pepe Nuevo' });
  await feedSourcesRepo.add(A, { kind: 'team', externalId: '5', name: 'Boca', extra: { leagueId: 'soccer/arg.1' } });
  const mine = await feedSourcesRepo.list(A);
  assert.equal(mine.length, 2, 'no duplica la misma cuenta');
  assert.equal(mine.find((s) => s.kind === 'bluesky')?.name, 'Pepe Nuevo');
  assert.equal((await feedSourcesRepo.list(B)).length, 0, 'otro perfil no ve nada');
  assert.equal(await feedSourcesRepo.has(A, 'team', '5'), true);
  const team = mine.find((s) => s.kind === 'team')!;
  await feedSourcesRepo.setMuted(A, team.id, true);
  assert.equal((await feedSourcesRepo.list(A, 'team'))[0].muted, true);
  await feedSourcesRepo.remove(A, team.id);
  assert.equal((await feedSourcesRepo.list(A, 'team')).length, 0);
});

test('feed: actualizar por id externo conserva guardado y renueva datos', async () => {
  const base = { kind: 'crypto' as const, topic: 'Bitcoin', externalId: 'coin:bitcoin', title: 'Bitcoin (BTC)', publishedAt: '2026-11-05T10:00:00.000Z', extra: { price: 100 } };
  await feedRepo.addMany(A, [base]);
  const it = (await feedRepo.list(A, { kind: 'crypto' }))[0];
  await feedRepo.setFlag(A, it.id, 'saved', true);
  assert.equal(await feedRepo.addMany(A, [{ ...base, extra: { price: 120 }, publishedAt: '2026-11-05T11:00:00.000Z' }]), 0, 'no es nueva');
  const again = (await feedRepo.list(A, { kind: 'crypto' }))[0];
  assert.equal(again.id, it.id);
  assert.equal(again.saved, true);
  assert.equal((again.extra as any).price, 120);
  await feedRepo.hideTopic(A, 'Bitcoin');
  assert.equal((await feedRepo.list(A, { kind: 'crypto' })).length, 1, 'lo guardado no se oculta al silenciar');
  await feedRepo.clearKind(A, 'crypto');
});

// ---------- Feed: orden y resumen ----------

function fi(id: number, kind: FeedItem['kind'], topic: string, hoursAgo: number, extra: Partial<FeedItem> = {}): FeedItem {
  const now = new Date('2026-11-05T20:00:00Z');
  return { id, profileId: A, kind, topic, externalId: `x:${id}`, title: `t${id}`, text: '', url: '', author: topic, authorHandle: '', authorAvatar: null, imageUrl: null, publishedAt: new Date(now.getTime() - hoursAgo * 3600_000).toISOString(), likes: null, extra: {}, spoiler: false, saved: false, hidden: false, opened: false, fetchedAt: '', ...extra };
}

test('feed: orden "Para vos" intercala temas y tipos, y respeta los pesos', () => {
  const now = new Date('2026-11-05T20:00:00Z');
  const items = [fi(1, 'news', 'Cine', 1), fi(2, 'post', 'UFC', 2), fi(3, 'post', 'UFC', 3), fi(4, 'post', 'UFC', 4), fi(5, 'news', 'Cine', 2), fi(6, 'crypto', 'Bitcoin', 0)];
  const ranked = rankFeed(items, { UFC: 5 }, now);
  assert.equal(ranked[0].topic, 'UFC');
  for (let i = 2; i < ranked.length; i++) assert.ok(!(ranked[i].topic === ranked[i - 1].topic && ranked[i].topic === ranked[i - 2].topic && ranked[i].kind === ranked[i - 1].kind && ranked[i].kind === ranked[i - 2].kind), 'no más de 2 seguidas iguales');
  assert.equal(timeAgo(new Date(now.getTime() - 90 * 60000).toISOString(), now), 'hace 2 h');
  assert.equal(timeAgo(new Date(now.getTime() - 26 * 3600_000).toISOString(), now), 'ayer');
  assert.equal(compactNumber(1534), '1,5 mil');
  assert.equal(compactNumber(154000), '154 mil');
  assert.equal(compactNumber(2_300_000), '2,3 M');
  assert.equal(filterFeed(items, 'bitcoin').length, 1);
  assert.equal(kindDef('match').label, 'Deportes');
});

test('feed: resumen de Nova toma lo de las últimas 24 h y oculta spoilers', () => {
  const now = new Date('2026-11-05T20:00:00Z');
  const items = [
    fi(1, 'match', 'Liga Argentina', 3, { title: 'Boca 2 - 1 River', spoiler: true, extra: { status: 'final' } }),
    fi(2, 'news', 'UFC', 5, { title: 'Se confirmó la cartelera del UFC 320' }),
    fi(3, 'crypto', 'Bitcoin', 0, { title: 'Bitcoin (BTC)', extra: { priceText: 'US$ 70.000', change24h: 2.3 } }),
    fi(4, 'video', 'Canal', 40, { title: 'viejo' }),
  ];
  const s = feedSummary(items, {}, { name: 'Nova', spoilerFree: false, now })!;
  assert.ok(s.text.includes('Boca 2 - 1 River'));
  assert.ok(s.text.includes('UFC 320'));
  assert.ok(s.text.includes('70.000'));
  assert.ok(!s.text.includes('viejo'));
  const noSpoil = feedSummary(items, {}, { name: 'Nova', spoilerFree: true, now })!;
  assert.ok(!noSpoil.text.includes('Boca 2 - 1'));
  assert.equal(feedSummary([], {}, { name: 'Nova', spoilerFree: false, now }), null);
});

// ---------- Fuentes: intérpretes ----------

test('bluesky: interpreta posts, salta reposts y arma la URL', () => {
  const post = (uri: string, text: string, extra: any = {}) => ({ post: { uri, author: { handle: 'pepe.bsky.social', displayName: 'Pepe', avatar: 'https://cdn/a.jpg' }, record: { text, createdAt: '2026-11-05T12:00:00.000Z' }, likeCount: 12, repostCount: 3, replyCount: 1, ...extra } });
  const json = { feed: [post('at://did:plc:x/app.bsky.feed.post/abc', 'Hola\nsegunda línea', { embed: { $type: 'app.bsky.embed.images#view', images: [{ thumb: 'https://cdn/t.jpg' }] } }), { ...post('at://did/app.bsky.feed.post/rep', 'repost'), reason: { $type: 'repost' } }, { post: { uri: 'x' } }] };
  const items = parseAuthorFeed(json, 'Pepe');
  assert.equal(items.length, 1);
  assert.equal(items[0].title, 'Hola');
  assert.equal(items[0].authorHandle, '@pepe.bsky.social');
  assert.equal(items[0].imageUrl, 'https://cdn/t.jpg');
  assert.equal(items[0].likes, 12);
  assert.equal(items[0].url, 'https://bsky.app/profile/pepe.bsky.social/post/abc');
  assert.equal(parseSearchPosts({ posts: [post('at://d/app.bsky.feed.post/q', 'tema').post] }, 'UFC').length, 1);
  assert.equal(parseActors({ actors: [{ did: 'd', handle: 'a.bsky.social', displayName: '' }] })[0].displayName, 'a.bsky.social');
  assert.equal(normalizeHandle('@Pepe'), 'pepe.bsky.social');
  assert.equal(normalizeHandle('https://bsky.app/profile/pepe.bsky.social'), 'pepe.bsky.social');
  assert.equal(postUrl('h', 'at://x/y/z'), 'https://bsky.app/profile/h/post/z');
  assert.deepEqual(parseAuthorFeed({ error: 'x' }, 'a'), []);
});

test('youtube: feed Atom, shorts afuera, id del canal desde el HTML', () => {
  const xml = `<feed><title>Canal Pro</title><entry><yt:videoId>abc123</yt:videoId><title>Video uno</title><author><name>Canal Pro</name></author><published>2026-11-04T10:00:00+00:00</published><link rel="alternate" href="https://www.youtube.com/watch?v=abc123"/><media:group><media:thumbnail url="https://i.ytimg.com/vi/abc123/hq.jpg"/><media:description>desc</media:description></media:group></entry><entry><yt:videoId>s1</yt:videoId><title>Corto #shorts</title><link href="https://www.youtube.com/shorts/s1"/></entry></feed>`;
  const items = parseChannelFeed(xml, 'UCxyz');
  assert.equal(items.length, 1);
  assert.equal(items[0].externalId, 'yt:abc123');
  assert.equal(items[0].imageUrl, 'https://i.ytimg.com/vi/abc123/hq.jpg');
  assert.equal(items[0].author, 'Canal Pro');
  assert.equal(looksLikeShort('x #Shorts', ''), true);
  assert.equal(channelIdFromHtml('<html>..."channelId":"UCabcdefghijklmnopqrstuv"...'), 'UCabcdefghijklmnopqrstuv');
  assert.equal(normalizeChannelInput('https://www.youtube.com/@mi.canal'), 'mi.canal');
  assert.equal(normalizeChannelInput('https://youtube.com/channel/UCabcdefghijklmnopqrstuv'), 'UCabcdefghijklmnopqrstuv');
});

test('apple: podcasts (búsqueda y RSS) y lanzamientos de música', () => {
  const hits = parsePodcastSearch({ results: [{ collectionId: 1, collectionName: 'Pod', artistName: 'Autor', feedUrl: 'https://f/rss', artworkUrl100: 'https://a/100x100bb.jpg', primaryGenreName: 'Humor' }, { collectionName: 'sin feed' }] });
  assert.equal(hits.length, 1);
  assert.equal(hits[0].image, 'https://a/600x600bb.jpg');
  const rss = `<rss><channel><title>Pod</title><itunes:image href="https://a/ch.jpg"/><item><title>Ep 1</title><enclosure url="https://f/ep1.mp3" type="audio/mpeg"/><guid>g1</guid><pubDate>Wed, 04 Nov 2026 10:00:00 GMT</pubDate><itunes:duration>45:12</itunes:duration><description><![CDATA[<p>Hola</p>]]></description></item><item><title>Sin audio</title></item></channel></rss>`;
  const eps = parsePodcastRss(rss, { id: '1', name: 'Pod', image: null });
  assert.equal(eps.length, 1);
  assert.equal(eps[0].externalId, 'pod:1:g1');
  assert.equal((eps[0].extra as any).audio, 'https://f/ep1.mp3');
  assert.equal((eps[0].extra as any).duration, '45 min');
  assert.equal(eps[0].authorAvatar, 'https://a/ch.jpg');
  assert.equal(durationLabel('3660'), '1 h 1 min');
  assert.equal(bigArtwork(null), null);
  const rel = parseArtistReleases({ results: [{ wrapperType: 'artist', artistId: 9 }, { wrapperType: 'collection', collectionId: 5, collectionName: 'Disco', artistName: 'Banda', releaseDate: '2026-10-30T00:00:00Z', artworkUrl100: 'https://a/100x100bb.jpg', trackCount: 10, collectionViewUrl: 'https://music/x', primaryGenreName: 'Rock' }] }, { id: '9', name: 'Banda' });
  assert.equal(rel.length, 1);
  assert.equal(rel[0].text, '10 temas · Rock');
  assert.equal((rel[0].extra as any).releaseDate, '2026-10-30');
});

test('espn: scoreboard de fútbol y cartelera de MMA, filtro por equipo y spoilers', () => {
  const league = leagueDef('soccer/arg.1')!;
  const json = { events: [
    { id: 'e1', date: '2026-11-05T22:00Z', name: 'Boca vs River', status: { type: { state: 'post', shortDetail: 'FT' } }, competitions: [{ id: 'c1', competitors: [{ homeAway: 'home', team: { id: '5', displayName: 'Boca', abbreviation: 'BOC', logo: 'https://l/b.png' }, score: '2', winner: true }, { homeAway: 'away', team: { id: '16', displayName: 'River', abbreviation: 'RIV' }, score: '1' }], venue: { fullName: 'La Bombonera' } }] },
    { id: 'e2', date: '2026-11-08T20:00Z', status: { type: { state: 'pre' } }, competitions: [{ id: 'c2', competitors: [{ homeAway: 'home', team: { id: '7', displayName: 'Racing' } }, { homeAway: 'away', team: { id: '8', displayName: 'Lanús' } }] }] },
  ] };
  const all = parseScoreboard(json, league);
  assert.equal(all.length, 2);
  assert.equal(all[0].title, 'Boca 2 - 1 River');
  assert.equal(all[0].spoiler, true);
  assert.equal((all[0].extra as any).home.logo, 'https://l/b.png');
  assert.equal(all[1].spoiler, false);
  assert.equal(all[1].title, 'Racing vs Lanús');
  assert.equal(parseScoreboard(json, league, ['16']).length, 1, 'filtra por equipo');
  const mma = parseScoreboard({ events: [{ id: 'u', name: 'UFC 320', date: '2026-11-07T23:00Z', status: { type: { state: 'pre' } }, competitions: [{ id: 'f1', competitors: [{ athlete: { displayName: 'Peleador A' } }, { athlete: { displayName: 'Peleador B' } }] }, { id: 'f2', competitors: [{ athlete: { displayName: 'C' } }, { athlete: { displayName: 'D' } }] }] }] }, leagueDef('mma/ufc')!);
  assert.equal(mma.length, 2);
  assert.equal(mma[0].text, 'UFC 320');
  assert.equal(parseTeams({ sports: [{ leagues: [{ teams: [{ team: { id: '5', displayName: 'Boca', abbreviation: 'BOC', logos: [{ href: 'https://l/b.png' }] } }] }] }] }, 'soccer/arg.1')[0].logo, 'https://l/b.png');
  assert.deepEqual(parseScoreboard(null, league), []);
});

test('steam y rawg: precios, ofertas y lanzamientos', () => {
  assert.equal(parseStoreSearch({ items: [{ id: 10, name: 'Juego', tiny_image: 'https://i/t.jpg', price: { final: 1234500, currency: 'ARS' } }] })[0].priceText, '$ 12.345');
  const prices = parseAppDetails({ '10': { success: true, data: { price_overview: { currency: 'ARS', initial: 2000000, final: 1000000, discount_percent: 50, final_formatted: 'ARS$ 10.000' } } }, '11': { success: false } });
  assert.equal(prices.length, 1);
  assert.equal(prices[0].discount, 50);
  const it = priceItem({ id: '10', name: 'Juego', image: null }, prices[0], new Date('2026-11-05T12:00:00Z'));
  assert.equal(it.externalId, 'steam:10:sale');
  assert.ok(it.text.includes('50%'));
  assert.equal(formatCents(99900, 'USD'), 'US$ 999');
  assert.equal((parseFeatured({ specials: { items: [{ id: 3, name: 'Oferta', discount_percent: 30, final_price: 700000, original_price: 1000000, currency: 'ARS', header_image: 'https://h/3.jpg' }] } }) as any)[0].name, 'Oferta');
  const games = parseGames({ results: [{ id: 1, name: 'GTA VI', released: '2026-11-19', background_image: 'https://r/g.jpg', genres: [{ name: 'Action' }], platforms: [{ platform: { name: 'PlayStation 5' } }], metacritic: null }] });
  const rel = releaseItem(games[0], 'Lanzamientos', new Date('2026-11-05T12:00:00Z'))!;
  assert.ok(rel.text.startsWith('sale en 14 días'));
  assert.equal((rel.extra as any).rawgId, '1');
});

test('tmdb: búsqueda, detalle de serie con próximo episodio y plataformas, películas', () => {
  const hits = parseTmdbSearch({ results: [{ id: 1, media_type: 'tv', name: 'Serie', first_air_date: '2024-01-01', poster_path: '/p.jpg', genre_ids: [18, 35] }, { id: 2, media_type: 'person', name: 'Actor' }] });
  assert.equal(hits.length, 1);
  assert.equal(hits[0].image, 'https://image.tmdb.org/t/p/w342/p.jpg');
  assert.deepEqual(hits[0].genres, ['Drama', 'Comedia']);
  const det = parseDetail({ id: 1, name: 'Serie', poster_path: '/p.jpg', genres: [{ name: 'Drama' }], status: 'Returning Series', next_episode_to_air: { air_date: '2026-11-12', season_number: 2, episode_number: 3, name: 'El final' }, 'watch/providers': { results: { AR: { flatrate: [{ provider_name: 'Netflix' }] } } } }, 'tv')!;
  assert.deepEqual(det.providers, ['Netflix']);
  const items = showItems(det, '2026-11-05', new Date('2026-11-05T12:00:00Z'));
  assert.equal(items.length, 1);
  assert.ok(items[0].text.includes('T2 E3'));
  assert.ok(items[0].text.includes('sale el 12/11'));
  assert.equal(items[0].spoiler, true, 'el nombre del episodio puede ser spoiler');
  assert.equal(items[0].author, 'Netflix');
  const mov = parseDetail({ id: 7, title: 'Peli', release_date: '2026-12-01' }, 'movie')!;
  assert.ok(showItems(mov, '2026-11-05')[0].text.includes('Estreno el 01/12'));
  assert.deepEqual(genreNames([28, 999]), ['Acción']);
});

test('coingecko: mercados y búsqueda', () => {
  const items = parseMarkets([{ id: 'bitcoin', name: 'Bitcoin', symbol: 'btc', image: 'https://c/b.png', current_price: 70123.4, price_change_percentage_24h: 2.345, price_change_percentage_7d_in_currency: -1.2, sparkline_in_7d: { price: Array.from({ length: 168 }, (_, i) => 60000 + i) } }, { id: 'raro' }], new Date('2026-11-05T12:00:00Z'));
  assert.equal(items.length, 1);
  assert.equal(items[0].externalId, 'coin:bitcoin');
  assert.equal((items[0].extra as any).priceText, 'US$ 70.123');
  assert.equal((items[0].extra as any).spark.length, 42);
  assert.ok(items[0].text.startsWith('Subió 2,3%'));
  assert.equal(formatUsd(0.004567), 'US$ 0,00457');
  assert.equal(parseCoinSearch({ coins: [{ id: 'solana', name: 'Solana', symbol: 'sol', thumb: 'https://c/s.png', market_cap_rank: 5 }] })[0].symbol, 'SOL');
});

test('argentinadatos: inflación y feriados', () => {
  assert.deepEqual(parseInflation([{ fecha: '2026-09-01', valor: 2.1 }, { fecha: 'x' }]), [{ month: '2026-09', value: 2.1 }]);
  const h = parseHolidays([{ fecha: '2026-12-25', tipo: 'inamovible', nombre: 'Navidad' }, { nombre: 'sin fecha' }]);
  assert.equal(h.length, 1);
  assert.equal(h[0].name, 'Navidad');
});

// ---------- Monedas ----------

test('dólar: otras monedas de DolarAPI, histórico forzado y formato', () => {
  const cur = parseCotizaciones([{ moneda: 'USD', casa: 'oficial', compra: 1, venta: 2 }, { moneda: 'EUR', casa: 'oficial', compra: 1725.4, venta: 1739.4, fechaActualizacion: '2026-11-05T15:00:00.000Z' }, { moneda: 'CLP', casa: 'oficial', compra: 1.6014, venta: 1.6014 }]);
  assert.equal(cur.length, 2);
  assert.equal(cur[0].casa, 'eur');
  assert.equal(cur[1].casa, 'clp');
  const hist = parseArgentinaDatos([{ casa: 'oficial', compra: 1700, venta: 1710, fecha: '2026-11-04' }], 'eur', true);
  assert.equal(hist[0].casa, 'eur');
  assert.equal(formatRate(1.6014, 'clp'), '$ 1,60');
  assert.equal(formatRate(1739.4, 'eur'), '$ 1.739,40');
  assert.equal(CASA_LABELS.uyu.long, 'Peso uruguayo');
});

// ---------- Sueldo e inflación ----------

test('sueldo: dólares por mes, inflación acumulada y veredicto', async () => {
  const rates = [
    { casa: 'blue' as const, date: '2026-08-20', buy: 1300, sell: 1320, updatedAt: '' },
    { casa: 'blue' as const, date: '2026-10-15', buy: 1400, sell: 1420, updatedAt: '' },
  ];
  assert.equal(rateForMonth(rates, '2026-08'), 1320);
  assert.equal(rateForMonth(rates, '2026-09'), 1320, 'usa la anterior si el mes no tiene');
  assert.equal(rateForMonth(rates, '2026-11'), 1420);
  const infl = [{ month: '2026-09', value: 2 }, { month: '2026-10', value: 3 }];
  assert.ok(Math.abs(cumulativeInflation(infl, '2026-08', '2026-10')! - 5.06) < 0.01);
  assert.equal(cumulativeInflation(infl, '2026-08', '2026-08'), 0);
  assert.equal(cumulativeInflation(infl, '2026-08', '2027-01'), null, 'con más de un mes sin dato no inventa');
  const rows = buildSalaryRows([{ id: 1, profileId: A, month: '2026-08', amount: 100000000, createdAt: '' }, { id: 2, profileId: A, month: '2026-10', amount: 103000000, createdAt: '' }], rates, infl);
  assert.equal(rows[0].usd, 757.58);
  assert.ok(Math.abs(rows[1].inflationSince! - 5.06) < 0.01);
  assert.ok(rows[1].realAmount! < 100000000);
  assert.ok(salaryVerdict(rows)!.includes('menos que en agosto 26'));
  await salariesRepo.set(A, '2026-11', 120000000);
  await salariesRepo.set(A, '2026-11', 125000000);
  assert.equal((await salariesRepo.list(A)).length, 1);
  assert.equal((await salariesRepo.list(B)).length, 0);
  await assert.rejects(salariesRepo.set(A, 'mal', 1));
  await inflationRepo.upsertMany(infl);
  assert.equal(await inflationRepo.count(), 2);
});

// ---------- Feriados ----------

test('feriados: próximo, findes largos y repo', async () => {
  const hol = [
    { date: '2026-11-20', name: 'Soberanía', type: 'trasladable' }, // viernes
    { date: '2026-11-23', name: 'Puente', type: 'puente' }, // lunes
    { date: '2026-12-08', name: 'Inmaculada', type: 'inamovible' }, // martes
    { date: '2026-12-07', name: 'Puente', type: 'puente' }, // lunes
    { date: '2026-12-25', name: 'Navidad', type: 'inamovible' }, // viernes
  ];
  assert.equal(nextHoliday(hol, '2026-11-05')?.name, 'Soberanía');
  assert.equal(daysUntil('2026-11-20', '2026-11-05'), 15);
  const lws = longWeekends(hol, '2026-11-05', '2026-12-31');
  assert.equal(lws[0].from, '2026-11-20');
  assert.equal(lws[0].to, '2026-11-23');
  assert.equal(lws[0].days, 4);
  assert.equal(lws[1].from, '2026-12-05');
  assert.equal(lws[1].days, 4);
  assert.equal(lws[2].from, '2026-12-25');
  assert.equal(lws[2].days, 3);
  assert.equal(nextLongWeekend(hol, '2026-11-24')?.from, '2026-12-05');
  await holidaysRepo.upsertMany(hol);
  assert.equal((await holidaysRepo.list('2026-12-01', '2026-12-31')).length, 3);
  assert.equal(await holidaysRepo.countYear(2026), 5);
});

// ---------- Transporte ----------

test('transporte: detecta viajes por categoría o nombre y arma la serie', async () => {
  await financeRepo.create(A, { kind: 'expense', name: 'Carga SUBE', emoji: '', category: 'Otros', quantity: 1, unitPrice: null, amount: 500000, date: '2026-11-03', description: '' });
  await financeRepo.create(A, { kind: 'expense', name: 'Viaje', emoji: '', category: 'Transporte', quantity: 1, unitPrice: null, amount: 300000, date: '2026-11-04', description: '' });
  await financeRepo.create(A, { kind: 'expense', name: 'Pizza', emoji: '', category: 'Comida', quantity: 1, unitPrice: null, amount: 900000, date: '2026-11-04', description: '' });
  const txs = await financeRepo.list(A);
  assert.equal(txs.filter(isTransport).length, 2);
  const s = transportSeries(txs, '2026-11', 3);
  assert.equal(s.length, 3);
  assert.equal(s[2].total, 800000);
  assert.equal(s[2].trips, 2);
  const b = transportBreakdown(txs, '2026-11');
  assert.equal(b[0].label, 'SUBE / colectivo');
  assert.equal(b[0].total, 500000);
  await remindersRepo.create(A, { title: 'Recargar la SUBE / transporte', kind: 'payment', date: '2026-11-10', time: '09:00', repeat: 'monthly', amount: null, notes: '' });
});

// ---------- Pendientes y "qué ver" ----------

test('pendientes: repo, sin duplicar por id externo, y sugerencias según gustos', async () => {
  const id1 = await watchlistRepo.create(A, { kind: 'show', title: 'Serie de acción', genres: ['Acción'], externalId: 'tmdb:tv:1' });
  assert.equal(await watchlistRepo.create(A, { kind: 'show', title: 'Otra vez', externalId: 'tmdb:tv:1' }), id1, 'misma serie, mismo registro');
  await watchlistRepo.create(A, { kind: 'movie', title: 'Comedia corta', genres: ['Comedia'] });
  await watchlistRepo.create(A, { kind: 'game', title: 'Juego RPG', genres: ['RPG'], status: 'current' });
  await watchlistRepo.create(A, { kind: 'show', title: 'Terror vista', genres: ['Terror'], status: 'done', rating: 5 });
  await watchlistRepo.create(A, { kind: 'show', title: 'Terror pendiente', genres: ['Terror'] });
  assert.equal((await watchlistRepo.list(B)).length, 0);
  const list = await watchlistRepo.list(A);
  assert.equal(list[0].status, 'current', 'lo en curso primero');
  const q = parseWatchQuery('quiero ver algo de acción, una serie');
  assert.equal(q.kind, 'show');
  assert.deepEqual(q.genres, ['Acción']);
  const s = suggest(list, q, []);
  assert.equal(s[0].item.title, 'Serie de acción');
  assert.ok(suggestionText(s, q).startsWith('Mirá Serie de acción'));
  const q2 = parseWatchQuery('que puedo ver');
  const s2 = suggest(list, q2, []);
  assert.ok(s2.some((x) => x.item.title === 'Terror pendiente'), 'el género bien puntuado pesa');
  const q3 = parseWatchQuery('algo corto');
  assert.equal(suggest(list, q3, [])[0].item.kind === 'movie' || suggest(list, q3, [])[0].item.status === 'current', true);
  assert.ok(suggestionText([], parseWatchQuery('un juego')).includes('juegos'));
  await watchlistRepo.update(A, id1, { status: 'done', rating: 4 });
  assert.equal((await watchlistRepo.get(A, id1))?.rating, 4);
});

// ---------- Alarmas ----------

test('alarmas: decisión por tipo, repeticiones e identificadores', () => {
  const s = defaultSettings().notifications;
  const d = decideAlarm('reminders', s);
  assert.equal(d.alarm, true);
  assert.equal(d.channelId, alarmChannelId('classic'));
  assert.equal(decideAlarm('payments', s).alarm, true);
  assert.equal(decideAlarm('tasks', s).alarm, false);
  assert.equal(decideAlarm('tasks', s).channelId, 'tasks');
  assert.equal(decideAlarm('summary', s).alarm, false);
  assert.equal(alarmChannelId('bell'), 'alarm_v2_bell');
  // Los canales viejos no se reutilizan (Android conserva su configuración vieja).
  assert.ok(!LEGACY_ALARM_CHANNEL_IDS.includes(alarmChannelId('classic')));
  assert.ok(!LEGACY_ALARM_CHANNEL_IDS.includes(alarmChannelId('bell')));
  const reps = repeatTriggers({ kind: 'date', date: new Date('2026-11-05T09:00:00Z') });
  assert.equal(reps.length, 8);
  assert.equal((reps[0] as any).date.toISOString(), '2026-11-05T09:00:35.000Z');
  const daily = repeatTriggers({ kind: 'daily', hour: 23, minute: 59 });
  assert.deepEqual(daily, [{ kind: 'daily', hour: 0, minute: 0 }, { kind: 'daily', hour: 0, minute: 1 }]);
  assert.equal(baseId(repeatId('p1:rem:5', 3)), 'p1:rem:5');
  assert.equal(baseId(snoozeId('p1:rem:5:r2', new Date(5))), 'p1:rem:5');
});

// ---------- Nova ----------

test('nova: entiende las preguntas nuevas y responde con los datos del perfil', async () => {
  const ctx = { today: '2026-11-05' };
  assert.equal(parseIntent('que puedo ver hoy', ctx).type, 'what_to_watch');
  assert.equal(parseIntent('recomendame una serie de accion', ctx).type, 'what_to_watch');
  assert.equal(parseIntent('que hay de nuevo', ctx).type, 'feed');
  assert.equal(parseIntent('cuanto vale mi sueldo', ctx).type, 'salary');
  assert.equal(parseIntent('cuando es el proximo feriado', ctx).type, 'holiday');
  assert.deepEqual(parseIntent('a cuanto esta el euro', ctx), { type: 'dollar', casa: 'eur' });
  assert.equal(parseIntent('que tengo mañana', ctx).type, 'pending');
  const profile = (await profilesRepo.get(A)) as Profile;
  await dollarRepo.upsert({ casa: 'eur', date: '2026-11-05', buy: 1725, sell: 1739.4, updatedAt: new Date().toISOString() });
  const d = await loadAssistantData(profile);
  assert.ok(respond('a cuanto esta el euro', d).text.includes('1.739,40'));
  const w = respond('recomendame algo de terror', d);
  assert.ok(w.text.includes('Terror pendiente'), w.text);
  assert.ok(/feriado/i.test(respond('cuando es el proximo feriado', d).text));
  assert.ok(respond('cuanto vale mi sueldo', d).text.includes('noviembre 26'));
  await feedRepo.addMany(A, [{ kind: 'news', topic: 'UFC', externalId: 'news:https://n/1', title: 'Noticia fresca del UFC', publishedAt: new Date().toISOString() }]);
  const d2 = await loadAssistantData(profile);
  assert.ok(respond('que hay de nuevo', d2).text.includes('Noticia fresca'));
});

// ---------- Copia de seguridad 2.1 ----------

test('copia v4 incluye feed, fuentes, pendientes y sueldos; una copia v3 se restaura y Descubrir pasa al Feed', async () => {
  const bk = await exportProfile(A);
  assert.equal(bk.version, 4);
  assert.ok(bk.tables.feed_items.length >= 1);
  assert.ok(bk.tables.feed_sources.length >= 1);
  assert.ok(bk.tables.watchlist.length >= 1);
  assert.ok(bk.tables.salaries.length >= 1);
  const C = await mk('Copia');
  await restoreProfile(C, bk, { restoreSettings: false });
  assert.equal((await watchlistRepo.list(C)).length, bk.tables.watchlist.length);
  assert.equal((await feedSourcesRepo.list(C)).length, bk.tables.feed_sources.length);
  assert.equal((await salariesRepo.list(C)).length, bk.tables.salaries.length);
  // Copia de la 2.0: sin tablas nuevas y con discover_items
  const old: any = { format: bk.format, version: 3, exportedAt: '', profile: bk.profile, tables: { discover_items: [{ topic: 'Cine', title: 'Vieja', summary: '', url: 'https://v/1', source: '', image_url: null, published_at: '2026-10-01T00:00:00.000Z', saved: 0, hidden: 0, opened: 0, fetched_at: '' }] }, habitLogs: [] };
  await restoreProfile(C, old, { restoreSettings: false });
  const feed = await feedRepo.list(C);
  assert.equal(feed.length, 1);
  assert.equal(feed[0].externalId, 'news:https://v/1');
  await profilesRepo.remove(C);
  const db = getDb();
  for (const t of ['feed_items', 'feed_sources', 'watchlist', 'salaries']) assert.equal((await db.all(`SELECT * FROM ${t} WHERE profile_id = ?`, [C])).length, 0, t);
});
