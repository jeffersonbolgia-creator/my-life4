// Transporte: cuánto se gasta en viajes por mes, a partir de los movimientos de Finanzas.

import type { Transaction } from '../types';
import { addMonthsToKey, monthKey } from '../lib/dates';
import { normalizeText } from '../lib/text';

const WORDS = ['sube', 'colectivo', 'bondi', 'tren', 'subte', 'uber', 'cabify', 'didi', 'taxi', 'remis', 'nafta', 'combustible', 'peaje', 'estacionamiento', 'micro', 'pasaje'];

/** Un movimiento cuenta como transporte si está en la categoría o su nombre lo sugiere. */
export function isTransport(tx: Pick<Transaction, 'kind' | 'category' | 'name'>): boolean {
  if (tx.kind !== 'expense') return false;
  if (normalizeText(tx.category) === 'transporte') return true;
  const n = normalizeText(tx.name);
  return WORDS.some((w) => new RegExp(`\\b${w}\\b`).test(n));
}

export interface TransportMonth { month: string; total: number; trips: number }

export function transportSeries(txs: Transaction[], month: string, months = 6): TransportMonth[] {
  const out: TransportMonth[] = [];
  for (let i = months - 1; i >= 0; i--) {
    const m = addMonthsToKey(month, -i);
    const mine = txs.filter((t) => monthKey(t.date) === m && isTransport(t));
    out.push({ month: m, total: mine.reduce((a, t) => a + t.amount, 0), trips: mine.length });
  }
  return out;
}

/** Desglose por medio (SUBE, nafta, apps...) del mes. */
export function transportBreakdown(txs: Transaction[], month: string): { label: string; total: number }[] {
  const groups: Record<string, string[]> = { 'SUBE / colectivo': ['sube', 'colectivo', 'bondi', 'tren', 'subte', 'micro', 'pasaje'], 'Apps y taxi': ['uber', 'cabify', 'didi', 'taxi', 'remis'], 'Nafta y auto': ['nafta', 'combustible', 'peaje', 'estacionamiento'] };
  const totals = new Map<string, number>();
  for (const t of txs) {
    if (monthKey(t.date) !== month || !isTransport(t)) continue;
    const n = normalizeText(t.name);
    const g = Object.entries(groups).find(([, ws]) => ws.some((w) => new RegExp(`\\b${w}\\b`).test(n)))?.[0] ?? 'Otros viajes';
    totals.set(g, (totals.get(g) ?? 0) + t.amount);
  }
  return [...totals.entries()].map(([label, total]) => ({ label, total })).sort((a, b) => b.total - a.total);
}
