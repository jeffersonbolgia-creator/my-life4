// RAWG (lanzamientos de videojuegos). Necesita clave gratuita: constante RAWG_API_KEY en services/keys.ts.
//  - Próximos:  GET https://api.rawg.io/api/games?key=...&dates=YYYY-MM-DD,YYYY-MM-DD&ordering=-added&page_size=20
//  - Buscar:    GET https://api.rawg.io/api/games?key=...&search={texto}&page_size=10

import type { FeedItemInput } from '../../db/repos';
import { isHttp } from '../xml';

export function upcomingUrl(key: string, from: string, to: string): string {
  return `https://api.rawg.io/api/games?key=${encodeURIComponent(key)}&dates=${from},${to}&ordering=-added&page_size=20`;
}
export function searchUrl(key: string, q: string): string {
  return `https://api.rawg.io/api/games?key=${encodeURIComponent(key)}&search=${encodeURIComponent(q)}&page_size=10&search_precise=true`;
}
export function gameUrl(key: string, id: string): string {
  return `https://api.rawg.io/api/games/${encodeURIComponent(id)}?key=${encodeURIComponent(key)}`;
}

export interface RawgGame { id: string; name: string; released: string | null; image: string | null; genres: string[]; platforms: string[]; metacritic: number | null; tba: boolean }

export function parseGames(json: unknown): RawgGame[] {
  const results = (json as any)?.results;
  if (!Array.isArray(results)) return [];
  return results.filter((g) => g && g.id && g.name).map(parseGame);
}

export function parseGame(g: any): RawgGame {
  return {
    id: String(g.id), name: String(g.name), released: typeof g.released === 'string' ? g.released : null, image: isHttp(g.background_image) ? g.background_image : null,
    genres: Array.isArray(g.genres) ? g.genres.map((x: any) => String(x?.name ?? '')).filter(Boolean) : [],
    platforms: Array.isArray(g.platforms) ? g.platforms.map((x: any) => String(x?.platform?.name ?? '')).filter(Boolean) : [],
    metacritic: typeof g.metacritic === 'number' ? g.metacritic : null, tba: !!g.tba,
  };
}

/** Publicación "sale el X" para un juego. */
export function releaseItem(g: RawgGame, topic: string, now: Date = new Date()): FeedItemInput | null {
  if (!g.released) return null;
  const d = new Date(g.released.replace(/-/g, '/'));
  const days = Math.round((d.getTime() - now.getTime()) / 86400_000);
  const when = days < 0 ? 'ya salió' : days === 0 ? 'sale hoy' : days === 1 ? 'sale mañana' : `sale en ${days} días`;
  return {
    kind: 'game', topic, externalId: `rawg:${g.id}`, title: g.name, text: `${when} (${g.released.slice(8, 10)}/${g.released.slice(5, 7)})${g.platforms.length ? ` · ${g.platforms.slice(0, 3).join(', ')}` : ''}`,
    url: `https://rawg.io/games/${g.id}`, author: g.genres.slice(0, 2).join(' · ') || 'Videojuegos', authorHandle: '', authorAvatar: null, imageUrl: g.image,
    publishedAt: days <= 0 ? d.toISOString() : now.toISOString(), likes: g.metacritic, extra: { rawgId: g.id, release: when, releaseDate: g.released, genres: g.genres, platforms: g.platforms },
  };
}
