// Steam (sin clave): precios en pesos argentinos y ofertas.
//  - Buscar:    GET https://store.steampowered.com/api/storesearch/?term={texto}&cc=ar&l=spanish
//  - Precios:   GET https://store.steampowered.com/api/appdetails?appids=1,2,3&cc=ar&l=spanish&filters=price_overview
//  - Ofertas:   GET https://store.steampowered.com/api/featuredcategories?cc=ar&l=spanish
// Límite aproximado: 200 pedidos cada 5 minutos por IP. El precio regional con cc=ar no se pudo confirmar en vivo.

import type { FeedItemInput } from '../../db/repos';
import { isHttp } from '../xml';

export function storeSearchUrl(term: string): string {
  return `https://store.steampowered.com/api/storesearch/?term=${encodeURIComponent(term)}&cc=ar&l=spanish`;
}
export function appDetailsUrl(appIds: string[]): string {
  return `https://store.steampowered.com/api/appdetails?appids=${appIds.join(',')}&cc=ar&l=spanish&filters=price_overview`;
}
export function featuredUrl(): string {
  return 'https://store.steampowered.com/api/featuredcategories?cc=ar&l=spanish';
}
export function storePageUrl(appId: string): string {
  return `https://store.steampowered.com/app/${appId}/`;
}
export function headerImage(appId: string): string {
  return `https://cdn.cloudflare.steamstatic.com/steam/apps/${appId}/header.jpg`;
}

export interface SteamHit { id: string; name: string; image: string | null; priceText: string | null }
export interface SteamPrice { appId: string; final: number; initial: number; discount: number; currency: string; finalText: string; initialText: string }

export function parseStoreSearch(json: unknown): SteamHit[] {
  const items = (json as any)?.items;
  if (!Array.isArray(items)) return [];
  return items.filter((i) => i && i.id && i.name).map((i) => ({
    id: String(i.id), name: String(i.name), image: isHttp(i.tiny_image) ? i.tiny_image : headerImage(String(i.id)),
    priceText: i.price && typeof i.price.final === 'number' ? formatCents(i.price.final, i.price.currency) : null,
  }));
}

/** Precio en centavos de la moneda indicada → "$ 12.345". */
export function formatCents(cents: number, currency = 'ARS'): string {
  const v = Math.round(cents / 100);
  const body = String(v).replace(/\B(?=(\d{3})+(?!\d))/g, '.');
  return currency === 'USD' ? `US$ ${body}` : `$ ${body}`;
}

/** appdetails: { "123": { success, data: { price_overview: { currency, initial, final, discount_percent, final_formatted } } } }. */
export function parseAppDetails(json: unknown): SteamPrice[] {
  if (!json || typeof json !== 'object') return [];
  const out: SteamPrice[] = [];
  for (const [appId, v] of Object.entries(json as Record<string, any>)) {
    const po = v?.data?.price_overview;
    if (!v?.success || !po || typeof po.final !== 'number') continue;
    const currency = String(po.currency ?? 'ARS');
    out.push({ appId, final: po.final, initial: typeof po.initial === 'number' ? po.initial : po.final, discount: Number(po.discount_percent ?? 0), currency, finalText: String(po.final_formatted ?? formatCents(po.final, currency)), initialText: String(po.initial_formatted ?? formatCents(po.initial ?? po.final, currency)) });
  }
  return out;
}

/** Ofertas destacadas: { specials: { items: [{ id, name, discount_percent, final_price, original_price, currency, header_image }] } }. */
export function parseFeatured(json: unknown): SteamPrice[] & { name?: string }[] {
  const items = (json as any)?.specials?.items;
  if (!Array.isArray(items)) return [];
  return items.filter((i) => i && i.id && i.name && typeof i.final_price === 'number').map((i) => ({
    appId: String(i.id), final: i.final_price, initial: typeof i.original_price === 'number' ? i.original_price : i.final_price, discount: Number(i.discount_percent ?? 0), currency: String(i.currency ?? 'ARS'),
    finalText: formatCents(i.final_price, String(i.currency ?? 'ARS')), initialText: formatCents(i.original_price ?? i.final_price, String(i.currency ?? 'ARS')), name: String(i.name), image: isHttp(i.header_image) ? i.header_image : headerImage(String(i.id)),
  })) as any;
}

/** Publicación del Feed para un juego seguido con su precio (o una oferta destacada). */
export function priceItem(game: { id: string; name: string; image: string | null }, p: SteamPrice, now: Date = new Date()): FeedItemInput {
  const onSale = p.discount > 0;
  return {
    kind: 'game', topic: game.name, externalId: `steam:${game.id}:${onSale ? 'sale' : 'price'}`, title: game.name,
    text: onSale ? `${p.discount}% de descuento · antes ${p.initialText}` : 'Precio actual en Steam', url: storePageUrl(game.id), author: 'Steam', authorHandle: '', authorAvatar: null,
    imageUrl: game.image ?? headerImage(game.id), publishedAt: now.toISOString(), likes: null,
    extra: { appId: game.id, priceText: p.finalText, initialText: p.initialText, discount: p.discount, currency: p.currency, final: p.final },
  };
}
