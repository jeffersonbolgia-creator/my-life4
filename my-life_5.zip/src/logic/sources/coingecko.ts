// CoinGecko (sin clave, con atribución obligatoria "Datos de CoinGecko"). Unas 5 consultas por minuto por IP: se pide todo en una.
//  - Precios:   GET https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&ids=bitcoin,ethereum&price_change_percentage=24h,7d&sparkline=true
//  - Buscar:    GET https://api.coingecko.com/api/v3/search?query={texto}

import type { FeedItemInput } from '../../db/repos';
import { isHttp } from '../xml';

export const DEFAULT_COINS = [
  { id: 'bitcoin', name: 'Bitcoin', symbol: 'BTC' },
  { id: 'ethereum', name: 'Ethereum', symbol: 'ETH' },
];

export function marketsUrl(ids: string[]): string {
  return `https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&ids=${encodeURIComponent(ids.join(','))}&price_change_percentage=24h,7d&sparkline=true&per_page=50`;
}
export function searchUrl(q: string): string {
  return `https://api.coingecko.com/api/v3/search?query=${encodeURIComponent(q)}`;
}

export interface CoinHit { id: string; name: string; symbol: string; image: string | null; rank: number | null }

export function parseSearch(json: unknown): CoinHit[] {
  const coins = (json as any)?.coins;
  if (!Array.isArray(coins)) return [];
  return coins.slice(0, 12).filter((c) => c && c.id && c.name).map((c) => ({ id: String(c.id), name: String(c.name), symbol: String(c.symbol ?? '').toUpperCase(), image: isHttp(c.thumb) ? c.thumb : null, rank: typeof c.market_cap_rank === 'number' ? c.market_cap_rank : null }));
}

export function formatUsd(v: number): string {
  if (v >= 1000) return `US$ ${Math.round(v).toLocaleString('de-DE')}`;
  if (v >= 1) return `US$ ${v.toFixed(2).replace('.', ',')}`;
  return `US$ ${v.toPrecision(3).replace('.', ',')}`;
}

/** Una publicación por moneda con precio, variación y mini serie de 7 días. */
export function parseMarkets(json: unknown, now: Date = new Date()): FeedItemInput[] {
  if (!Array.isArray(json)) return [];
  const out: FeedItemInput[] = [];
  for (const c of json) {
    if (!c || !c.id || typeof c.current_price !== 'number') continue;
    const change = typeof c.price_change_percentage_24h === 'number' ? c.price_change_percentage_24h : null;
    const change7 = typeof c.price_change_percentage_7d_in_currency === 'number' ? c.price_change_percentage_7d_in_currency : null;
    const spark: number[] = Array.isArray(c.sparkline_in_7d?.price) ? c.sparkline_in_7d.price.filter((n: unknown) => typeof n === 'number') : [];
    // 168 puntos (uno por hora): nos quedamos con uno cada 4 h para el gráfico
    const compact = spark.filter((_, i) => i % 4 === 0);
    const symbol = String(c.symbol ?? '').toUpperCase();
    out.push({
      kind: 'crypto', topic: String(c.name), externalId: `coin:${c.id}`, title: `${c.name} (${symbol})`, text: change == null ? '' : `${change > 0 ? 'Subió' : change < 0 ? 'Bajó' : 'Sin cambios'} ${Math.abs(change).toFixed(1).replace('.', ',')}% en 24 h`,
      url: `https://www.coingecko.com/es/monedas/${c.id}`, author: 'CoinGecko', authorHandle: symbol, authorAvatar: isHttp(c.image) ? c.image : null, imageUrl: null, publishedAt: now.toISOString(), likes: null,
      extra: { coinId: c.id, symbol, price: c.current_price, priceText: formatUsd(c.current_price), change24h: change, change7d: change7, spark: compact },
    });
  }
  return out;
}
