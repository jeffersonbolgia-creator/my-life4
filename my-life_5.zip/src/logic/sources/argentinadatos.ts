// ArgentinaDatos (sin clave): inflación mensual oficial y feriados nacionales.
//  - Inflación:  GET https://api.argentinadatos.com/v1/finanzas/indices/inflacion   → [{ fecha: "2024-01-01", valor: 20.6 }]
//  - Feriados:   GET https://api.argentinadatos.com/v1/feriados/{año}               → [{ fecha, tipo, nombre }]

import type { Holiday, InflationRate } from '../../types';

export function inflationUrl(): string {
  return 'https://api.argentinadatos.com/v1/finanzas/indices/inflacion';
}
export function holidaysUrl(year: number): string {
  return `https://api.argentinadatos.com/v1/feriados/${year}`;
}

export function parseInflation(json: unknown): InflationRate[] {
  if (!Array.isArray(json)) return [];
  const out: InflationRate[] = [];
  for (const r of json) {
    const fecha = (r as any)?.fecha;
    const valor = Number((r as any)?.valor);
    if (typeof fecha !== 'string' || !/^\d{4}-\d{2}/.test(fecha) || !Number.isFinite(valor)) continue;
    out.push({ month: fecha.slice(0, 7), value: valor });
  }
  return out;
}

export function parseHolidays(json: unknown): Holiday[] {
  if (!Array.isArray(json)) return [];
  const out: Holiday[] = [];
  for (const r of json) {
    const fecha = (r as any)?.fecha;
    const nombre = (r as any)?.nombre;
    if (typeof fecha !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(fecha) || typeof nombre !== 'string') continue;
    out.push({ date: fecha, name: nombre.trim(), type: String((r as any)?.tipo ?? '').trim() });
  }
  return out;
}
