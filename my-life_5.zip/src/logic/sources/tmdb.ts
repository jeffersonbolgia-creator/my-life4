// TMDB (series y películas). Necesita clave gratuita, uso no comercial, con atribución: constante TMDB_API_KEY en services/keys.ts.
//  - Buscar:         GET https://api.themoviedb.org/3/search/multi?api_key=...&query={texto}&language=es-AR&include_adult=false
//  - Serie:          GET https://api.themoviedb.org/3/tv/{id}?api_key=...&language=es-AR&append_to_response=watch/providers
//  - Película:       GET https://api.themoviedb.org/3/movie/{id}?api_key=...&language=es-AR&append_to_response=watch/providers
//  - Estrenos cine:  GET https://api.themoviedb.org/3/movie/upcoming?api_key=...&language=es-AR&region=AR
//  - Series al aire: GET https://api.themoviedb.org/3/tv/on_the_air?api_key=...&language=es-AR

import type { FeedItemInput } from '../../db/repos';
import { isHttp } from '../xml';

const BASE = 'https://api.themoviedb.org/3';

export function searchUrl(key: string, q: string): string {
  return `${BASE}/search/multi?api_key=${encodeURIComponent(key)}&query=${encodeURIComponent(q)}&language=es-AR&include_adult=false`;
}
export function detailUrl(key: string, type: 'tv' | 'movie', id: string): string {
  return `${BASE}/${type}/${encodeURIComponent(id)}?api_key=${encodeURIComponent(key)}&language=es-AR&append_to_response=watch/providers`;
}
export function upcomingMoviesUrl(key: string): string {
  return `${BASE}/movie/upcoming?api_key=${encodeURIComponent(key)}&language=es-AR&region=AR`;
}
export function onTheAirUrl(key: string): string {
  return `${BASE}/tv/on_the_air?api_key=${encodeURIComponent(key)}&language=es-AR`;
}
export function poster(path: unknown): string | null {
  return typeof path === 'string' && path.startsWith('/') ? `https://image.tmdb.org/t/p/w342${path}` : null;
}
export function pageUrl(type: 'tv' | 'movie', id: string): string {
  return `https://www.themoviedb.org/${type}/${id}`;
}

const GENRES: Record<number, string> = {
  28: 'Acción', 12: 'Aventura', 16: 'Animación', 35: 'Comedia', 80: 'Crimen', 99: 'Documental', 18: 'Drama', 10751: 'Familia', 14: 'Fantasía', 36: 'Historia', 27: 'Terror',
  10402: 'Música', 9648: 'Misterio', 10749: 'Romance', 878: 'Ciencia ficción', 53: 'Suspenso', 10752: 'Bélica', 37: 'Western', 10759: 'Acción y aventura', 10762: 'Infantil',
  10763: 'Noticias', 10764: 'Reality', 10765: 'Ciencia ficción y fantasía', 10766: 'Telenovela', 10767: 'Entrevistas', 10768: 'Guerra y política',
};

export function genreNames(ids: unknown): string[] {
  return Array.isArray(ids) ? ids.map((i) => GENRES[Number(i)]).filter((x): x is string => !!x) : [];
}

export interface TmdbHit { id: string; type: 'tv' | 'movie'; title: string; date: string | null; image: string | null; genres: string[]; overview: string }

export function parseSearch(json: unknown): TmdbHit[] {
  const results = (json as any)?.results;
  if (!Array.isArray(results)) return [];
  return results
    .filter((r) => r && r.id && (r.media_type === 'tv' || r.media_type === 'movie') && (r.name || r.title))
    .map((r) => ({
      id: String(r.id), type: r.media_type, title: String(r.name ?? r.title), date: typeof (r.first_air_date ?? r.release_date) === 'string' ? (r.first_air_date ?? r.release_date) : null,
      image: poster(r.poster_path), genres: Array.isArray(r.genres) ? r.genres.map((g: any) => String(g?.name ?? '')).filter(Boolean) : genreNames(r.genre_ids), overview: typeof r.overview === 'string' ? r.overview.slice(0, 300) : '',
    }));
}

export interface TmdbDetail {
  id: string; type: 'tv' | 'movie'; title: string; image: string | null; genres: string[]; status: string; overview: string;
  nextEpisode: { date: string; season: number; episode: number; name: string } | null;
  lastEpisode: { date: string; season: number; episode: number; name: string } | null;
  releaseDate: string | null;
  providers: string[];
}

export function parseDetail(json: unknown, type: 'tv' | 'movie'): TmdbDetail | null {
  const d: any = json;
  if (!d || typeof d !== 'object' || !d.id) return null;
  const ep = (e: any) => (e && typeof e.air_date === 'string' ? { date: e.air_date, season: Number(e.season_number ?? 0), episode: Number(e.episode_number ?? 0), name: String(e.name ?? '') } : null);
  const ar = d['watch/providers']?.results?.AR;
  const providers: string[] = [];
  for (const k of ['flatrate', 'free', 'ads']) for (const p of Array.isArray(ar?.[k]) ? ar[k] : []) if (p?.provider_name && !providers.includes(p.provider_name)) providers.push(String(p.provider_name));
  return {
    id: String(d.id), type, title: String(d.name ?? d.title ?? ''), image: poster(d.poster_path), genres: Array.isArray(d.genres) ? d.genres.map((g: any) => String(g?.name ?? '')).filter(Boolean) : [],
    status: String(d.status ?? ''), overview: typeof d.overview === 'string' ? d.overview.slice(0, 400) : '', nextEpisode: ep(d.next_episode_to_air), lastEpisode: ep(d.last_episode_to_air),
    releaseDate: typeof d.release_date === 'string' ? d.release_date : typeof d.first_air_date === 'string' ? d.first_air_date : null, providers,
  };
}

const fmt = (iso: string) => `${iso.slice(8, 10)}/${iso.slice(5, 7)}`;

/** Publicaciones para una serie/película seguida: próximo episodio, último episodio o estreno. */
export function showItems(det: TmdbDetail, today: string, now: Date = new Date()): FeedItemInput[] {
  const out: FeedItemInput[] = [];
  const base = { kind: 'show' as const, topic: det.title, author: det.providers.length ? det.providers.slice(0, 2).join(' · ') : det.type === 'tv' ? 'Serie' : 'Película', authorHandle: '', authorAvatar: null, imageUrl: det.image, likes: null, url: pageUrl(det.type, det.id) };
  if (det.type === 'tv') {
    if (det.nextEpisode) {
      const n = det.nextEpisode;
      const label = `T${n.season} E${n.episode}`;
      out.push({ ...base, externalId: `tmdb:tv:${det.id}:next:${n.date}`, title: det.title, text: `${label}${n.name ? ` · ${n.name}` : ''} · ${n.date >= today ? `sale el ${fmt(n.date)}` : `salió el ${fmt(n.date)}`}`, publishedAt: n.date >= today ? now.toISOString() : `${n.date}T12:00:00.000Z`, extra: { tmdbId: det.id, type: 'tv', episode: label, episodeDate: n.date, providers: det.providers, genres: det.genres }, spoiler: !!n.name });
    } else if (det.lastEpisode) {
      const l = det.lastEpisode;
      const label = `T${l.season} E${l.episode}`;
      out.push({ ...base, externalId: `tmdb:tv:${det.id}:last:${l.date}`, title: det.title, text: `Último episodio: ${label}${l.name ? ` · ${l.name}` : ''} (${fmt(l.date)})${det.status === 'Ended' ? ' · Serie terminada' : ''}`, publishedAt: `${l.date}T12:00:00.000Z`, extra: { tmdbId: det.id, type: 'tv', episode: label, episodeDate: l.date, providers: det.providers, genres: det.genres }, spoiler: !!l.name });
    }
  } else if (det.releaseDate) {
    const r = det.releaseDate;
    out.push({ ...base, externalId: `tmdb:movie:${det.id}:${r}`, title: det.title, text: r >= today ? `Estreno el ${fmt(r)}` : `${det.providers.length ? `Disponible en ${det.providers.slice(0, 2).join(', ')}` : `Estrenada el ${fmt(r)}`}`, publishedAt: r >= today ? now.toISOString() : `${r}T12:00:00.000Z`, extra: { tmdbId: det.id, type: 'movie', releaseDate: r, providers: det.providers, genres: det.genres }, spoiler: false });
  }
  return out;
}

/** Estrenos generales (sin seguir nada): upcoming de cine y series al aire. */
export function listItems(json: unknown, type: 'tv' | 'movie', topic: string, now: Date = new Date()): FeedItemInput[] {
  return parseSearch({ results: (((json as any)?.results ?? []) as any[]).map((r) => ({ ...r, media_type: type })) }).slice(0, 12).map((h) => ({
    kind: 'show', topic, externalId: `tmdb:${type}:${h.id}:list`, title: h.title, text: `${h.date ? (type === 'movie' ? 'Estreno ' : 'En emisión · ') + fmt(h.date) : ''}${h.genres.length ? ` · ${h.genres.slice(0, 2).join(', ')}` : ''}`.replace(/^ · /, ''),
    url: pageUrl(type, h.id), author: type === 'tv' ? 'Serie' : 'Película', authorHandle: '', authorAvatar: null, imageUrl: h.image, publishedAt: now.toISOString(), likes: null,
    extra: { tmdbId: h.id, type, releaseDate: h.date, genres: h.genres },
  }));
}
