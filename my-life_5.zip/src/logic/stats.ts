import type { Goal, Habit, Task, Transaction } from '../types';
import { addDays, startOfMonth, startOfWeek, endOfMonth, weekday } from '../lib/dates';
import { completionRate } from './habits';
import { sumBy } from './finance';

export type Period = 'day' | 'week' | 'month';

export function periodRange(period: Period, today: string): { from: string; to: string } {
  if (period === 'day') return { from: today, to: today };
  if (period === 'week') {
    const from = startOfWeek(today);
    return { from, to: addDays(from, 6) };
  }
  return { from: startOfMonth(today), to: endOfMonth(today) };
}

export function previousRange(period: Period, today: string): { from: string; to: string } {
  if (period === 'day') return periodRange('day', addDays(today, -1));
  if (period === 'week') return periodRange('week', addDays(startOfWeek(today), -1));
  return periodRange('month', addDays(startOfMonth(today), -1));
}

export interface PeriodStats {
  from: string;
  to: string;
  tasksCompleted: number;
  tasksDue: number;
  tasksOverdue: number;
  habitRate: number; // 0..100
  habitChecks: number;
  goalsAchieved: number;
  income: number;
  expense: number;
}

export function computePeriodStats(
  range: { from: string; to: string },
  today: string,
  data: { tasks: Task[]; habits: Habit[]; habitLogs: Map<number, Set<string>>; goals: Goal[]; txs: Transaction[] },
): PeriodStats {
  const { from, to } = range;
  const inRange = (d: string | null | undefined) => !!d && d.slice(0, 10) >= from && d.slice(0, 10) <= to;
  const tasksCompleted = data.tasks.filter((t) => inRange(t.completedAt)).length;
  const tasksDue = data.tasks.filter((t) => inRange(t.dueDate)).length;
  const tasksOverdue = data.tasks.filter((t) => !t.completedAt && t.dueDate && t.dueDate < today).length;
  const effectiveTo = to > today ? today : to;
  const active = data.habits.filter((h) => !h.archived);
  let rateSum = 0;
  let rateCount = 0;
  let habitChecks = 0;
  for (const h of active) {
    const logs = data.habitLogs.get(h.id) ?? new Set<string>();
    if (h.createdAt.slice(0, 10) <= effectiveTo) {
      rateSum += completionRate(h, logs, from, effectiveTo);
      rateCount++;
    }
    for (const d of logs) if (d >= from && d <= to) habitChecks++;
  }
  const goalsAchieved = data.goals.filter((g) => inRange(g.completedAt)).length;
  const txs = data.txs.filter((t) => t.date >= from && t.date <= to);
  return {
    from,
    to,
    tasksCompleted,
    tasksDue,
    tasksOverdue,
    habitRate: rateCount ? Math.round(rateSum / rateCount) : 0,
    habitChecks,
    goalsAchieved,
    income: sumBy(txs, 'income'),
    expense: sumBy(txs, 'expense'),
  };
}

/** Tareas completadas por día en los últimos N días (para gráficos). */
export function completedPerDay(tasks: Task[], today: string, days: number): { date: string; count: number }[] {
  const out: { date: string; count: number }[] = [];
  for (let i = days - 1; i >= 0; i--) {
    const d = addDays(today, -i);
    out.push({ date: d, count: tasks.filter((t) => t.completedAt && t.completedAt.slice(0, 10) === d).length });
  }
  return out;
}

/** Porcentaje de hábitos cumplidos por día (últimos N días). */
export function habitRatePerDay(habits: Habit[], logs: Map<number, Set<string>>, today: string, days: number): { date: string; rate: number }[] {
  const out: { date: string; rate: number }[] = [];
  for (let i = days - 1; i >= 0; i--) {
    const d = addDays(today, -i);
    let sched = 0;
    let done = 0;
    for (const h of habits) {
      if (h.archived || h.frequency !== 'daily') continue;
      if (h.createdAt.slice(0, 10) > d) continue;
      if (h.weekdays.length && !h.weekdays.includes(weekday(d))) continue;
      sched++;
      if (logs.get(h.id)?.has(d)) done++;
    }
    out.push({ date: d, rate: sched ? Math.round((done / sched) * 100) : 0 });
  }
  return out;
}
