// Sueldo e inflación: cuánto vale el sueldo de cada mes en dólares y cuánto poder de compra perdió.
// Sin red (testeable). Inflación y dólar vienen de la base (ArgentinaDatos y DolarAPI).

import type { DollarRate, InflationRate, Salary } from '../types';
import { addMonthsToKey, monthKey } from '../lib/dates';

export interface SalaryRow {
  month: string; // YYYY-MM
  amount: number; // centavos
  usd: number | null; // dólares (número, 2 decimales) a la cotización del mes
  rateUsed: number | null;
  /** Inflación acumulada desde el primer sueldo cargado hasta este mes (%). */
  inflationSince: number | null;
  /** Lo que el sueldo "vale" en pesos del primer mes (centavos). */
  realAmount: number | null;
  /** Variación nominal contra el mes anterior cargado (%). */
  nominalChange: number | null;
  /** Variación real (descontando inflación) contra el mes anterior cargado (%). */
  realChange: number | null;
}

/** Cotización (venta) representativa de un mes: la última disponible dentro del mes; si no hay, la más cercana anterior; si no, la última de todas. */
export function rateForMonth(rates: DollarRate[], month: string): number | null {
  const mine = [...rates].sort((a, b) => a.date.localeCompare(b.date));
  if (!mine.length) return null;
  const inMonth = mine.filter((r) => r.date.slice(0, 7) === month);
  if (inMonth.length) return inMonth[inMonth.length - 1].sell;
  const before = mine.filter((r) => r.date.slice(0, 7) < month);
  if (before.length) return before[before.length - 1].sell;
  return mine[mine.length - 1].sell;
}

/** Índice acumulado: multiplica (1 + inflación/100) de cada mes entre `from` (exclusive) y `to` (inclusive). */
export function cumulativeInflation(infl: InflationRate[], from: string, to: string): number | null {
  if (from >= to) return 0;
  const map = new Map(infl.map((i) => [i.month, i.value]));
  let idx = 1;
  let m = addMonthsToKey(from, 1);
  let missing = 0;
  while (m <= to) {
    const v = map.get(m);
    if (v == null) missing++;
    else idx *= 1 + v / 100;
    m = addMonthsToKey(m, 1);
  }
  // Si falta más de un mes de datos (el último suele publicarse con demora), no inventamos.
  if (missing > 1) return null;
  return (idx - 1) * 100;
}

export function buildSalaryRows(salaries: Salary[], rates: DollarRate[], infl: InflationRate[]): SalaryRow[] {
  const sorted = [...salaries].sort((a, b) => a.month.localeCompare(b.month));
  if (!sorted.length) return [];
  const base = sorted[0];
  const rows: SalaryRow[] = [];
  let prev: SalaryRow | null = null;
  for (const s of sorted) {
    const rate = rateForMonth(rates, s.month);
    const inflSince = cumulativeInflation(infl, base.month, s.month);
    const realAmount = inflSince == null ? null : Math.round(s.amount / (1 + inflSince / 100));
    const nominalChange = prev ? ((s.amount - prev.amount) / prev.amount) * 100 : null;
    const realChange = prev && prev.realAmount != null && realAmount != null ? ((realAmount - prev.realAmount) / prev.realAmount) * 100 : null;
    const row: SalaryRow = { month: s.month, amount: s.amount, usd: rate ? Math.round((s.amount / 100 / rate) * 100) / 100 : null, rateUsed: rate, inflationSince: inflSince, realAmount, nominalChange, realChange };
    rows.push(row);
    prev = row;
  }
  return rows;
}

/** Frase corta para la tarjeta: "Tu sueldo vale 4% menos que en marzo" o "Le ganaste 2% a la inflación". */
export function salaryVerdict(rows: SalaryRow[]): string | null {
  if (rows.length < 2) return null;
  const last = rows[rows.length - 1];
  if (last.realAmount == null || last.inflationSince == null) return 'Faltan datos de inflación para comparar.';
  const first = rows[0];
  const diff = ((last.realAmount - first.amount) / first.amount) * 100;
  const from = monthLabel(first.month);
  if (Math.abs(diff) < 0.5) return `Tu sueldo vale lo mismo que en ${from}.`;
  return diff < 0 ? `Tu sueldo compra ${Math.abs(diff).toFixed(1).replace('.', ',')}% menos que en ${from}.` : `Le ganaste ${diff.toFixed(1).replace('.', ',')}% a la inflación desde ${from}.`;
}

const MONTHS = ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'];
export function monthLabel(month: string): string {
  const m = Number(month.slice(5, 7));
  return `${MONTHS[m - 1] ?? month} ${month.slice(2, 4)}`;
}

export function currentMonth(now: Date = new Date()): string {
  return monthKey(`${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-01`);
}
