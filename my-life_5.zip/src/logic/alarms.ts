// Alarmas: qué tipos de aviso suenan como alarma, con qué canal y cómo se repiten.
// Sin efectos (testeable). La programación real está en notifications/notifications.ts.

import type { AlarmPrefs, AlarmSound, AlarmType, NotificationSettings } from '../types';
import type { ChannelId, PlannedTrigger } from './notificationPlan';

export const ALARM_SOUND_LABELS: Record<AlarmSound, string> = { classic: 'Clásica', soft: 'Suave', chime: 'Campanitas', bell: 'Campana' };

/** Archivo de sonido (en assets/sounds, copiado a res/raw por el plugin de expo-notifications). */
export const ALARM_SOUND_FILES: Record<AlarmSound, string> = { classic: 'alarm.wav', soft: 'alarm_soft.wav', chime: 'alarm_chime.wav', bell: 'alarm_bell.wav' };

/**
 * Los canales de Android no se pueden cambiar una vez creados (ni el sonido, ni la importancia,
 * ni el uso de audio "alarma"): un canal por sonido, y con versión. Si una instalación anterior
 * dejó un canal con el sonido por defecto o sin el archivo, subir la versión crea canales nuevos.
 */
export const ALARM_CHANNEL_VERSION = 2;
export function alarmChannelId(sound: AlarmSound): string {
  return `alarm_v${ALARM_CHANNEL_VERSION}_${sound}`;
}

/** Canales de versiones anteriores: se borran al iniciar para que no queden duplicados en Ajustes. */
export const LEGACY_ALARM_CHANNEL_IDS = ['reminders_alarm', 'alarm_soft', 'alarm_chime', 'alarm_bell'];

export const ALARM_TYPE_LABELS: Record<AlarmType, { label: string; hint: string; icon: string }> = {
  reminders: { label: 'Recordatorios y pagos', hint: 'Lo que cargás en Recordatorios', icon: 'BellRing' },
  tasks: { label: 'Tareas', hint: 'Tareas con fecha y aviso', icon: 'CircleCheck' },
  events: { label: 'Eventos y cumpleaños', hint: 'Avisos del calendario', icon: 'CalendarDays' },
  subscriptions: { label: 'Suscripciones', hint: 'Antes de cada cobro', icon: 'Repeat2' },
  routines: { label: 'Rutinas', hint: 'A la hora de empezar', icon: 'Sunrise' },
};

/** A qué tipo de alarma corresponde cada canal de aviso (null = nunca es alarma: resumen, dólar, etc.). */
export function alarmTypeForChannel(channel: ChannelId): AlarmType | null {
  switch (channel) {
    case 'reminders':
    case 'payments': return 'reminders';
    case 'tasks': return 'tasks';
    case 'events': return 'events';
    case 'subscriptions': return 'subscriptions';
    case 'routines': return 'routines';
    default: return null;
  }
}

export interface AlarmDecision {
  channelId: string;
  alarm: boolean;
  prefs: AlarmPrefs | null;
}

export function decideAlarm(channel: ChannelId, settings: NotificationSettings): AlarmDecision {
  const type = alarmTypeForChannel(channel);
  const prefs = type ? settings.alarms[type] : null;
  if (!prefs || !prefs.alarm) return { channelId: channel, alarm: false, prefs };
  return { channelId: alarmChannelId(prefs.sound), alarm: true, prefs };
}

/** Segundos entre repeticiones (el sonido dura ~30 s) y cuántas como máximo (5 minutos en total). */
export const REPEAT_EVERY_SECONDS = 35;
export const MAX_REPEATS = 8;

/**
 * Disparos extra para que la alarma se repita hasta que la apaguen.
 *  - Avisos únicos (fecha): hasta 8 repeticiones cada 35 s.
 *  - Avisos diarios/semanales: 2 repeticiones, a +1 y +2 minutos (Android sólo permite hora y minuto en esos casos).
 */
export function repeatTriggers(trigger: PlannedTrigger): PlannedTrigger[] {
  if (trigger.kind === 'date') {
    const out: PlannedTrigger[] = [];
    for (let k = 1; k <= MAX_REPEATS; k++) out.push({ kind: 'date', date: new Date(trigger.date.getTime() + k * REPEAT_EVERY_SECONDS * 1000) });
    return out;
  }
  const out: PlannedTrigger[] = [];
  for (let k = 1; k <= 2; k++) {
    const total = trigger.hour * 60 + trigger.minute + k;
    const hour = Math.floor(total / 60) % 24;
    const minute = total % 60;
    out.push(trigger.kind === 'daily' ? { kind: 'daily', hour, minute } : { kind: 'weekly', weekday: trigger.weekday, hour, minute });
  }
  return out;
}

/** Identificador de una repetición: "<id>:r<k>". El id base se recupera con baseId(). */
export function repeatId(id: string, k: number): string {
  return `${id}:r${k}`;
}
export function baseId(id: string): string {
  return id.replace(/:r\d+$/, '').replace(/:snooze:\d+$/, '');
}
export function snoozeId(id: string, now: Date = new Date()): string {
  return `${baseId(id)}:snooze:${now.getTime()}`;
}
export const SNOOZE_MINUTES = 10;
