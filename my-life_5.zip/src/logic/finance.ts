import type { Transaction } from '../types';
import { addMonthsToKey, monthKey } from '../lib/dates';

export interface MonthSummary {
  month: string;
  income: number;
  expense: number;
  net: number;
}

export interface CategoryTotal {
  category: string;
  total: number;
  percent: number;
  count: number;
}

export function sumBy(txs: Transaction[], kind: 'income' | 'expense'): number {
  let s = 0;
  for (const t of txs) if (t.kind === kind) s += t.amount;
  return s;
}

export function monthSummary(txs: Transaction[], month: string): MonthSummary {
  const inMonth = txs.filter((t) => monthKey(t.date) === month);
  const income = sumBy(inMonth, 'income');
  const expense = sumBy(inMonth, 'expense');
  return { month, income, expense, net: income - expense };
}

/**
 * Saldo disponible = saldo inicial + ingresos - gastos.
 * Si el saldo inicial tiene fecha, solo se cuentan los movimientos desde esa fecha.
 */
export function availableBalance(
  txs: Transaction[],
  initialBalance: number,
  initialDate: string | null,
  upTo?: string,
): number {
  let bal = initialBalance;
  for (const t of txs) {
    if (initialDate && t.date < initialDate) continue;
    if (upTo && t.date > upTo) continue;
    bal += t.kind === 'income' ? t.amount : -t.amount;
  }
  return bal;
}

export function categoryBreakdown(txs: Transaction[], month: string | null, kind: 'income' | 'expense' = 'expense'): CategoryTotal[] {
  const map = new Map<string, { total: number; count: number }>();
  let total = 0;
  for (const t of txs) {
    if (t.kind !== kind) continue;
    if (month && monthKey(t.date) !== month) continue;
    const key = t.category || 'Otros';
    const cur = map.get(key) ?? { total: 0, count: 0 };
    cur.total += t.amount;
    cur.count += 1;
    map.set(key, cur);
    total += t.amount;
  }
  return [...map.entries()]
    .map(([category, v]) => ({
      category,
      total: v.total,
      count: v.count,
      percent: total ? Math.round((v.total / total) * 1000) / 10 : 0,
    }))
    .sort((a, b) => b.total - a.total);
}

/** Serie de los últimos N meses terminando en endMonth (inclusive). */
export function monthlySeries(txs: Transaction[], endMonth: string, count: number): MonthSummary[] {
  const out: MonthSummary[] = [];
  for (let i = count - 1; i >= 0; i--) out.push(monthSummary(txs, addMonthsToKey(endMonth, -i)));
  return out;
}

/** Variación porcentual respecto del mes anterior (null si no hay base de comparación). */
export function percentChange(current: number, previous: number): number | null {
  if (!previous) return null;
  return Math.round(((current - previous) / previous) * 1000) / 10;
}

export function dailyAverageExpense(txs: Transaction[], month: string, today: string): number {
  const s = monthSummary(txs, month);
  const isCurrent = monthKey(today) === month;
  const [y, m] = month.split('-').map(Number);
  const days = isCurrent ? Number(today.slice(8, 10)) : new Date(y, m, 0).getDate();
  return days ? Math.round(s.expense / days) : 0;
}

export const EXPENSE_CATEGORIES = [
  'Comida', 'Supermercado', 'Transporte', 'Salidas', 'Hogar', 'Servicios', 'Salud',
  'Educación', 'Ropa', 'Tecnología', 'Deporte', 'Regalos', 'Suscripciones', 'Otros',
];

export const INCOME_CATEGORIES = ['Sueldo', 'Changas', 'Ventas', 'Regalo', 'Beca', 'Mesada', 'Inversiones', 'Otros'];
