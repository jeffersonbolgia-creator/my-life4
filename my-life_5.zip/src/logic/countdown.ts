// Cálculos de cuentas regresivas (sin efectos secundarios).

import type { Countdown } from '../types';
import { combineDateTime, diffDays, toISODate } from '../lib/dates';

export interface Remaining {
  /** Milisegundos hasta el momento objetivo (negativo si ya pasó). */
  ms: number;
  days: number;
  hours: number;
  minutes: number;
  seconds: number;
  past: boolean;
  /** true si es hoy (y todavía no pasó la hora, o es todo el día). */
  today: boolean;
}

/** Tiempo que falta para una cuenta regresiva. Para "todo el día" cuenta hasta las 00:00 de ese día. */
export function remaining(c: Pick<Countdown, 'date' | 'time'>, now: Date = new Date()): Remaining {
  const target = combineDateTime(c.date, c.time);
  if (!c.time) target.setHours(0, 0, 0, 0);
  const ms = target.getTime() - now.getTime();
  const todayISO = toISODate(now);
  const isToday = c.date === todayISO;
  if (!c.time && isToday) return { ms: 0, days: 0, hours: 0, minutes: 0, seconds: 0, past: false, today: true };
  const abs = Math.abs(ms);
  const days = Math.floor(abs / 86400000);
  const hours = Math.floor((abs % 86400000) / 3600000);
  const minutes = Math.floor((abs % 3600000) / 60000);
  const seconds = Math.floor((abs % 60000) / 1000);
  return { ms, days, hours, minutes, seconds, past: ms < 0, today: isToday && ms >= 0 };
}

/** Días calendario que faltan (0 = hoy, negativo = ya pasó). */
export function daysLeft(c: Pick<Countdown, 'date'>, now: Date = new Date()): number {
  return diffDays(c.date, toISODate(now));
}

/** "Faltan 12 días", "Es hoy", "Mañana", "Pasó hace 3 días". */
export function daysLabel(c: Pick<Countdown, 'date'>, now: Date = new Date()): string {
  const d = daysLeft(c, now);
  if (d === 0) return 'Es hoy';
  if (d === 1) return 'Es mañana';
  if (d > 1) return `Faltan ${d} días`;
  if (d === -1) return 'Fue ayer';
  return `Pasó hace ${-d} días`;
}

/**
 * Progreso 0..100 del tiempo transcurrido desde que se creó la cuenta regresiva
 * hasta la fecha objetivo. Sirve para el anillo.
 */
export function progress(c: Pick<Countdown, 'date' | 'time' | 'createdAt'>, now: Date = new Date()): number {
  const start = new Date(c.createdAt.replace(' ', 'T')).getTime();
  const end = combineDateTime(c.date, c.time).getTime();
  if (!Number.isFinite(start) || end <= start) return daysLeft(c, now) <= 0 ? 100 : 0;
  const p = ((now.getTime() - start) / (end - start)) * 100;
  return Math.max(0, Math.min(100, Math.round(p)));
}

/** Ordena: primero las que faltan (más cercana primero), después las pasadas (más reciente primero). */
export function sortCountdowns(list: Countdown[], now: Date = new Date()): Countdown[] {
  const today = toISODate(now);
  const up = list.filter((c) => c.date >= today).sort((a, b) => a.date.localeCompare(b.date) || (a.time ?? '').localeCompare(b.time ?? ''));
  const past = list.filter((c) => c.date < today).sort((a, b) => b.date.localeCompare(a.date));
  return [...up, ...past];
}

/** La próxima cuenta regresiva fijada para el inicio (o la próxima de todas si ninguna está fijada). */
export function featured(list: Countdown[], now: Date = new Date()): Countdown | null {
  const sorted = sortCountdowns(list, now).filter((c) => c.date >= toISODate(now));
  return sorted.find((c) => c.pinned) ?? sorted[0] ?? null;
}
