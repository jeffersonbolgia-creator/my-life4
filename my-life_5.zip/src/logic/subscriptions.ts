// Suscripciones y gastos fijos: próximos cobros, días que faltan, totales y renovación.

import type { DollarRate, Subscription, SubscriptionCycle, Transaction } from '../types';
import { addDays, addMonths, diffDays, toISODate } from '../lib/dates';
import { normalizeText } from '../lib/text';
import { usdToArsCents } from './dollar';

export const CYCLE_LABELS: Record<SubscriptionCycle, string> = { weekly: 'Semanal', monthly: 'Mensual', yearly: 'Anual' };

export function nextCycleDate(date: string, cycle: SubscriptionCycle): string {
  if (cycle === 'weekly') return addDays(date, 7);
  if (cycle === 'yearly') return addMonths(date, 12);
  return addMonths(date, 1);
}

/** Largo del ciclo en días (aproximado para mensual y anual). */
export function cycleDays(cycle: SubscriptionCycle): number {
  return cycle === 'weekly' ? 7 : cycle === 'yearly' ? 365 : 30;
}

/** Días que faltan para el próximo cobro (0 = hoy, negativo = vencido sin renovar). */
export function daysUntilCharge(s: Pick<Subscription, 'nextDate'>, now: Date = new Date()): number {
  return diffDays(s.nextDate, toISODate(now));
}

/** Avance del ciclo 0..100 (cuánto del ciclo ya pasó). */
export function cycleProgress(s: Pick<Subscription, 'nextDate' | 'cycle'>, now: Date = new Date()): number {
  const left = daysUntilCharge(s, now);
  const total = cycleDays(s.cycle);
  return Math.max(0, Math.min(100, Math.round(((total - Math.max(0, left)) / total) * 100)));
}

export function daysLabel(s: Pick<Subscription, 'nextDate'>, now: Date = new Date()): string {
  const d = daysUntilCharge(s, now);
  if (d === 0) return 'Se cobra hoy';
  if (d === 1) return 'Se cobra mañana';
  if (d > 1) return `Faltan ${d} días`;
  return `Venció hace ${-d} ${-d === 1 ? 'día' : 'días'}`;
}

/**
 * Si el próximo cobro ya pasó, avanza la fecha tantos ciclos como haga falta hasta quedar en el futuro (o hoy).
 * Devuelve la fecha nueva o null si no cambia.
 */
export function rolledDate(s: Pick<Subscription, 'nextDate' | 'cycle'>, now: Date = new Date()): string | null {
  const today = toISODate(now);
  if (s.nextDate >= today) return null;
  let d = s.nextDate;
  let guard = 0;
  while (d < today && guard < 600) {
    d = nextCycleDate(d, s.cycle);
    guard++;
  }
  return d;
}

/** Monto mensual equivalente en centavos de la moneda de la suscripción. */
export function monthlyAmount(s: Pick<Subscription, 'amount' | 'cycle'>): number {
  if (s.cycle === 'weekly') return Math.round((s.amount * 52) / 12);
  if (s.cycle === 'yearly') return Math.round(s.amount / 12);
  return s.amount;
}

/** Monto en centavos de ARS (convierte USD con la cotización indicada; sin cotización, 0 para USD). */
export function amountInArs(s: Pick<Subscription, 'amount' | 'currency'>, usdSell: number | null): number {
  if (s.currency === 'ARS') return s.amount;
  return usdSell ? usdToArsCents(s.amount, usdSell) : 0;
}

export interface SubscriptionTotals {
  monthlyArs: number;
  monthlyUsd: number; // centavos de USD (sin convertir)
  count: number;
  hasUnconvertedUsd: boolean;
  byCategory: { category: string; amountArs: number; color: string }[];
}

export function totals(list: Subscription[], usdSell: number | null): SubscriptionTotals {
  const active = list.filter((s) => s.active);
  let monthlyArs = 0;
  let monthlyUsd = 0;
  let hasUnconvertedUsd = false;
  const cats = new Map<string, { amountArs: number; color: string }>();
  for (const s of active) {
    const m = monthlyAmount(s);
    if (s.currency === 'USD') {
      monthlyUsd += m;
      if (!usdSell) hasUnconvertedUsd = true;
    }
    const ars = amountInArs({ amount: m, currency: s.currency }, usdSell);
    monthlyArs += ars;
    const key = s.category || 'Otros';
    const cur = cats.get(key) ?? { amountArs: 0, color: s.color };
    cur.amountArs += ars;
    cats.set(key, cur);
  }
  const byCategory = [...cats.entries()].map(([category, v]) => ({ category, ...v })).sort((a, b) => b.amountArs - a.amountArs);
  return { monthlyArs, monthlyUsd, count: active.length, hasUnconvertedUsd, byCategory };
}

export function sortByNext(list: Subscription[]): Subscription[] {
  return [...list].sort((a, b) => Number(b.active) - Number(a.active) || a.nextDate.localeCompare(b.nextDate) || a.id - b.id);
}

/** La suscripción que coincide con el nombre de un gasto registrado (para darla por pagada). */
export function matchSubscription(list: Subscription[], tx: Pick<Transaction, 'name' | 'kind'>): Subscription | null {
  if (tx.kind !== 'expense') return null;
  const n = normalizeText(tx.name);
  if (!n) return null;
  return list.find((s) => s.active && (normalizeText(s.name) === n || n.includes(normalizeText(s.name)) || normalizeText(s.name).includes(n))) ?? null;
}

/** Fecha de cobro que corresponde dar por pagada: si el gasto es cercano al próximo cobro (±7 días), renueva. */
export function shouldRenewOnPayment(s: Pick<Subscription, 'nextDate' | 'cycle'>, txDate: string): boolean {
  return Math.abs(diffDays(s.nextDate, txDate)) <= 7;
}

export function usdSellFrom(rates: DollarRate[], casa: string): number | null {
  const r = rates.find((x) => x.casa === casa) ?? rates.find((x) => x.casa === 'tarjeta') ?? rates.find((x) => x.casa === 'blue');
  return r ? r.sell : null;
}
