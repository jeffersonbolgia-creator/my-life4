import type { CalendarEvent } from '../types';
import { addDays, parseISODate, toISODate, weekday, daysInMonth, timeToMinutes, isValidTime } from '../lib/dates';

export interface Occurrence {
  event: CalendarEvent;
  date: string;
}

function occursOn(e: CalendarEvent, d: string): boolean {
  if (d < e.date) return false;
  if (e.untilDate && d > e.untilDate) return false;
  switch (e.recurrence) {
    case 'none':
      return d === e.date;
    case 'daily':
      return true;
    case 'weekly': {
      const days = e.weekdays.length ? e.weekdays : [weekday(e.date)];
      return days.includes(weekday(d));
    }
    case 'monthly': {
      const base = parseISODate(e.date).getDate();
      const cur = parseISODate(d);
      const dim = daysInMonth(cur.getFullYear(), cur.getMonth());
      return cur.getDate() === Math.min(base, dim);
    }
    case 'yearly': {
      const b = parseISODate(e.date);
      const cur = parseISODate(d);
      if (cur.getMonth() !== b.getMonth()) return false;
      const dim = daysInMonth(cur.getFullYear(), cur.getMonth());
      return cur.getDate() === Math.min(b.getDate(), dim);
    }
    default:
      return false;
  }
}

export function eventSortKey(e: CalendarEvent): number {
  if (e.allDay || !isValidTime(e.startTime)) return -1;
  return timeToMinutes(e.startTime);
}

/** Expande eventos (con repeticiones) dentro del rango [from, to]. */
export function occurrencesInRange(events: CalendarEvent[], from: string, to: string): Occurrence[] {
  const out: Occurrence[] = [];
  for (const e of events) {
    if (e.recurrence === 'none') {
      if (e.date >= from && e.date <= to) out.push({ event: e, date: e.date });
      continue;
    }
    let d = from < e.date ? e.date : from;
    let guard = 0;
    while (d <= to && guard++ < 800) {
      if (occursOn(e, d)) out.push({ event: e, date: d });
      d = addDays(d, 1);
    }
  }
  out.sort((a, b) => (a.date === b.date ? eventSortKey(a.event) - eventSortKey(b.event) : a.date < b.date ? -1 : 1));
  return out;
}

export function occurrencesOn(events: CalendarEvent[], date: string): Occurrence[] {
  return occurrencesInRange(events, date, date);
}

/** Edad que cumple en un cumpleaños (si el evento tiene año de nacimiento). */
export function birthdayAge(e: CalendarEvent, onDate: string): number | null {
  if (e.type !== 'birthday') return null;
  const age = parseISODate(onDate).getFullYear() - parseISODate(e.date).getFullYear();
  return age > 0 && age < 130 ? age : null;
}

export function nextOccurrence(e: CalendarEvent, from: string, horizonDays = 400): string | null {
  const to = addDays(from, horizonDays);
  const occ = occurrencesInRange([e], from, to);
  return occ.length ? occ[0].date : null;
}

export { toISODate };
