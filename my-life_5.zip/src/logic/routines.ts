// Lógica de rutinas: qué rutinas aplican hoy, avance, rachas y horarios de cada paso.

import type { Routine, RoutineLog, RoutineStep } from '../types';
import { addDays, isValidTime, minutesToTime, timeToMinutes, weekday } from '../lib/dates';

export type RoutineLogs = Map<number, Map<string, RoutineLog>>;

/** La rutina aplica en la fecha dada (según sus días de la semana). */
export function isRoutineScheduledOn(r: Routine, date: string): boolean {
  if (r.archived) return false;
  if (!r.weekdays.length) return true;
  return r.weekdays.includes(weekday(date));
}

export function routinesForDay(list: Routine[], date: string): Routine[] {
  return list.filter((r) => isRoutineScheduledOn(r, date));
}

/** Pasos completados y total para un día. */
export function routineProgress(r: Routine, log: RoutineLog | undefined): { done: number; total: number; pct: number; completed: boolean } {
  const valid = new Set(r.steps.map((s) => s.id));
  const done = (log?.doneSteps ?? []).filter((s) => valid.has(s)).length;
  const total = r.steps.length;
  const pct = total ? Math.round((done / total) * 100) : 0;
  return { done, total, pct, completed: total > 0 && done >= total };
}

/** Hora estimada de cada paso a partir de la hora de inicio. */
export function stepTimes(r: Pick<Routine, 'startTime' | 'steps'>): (string | null)[] {
  if (!isValidTime(r.startTime)) return r.steps.map(() => null);
  let cur = timeToMinutes(r.startTime);
  return r.steps.map((s) => {
    const t = minutesToTime(cur);
    cur += Math.max(0, s.minutes);
    return t;
  });
}

export function totalMinutes(steps: RoutineStep[]): number {
  return steps.reduce((a, s) => a + Math.max(0, s.minutes), 0);
}

/** El paso que toca ahora: el primero sin completar. */
export function currentStep(r: Routine, log: RoutineLog | undefined): RoutineStep | null {
  const done = new Set(log?.doneSteps ?? []);
  return r.steps.find((s) => !done.has(s.id)) ?? null;
}

/**
 * Racha actual: días seguidos (hacia atrás desde `today`) en los que la rutina
 * aplicaba y se completó. Si hoy aplica y todavía no se completó, no corta la racha.
 */
export function routineStreak(r: Routine, logs: Map<string, RoutineLog> | undefined, today: string): number {
  let streak = 0;
  let d = today;
  let first = true;
  for (let i = 0; i < 400; i++) {
    if (d < r.createdAt.slice(0, 10)) break;
    if (isRoutineScheduledOn(r, d)) {
      const done = !!logs?.get(d)?.completed;
      if (done) streak++;
      else if (!first) break;
    }
    first = false;
    d = addDays(d, -1);
  }
  return streak;
}

/** Historial de los últimos `n` días: 'done' | 'missed' | 'off' (no aplicaba) | 'today'. */
export function routineHistory(r: Routine, logs: Map<string, RoutineLog> | undefined, today: string, n = 14): { date: string; state: 'done' | 'missed' | 'off' | 'today' }[] {
  const out: { date: string; state: 'done' | 'missed' | 'off' | 'today' }[] = [];
  for (let i = n - 1; i >= 0; i--) {
    const d = addDays(today, -i);
    const done = !!logs?.get(d)?.completed;
    if (!isRoutineScheduledOn(r, d) || d < r.createdAt.slice(0, 10)) out.push({ date: d, state: 'off' });
    else if (done) out.push({ date: d, state: 'done' });
    else if (d === today) out.push({ date: d, state: 'today' });
    else out.push({ date: d, state: 'missed' });
  }
  return out;
}

/** Cuántos días completó de los que aplicaban, en los últimos `n` días (sin contar hoy si no está completo). */
export function routineRate(r: Routine, logs: Map<string, RoutineLog> | undefined, today: string, n = 14): { done: number; total: number } {
  let done = 0;
  let total = 0;
  for (const h of routineHistory(r, logs, today, n)) {
    if (h.state === 'off') continue;
    if (h.state === 'today') continue;
    total++;
    if (h.state === 'done') done++;
  }
  return { done, total };
}
