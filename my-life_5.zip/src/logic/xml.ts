// Ayudas mínimas para leer RSS/Atom sin dependencias (suficiente para feeds bien formados).

import { decodeEntities, stripHtml } from './discover';

export { decodeEntities, stripHtml };

export function tag(xml: string, name: string): string | null {
  const m = xml.match(new RegExp(`<${name}(?:\\s[^>]*)?>([\\s\\S]*?)</${name}>`, 'i'));
  if (!m) return null;
  let v = m[1].trim();
  const cdata = v.match(/^<!\[CDATA\[([\s\S]*?)\]\]>$/);
  if (cdata) v = cdata[1];
  return v.trim();
}

export function attr(xml: string, tagName: string, attrName: string): string | null {
  const m = xml.match(new RegExp(`<${tagName}[^>]*\\s${attrName}=["']([^"']+)["']`, 'i'));
  return m ? decodeEntities(m[1]) : null;
}

/** Bloques <item> (RSS) o <entry> (Atom). */
export function entries(xml: string): string[] {
  return xml.match(/<item(?:\s[^>]*)?>[\s\S]*?<\/item>/gi) ?? xml.match(/<entry(?:\s[^>]*)?>[\s\S]*?<\/entry>/gi) ?? [];
}

export function isoDate(raw: string | null | undefined, fallback: Date = new Date()): string {
  if (!raw) return fallback.toISOString();
  const d = new Date(raw.trim());
  return Number.isNaN(d.getTime()) ? fallback.toISOString() : d.toISOString();
}

export const isHttp = (s: unknown): s is string => typeof s === 'string' && /^https?:\/\//i.test(s);
