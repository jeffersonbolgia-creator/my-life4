// Copias de seguridad: exporta/importa todos los datos de UN perfil.
// El PIN nunca se incluye en la copia.

import { getDb } from './db';
import { profilesRepo } from './repos';
import type { Transaction } from '../types';

export const BACKUP_FORMAT = 'mylife-backup';
export const BACKUP_VERSION = 4;

const TABLES = ['tasks', 'events', 'goals', 'habits', 'notes', 'transactions', 'reminders', 'countdowns', 'routines', 'dollar_alerts', 'subscriptions', 'discover_items', 'assistant_messages', 'feed_items', 'feed_sources', 'watchlist', 'salaries'] as const;

export interface BackupFile {
  format: string;
  version: number;
  exportedAt: string;
  profile: { name: string; birthDate: string | null; age: number | null; avatarColor: string; answers: unknown; settings: unknown };
  tables: Record<string, any[]>;
  habitLogs: { habit_id: number; date: string }[];
  routineLogs?: { routine_id: number; date: string; done_steps: string; completed: number }[];
}

export async function exportProfile(pid: number): Promise<BackupFile> {
  const db = getDb();
  const p = await profilesRepo.get(pid);
  if (!p) throw new Error('Perfil inexistente');
  const tables: Record<string, any[]> = {};
  for (const t of TABLES) tables[t] = await db.all(`SELECT * FROM ${t} WHERE profile_id = ? ORDER BY id`, [pid]);
  const habitLogs = await db.all<{ habit_id: number; date: string }>(
    'SELECT l.habit_id, l.date FROM habit_logs l JOIN habits h ON h.id = l.habit_id WHERE h.profile_id = ?',
    [pid],
  );
  const routineLogs = await db.all<{ routine_id: number; date: string; done_steps: string; completed: number }>(
    'SELECT l.routine_id, l.date, l.done_steps, l.completed FROM routine_logs l JOIN routines r ON r.id = l.routine_id WHERE r.profile_id = ?',
    [pid],
  );
  return {
    format: BACKUP_FORMAT,
    version: BACKUP_VERSION,
    exportedAt: new Date().toISOString(),
    profile: { name: p.name, birthDate: p.birthDate, age: p.age, avatarColor: p.avatarColor, answers: p.answers, settings: p.settings },
    tables,
    habitLogs,
    routineLogs,
  };
}

const COLUMNS: Record<(typeof TABLES)[number], string[]> = {
  tasks: ['title', 'description', 'due_date', 'due_time', 'priority', 'category', 'remind_minutes', 'completed_at', 'created_at'],
  events: ['title', 'type', 'date', 'start_time', 'end_time', 'all_day', 'recurrence', 'weekdays', 'until_date', 'remind_minutes', 'location', 'notes', 'created_at'],
  goals: ['title', 'description', 'term', 'target_date', 'progress', 'completed_at', 'created_at', 'saving_target', 'saving_saved', 'saving_currency', 'saving_casa'],
  habits: ['title', 'frequency', 'weekdays', 'target_per_week', 'reminder_time', 'color', 'icon', 'archived', 'created_at'],
  notes: ['title', 'body', 'category', 'is_list', 'items', 'favorite', 'created_at', 'updated_at'],
  transactions: ['kind', 'name', 'emoji', 'category', 'quantity', 'unit_price', 'amount', 'date', 'description', 'created_at'],
  reminders: ['title', 'kind', 'date', 'time', 'repeat', 'amount', 'notes', 'done', 'created_at'],
  countdowns: ['title', 'date', 'time', 'icon', 'color', 'remind_days_before', 'pinned', 'created_at'],
  routines: ['title', 'kind', 'icon', 'color', 'start_time', 'steps', 'weekdays', 'remind', 'archived', 'created_at'],
  dollar_alerts: ['casa', 'kind', 'value', 'enabled', 'last_fired_at', 'created_at'],
  subscriptions: ['name', 'icon', 'color', 'amount', 'currency', 'cycle', 'next_date', 'remind_days_before', 'active', 'category', 'created_at'],
  discover_items: ['topic', 'title', 'summary', 'url', 'source', 'image_url', 'published_at', 'saved', 'hidden', 'opened', 'fetched_at'],
  assistant_messages: ['role', 'text', 'payload', 'created_at'],
  feed_items: ['kind', 'topic', 'external_id', 'title', 'text', 'url', 'author', 'author_handle', 'author_avatar', 'image_url', 'published_at', 'likes', 'extra', 'spoiler', 'saved', 'hidden', 'opened', 'fetched_at'],
  feed_sources: ['kind', 'external_id', 'name', 'image_url', 'extra', 'muted', 'created_at'],
  watchlist: ['kind', 'title', 'status', 'rating', 'genres', 'image_url', 'external_id', 'notes', 'next_date', 'created_at', 'updated_at'],
  salaries: ['month', 'amount', 'created_at'],
};

/** Valores para columnas que una copia vieja no trae y que no admiten NULL. */
const COLUMN_DEFAULTS: Record<string, string | number> = {
  saving_saved: 0, saving_currency: 'ARS', summary: '', source: '', saved: 0, hidden: 0, opened: 0, fetched_at: '', active: 1, category: '', enabled: 1,
  kind: 'news', topic: '', text: '', url: '', author: '', author_handle: '', spoiler: 0, muted: 0, status: 'pending', genres: '[]', notes: '', updated_at: '',
};

export function validateBackup(data: any): data is BackupFile {
  return !!data && data.format === BACKUP_FORMAT && typeof data.version === 'number' && data.version <= BACKUP_VERSION &&
    typeof data.tables === 'object' && data.profile && typeof data.profile.name === 'string';
}

/** Reemplaza todos los datos del perfil por los de la copia. */
export async function restoreProfile(pid: number, data: BackupFile, opts: { restoreSettings: boolean }): Promise<{ total: number }> {
  if (!validateBackup(data)) throw new Error('El archivo no es una copia válida de MY LIFE');
  const db = getDb();
  let total = 0;
  await db.transaction(async () => {
    await db.run('DELETE FROM habit_logs WHERE habit_id IN (SELECT id FROM habits WHERE profile_id = ?)', [pid]);
    await db.run('DELETE FROM routine_logs WHERE routine_id IN (SELECT id FROM routines WHERE profile_id = ?)', [pid]);
    for (const t of TABLES) await db.run(`DELETE FROM ${t} WHERE profile_id = ?`, [pid]);
    const habitIdMap = new Map<number, number>();
    const routineIdMap = new Map<number, number>();
    for (const t of TABLES) {
      const rows = Array.isArray(data.tables[t]) ? data.tables[t] : [];
      const cols = COLUMNS[t];
      for (const row of rows) {
        if (!row || typeof row !== 'object') continue;
        if (t === 'feed_items' && (!row.external_id || !row.published_at || !row.title)) continue;
        if (t === 'feed_sources' && (!row.kind || !row.external_id || !row.name)) continue;
        if (t === 'watchlist' && (!row.kind || !row.title)) continue;
        const values = cols.map((c) => {
          const v = row[c];
          if (v === undefined || v === null) return COLUMN_DEFAULTS[c] ?? null;
          return typeof v === 'object' ? JSON.stringify(v) : v;
        });
        const sql = `INSERT INTO ${t} (profile_id, ${cols.join(', ')}) VALUES (?, ${cols.map(() => '?').join(', ')})`;
        const r = await db.run(sql, [pid, ...values]);
        if (t === 'habits' && typeof row.id === 'number') habitIdMap.set(row.id, r.lastInsertRowId);
        if (t === 'routines' && typeof row.id === 'number') routineIdMap.set(row.id, r.lastInsertRowId);
        total++;
      }
    }
    for (const l of data.habitLogs ?? []) {
      const nid = habitIdMap.get(l.habit_id);
      if (nid && typeof l.date === 'string') await db.run('INSERT OR IGNORE INTO habit_logs (habit_id, date) VALUES (?,?)', [nid, l.date]);
    }
    for (const l of data.routineLogs ?? []) {
      const nid = routineIdMap.get(l.routine_id);
      if (nid && typeof l.date === 'string') {
        await db.run('INSERT OR IGNORE INTO routine_logs (routine_id, date, done_steps, completed) VALUES (?,?,?,?)', [nid, l.date, typeof l.done_steps === 'string' ? l.done_steps : '[]', l.completed ? 1 : 0]);
      }
    }
    // Copias de la 2.0: lo de "Descubrir" pasa al Feed.
    await db.run(
      `INSERT OR IGNORE INTO feed_items (profile_id, kind, topic, external_id, title, text, url, author, image_url, published_at, saved, hidden, opened, fetched_at)
       SELECT profile_id, 'news', topic, 'news:' || url, title, summary, url, source, image_url, published_at, saved, hidden, opened, fetched_at FROM discover_items WHERE profile_id = ?`,
      [pid],
    );
  });
  if (opts.restoreSettings) {
    const patch: Parameters<typeof profilesRepo.update>[1] = {
      birthDate: data.profile.birthDate ?? null,
      age: data.profile.age ?? null,
      answers: (data.profile.answers as any) ?? {},
    };
    if (data.profile.name) patch.name = data.profile.name;
    await profilesRepo.update(pid, patch);
    if (data.profile.settings && typeof data.profile.settings === 'object') {
      // El PIN no viaja en la copia, así que se conservan su largo y la huella actuales.
      const { pinLength: _p, biometrics: _b, ...rest } = data.profile.settings as any;
      await profilesRepo.updateSettings(pid, rest);
    }
  }
  return { total };
}

function csvCell(v: unknown): string {
  const s = v == null ? '' : String(v);
  return /[",;\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}

/** CSV de movimientos (separado por ; para que Excel/Sheets en español lo abra bien). */
export function transactionsToCsv(txs: Transaction[]): string {
  const head = ['Fecha', 'Tipo', 'Nombre', 'Categoría', 'Cantidad', 'Precio unitario', 'Importe', 'Descripción'];
  const money = (c: number | null) => (c == null ? '' : (c / 100).toFixed(2).replace('.', ','));
  const lines = txs.map((t) =>
    [t.date, t.kind === 'income' ? 'Ingreso' : 'Gasto', t.name, t.category, String(t.quantity).replace('.', ','), money(t.unitPrice), money(t.amount), t.description]
      .map(csvCell)
      .join(';'),
  );
  return '﻿' + [head.join(';'), ...lines].join('\n');
}
