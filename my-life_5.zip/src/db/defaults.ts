import type { AlarmPrefs, AlarmType, DashboardCardKey, DollarCasa, FeedKind, ModuleKey, NotificationSettings, ProfileSettings } from '../types';

export const ALL_DASHBOARD_CARDS: DashboardCardKey[] = ['today', 'routine', 'countdown', 'holidays', 'dollar', 'subscriptions', 'tasks', 'events', 'habits', 'finance', 'feed', 'reminders', 'goals', 'weekly'];

export const DASHBOARD_CARD_LABELS: Record<DashboardCardKey, string> = {
  today: 'Resumen del día',
  routine: 'Rutina de hoy',
  countdown: 'Cuenta regresiva',
  dollar: 'Dólar hoy',
  subscriptions: 'Próximos cobros',
  feed: 'Feed',
  holidays: 'Próximo feriado',
  tasks: 'Próximas tareas',
  events: 'Próximos eventos',
  reminders: 'Recordatorios',
  habits: 'Hábitos de hoy',
  goals: 'Objetivos',
  finance: 'Resumen financiero',
  weekly: 'Resumen semanal',
};

/** Tarjetas del inicio que dependen de un módulo: si el módulo está apagado, no se muestran. */
export const CARD_MODULE: Partial<Record<DashboardCardKey, ModuleKey>> = {
  routine: 'routines',
  countdown: 'countdown',
  dollar: 'dollar',
  subscriptions: 'subscriptions',
  feed: 'feed',
  holidays: 'holidays',
};

export const ALL_MODULES: ModuleKey[] = ['countdown', 'routines', 'dollar', 'subscriptions', 'feed', 'assistant', 'salary', 'holidays', 'transport', 'watchlist'];

export function defaultModules(): Record<ModuleKey, boolean> {
  return { countdown: true, routines: true, dollar: false, subscriptions: false, feed: false, assistant: false, salary: false, holidays: false, transport: false, watchlist: false };
}

export const ALARM_TYPES: AlarmType[] = ['reminders', 'tasks', 'events', 'subscriptions', 'routines'];
export const ALARM_SOUNDS = ['classic', 'soft', 'chime', 'bell'] as const;
export const FEED_KINDS: FeedKind[] = ['post', 'news', 'video', 'podcast', 'match', 'game', 'show', 'music', 'crypto'];
export const ALL_CASAS: DollarCasa[] = ['oficial', 'blue', 'bolsa', 'contadoconliqui', 'tarjeta', 'mayorista', 'cripto', 'eur', 'brl', 'clp', 'uyu'];

export function defaultAlarms(): Record<AlarmType, AlarmPrefs> {
  return {
    reminders: { alarm: true, sound: 'classic', repeat: true },
    tasks: { alarm: false, sound: 'chime', repeat: false },
    events: { alarm: false, sound: 'bell', repeat: false },
    subscriptions: { alarm: false, sound: 'soft', repeat: false },
    routines: { alarm: false, sound: 'soft', repeat: false },
  };
}

export function defaultFeedTabs(): Partial<Record<FeedKind, boolean>> {
  return { post: true, news: true, video: true, podcast: false, match: false, game: false, show: false, music: false, crypto: false };
}

export function defaultSettings(): ProfileSettings {
  return {
    themeMode: 'dark',
    accent: 'violet',
    gradients: true,
    haptics: true,
    compact: false,
    dashboardCards: ALL_DASHBOARD_CARDS.map((key) => ({ key, visible: true })),
    showWeeklySummary: true,
    showMonthlySummary: true,
    autoLockMinutes: 1,
    biometrics: false,
    pinLength: 4,
    notifications: {
      enabled: true,
      tasks: true,
      events: true,
      habits: true,
      payments: true,
      reminders: true,
      goals: true,
      dailySummary: false,
      dailySummaryTime: '08:00',
      defaultTime: '09:00',
      discreet: false,
      alarms: defaultAlarms(),
      episodes: true,
    },
    currency: 'ARS',
    initialBalance: 0,
    initialBalanceDate: null,
    modules: defaultModules(),
    dollarCasa: 'blue',
    dollarCasas: ['blue', 'oficial', 'tarjeta', 'bolsa', 'cripto'],
    discover: { topics: [], weights: {}, wifiOnly: false },
    feed: { tabs: defaultFeedTabs(), spoilerFree: false, summary: true },
    transport: { rechargeDay: null, rechargeAmount: null },
    assistant: { name: 'Nova', personality: 'warm', proactive: true },
    glow: 'soft',
    bgStyle: 'gradient',
    radiusStyle: 'soft',
    fontScale: 'normal',
  };
}

/** Combina la configuración guardada con los valores por defecto (por si se agregan opciones nuevas). */
export function mergeSettings(raw: Partial<ProfileSettings> | null | undefined): ProfileSettings {
  const d = defaultSettings();
  if (!raw || typeof raw !== 'object') return d;
  // Compatibilidad con la 2.0: "discover" pasó a llamarse "feed".
  const rawCards = Array.isArray(raw.dashboardCards) ? raw.dashboardCards.map((c: any) => (c && c.key === 'discover' ? { ...c, key: 'feed' } : c)) : null;
  const cards = rawCards ? rawCards.filter((c) => c && ALL_DASHBOARD_CARDS.includes(c.key)) : d.dashboardCards;
  for (const k of ALL_DASHBOARD_CARDS) if (!cards.some((c) => c.key === k)) cards.push({ key: k, visible: true });
  const modules = { ...d.modules };
  if (raw.modules && typeof raw.modules === 'object') {
    const rm: any = raw.modules;
    for (const k of ALL_MODULES) if (typeof rm[k] === 'boolean') modules[k] = rm[k];
    if (typeof rm.discover === 'boolean' && typeof rm.feed !== 'boolean') modules.feed = rm.discover;
  }
  const pick = <T extends string>(v: unknown, allowed: readonly T[], fallback: T): T => (allowed.includes(v as T) ? (v as T) : fallback);
  const rn: any = raw.notifications ?? {};
  const alarms = defaultAlarms();
  if (rn.alarms && typeof rn.alarms === 'object') {
    for (const k of ALARM_TYPES) {
      const a = rn.alarms[k];
      if (a && typeof a === 'object') alarms[k] = { alarm: typeof a.alarm === 'boolean' ? a.alarm : alarms[k].alarm, sound: pick(a.sound, ALARM_SOUNDS, alarms[k].sound), repeat: typeof a.repeat === 'boolean' ? a.repeat : alarms[k].repeat };
    }
  }
  const notifications: NotificationSettings = { ...d.notifications, ...rn, alarms, episodes: typeof rn.episodes === 'boolean' ? rn.episodes : true };
  const rawCasas = Array.isArray(raw.dollarCasas) ? raw.dollarCasas.filter((c: unknown) => (ALL_CASAS as string[]).includes(c as string)) : d.dollarCasas;
  const tabs: Partial<Record<FeedKind, boolean>> = defaultFeedTabs();
  const rf: any = raw.feed ?? {};
  if (rf.tabs && typeof rf.tabs === 'object') for (const k of FEED_KINDS) if (typeof rf.tabs[k] === 'boolean') tabs[k] = rf.tabs[k];
  const rt: any = raw.transport ?? {};
  return {
    ...d,
    ...raw,
    dashboardCards: cards,
    notifications,
    modules,
    dollarCasa: pick(raw.dollarCasa, ALL_CASAS, d.dollarCasa),
    dollarCasas: rawCasas.length ? [...new Set(rawCasas as DollarCasa[])] : d.dollarCasas,
    feed: { tabs, spoilerFree: typeof rf.spoilerFree === 'boolean' ? rf.spoilerFree : false, summary: typeof rf.summary === 'boolean' ? rf.summary : true },
    transport: {
      rechargeDay: Number.isInteger(rt.rechargeDay) && rt.rechargeDay >= 1 && rt.rechargeDay <= 28 ? rt.rechargeDay : null,
      rechargeAmount: Number.isInteger(rt.rechargeAmount) && rt.rechargeAmount > 0 ? rt.rechargeAmount : null,
    },
    discover: {
      topics: Array.isArray(raw.discover?.topics) ? raw.discover!.topics.filter((x) => typeof x === 'string') : d.discover.topics,
      weights: raw.discover?.weights && typeof raw.discover.weights === 'object' ? raw.discover.weights : {},
      wifiOnly: typeof raw.discover?.wifiOnly === 'boolean' ? raw.discover.wifiOnly : false,
    },
    assistant: {
      name: typeof raw.assistant?.name === 'string' && raw.assistant.name.trim() ? raw.assistant.name.trim().slice(0, 20) : d.assistant.name,
      personality: pick(raw.assistant?.personality, ['warm', 'direct', 'fun'] as const, d.assistant.personality),
      proactive: typeof raw.assistant?.proactive === 'boolean' ? raw.assistant.proactive : true,
    },
    glow: pick(raw.glow, ['off', 'soft', 'strong'] as const, d.glow),
    bgStyle: pick(raw.bgStyle, ['pure', 'gradient', 'nebula'] as const, d.bgStyle),
    radiusStyle: pick(raw.radiusStyle, ['sharp', 'soft', 'round'] as const, d.radiusStyle),
    fontScale: pick(raw.fontScale, ['small', 'normal', 'large'] as const, d.fontScale),
  };
}

export const AVATAR_COLORS = ['#8B5CF6', '#6366F1', '#D946EF', '#3B82F6', '#10B981', '#F59E0B', '#F43F5E'];

export const TASK_CATEGORIES = ['Personal', 'Estudio', 'Trabajo', 'Casa', 'Salud', 'Compras', 'Trámites'];
export const NOTE_CATEGORIES = ['General', 'Ideas', 'Estudio', 'Trabajo', 'Compras', 'Personal'];

export const COUNTDOWN_ICONS: { icon: string; label: string }[] = [
  { icon: 'Plane', label: 'Viaje' },
  { icon: 'Cake', label: 'Cumpleaños' },
  { icon: 'GraduationCap', label: 'Examen' },
  { icon: 'Gamepad2', label: 'Juego' },
  { icon: 'PartyPopper', label: 'Fiesta' },
  { icon: 'Heart', label: 'Especial' },
  { icon: 'Trophy', label: 'Evento' },
  { icon: 'Gift', label: 'Regalo' },
  { icon: 'Music', label: 'Recital' },
  { icon: 'Sun', label: 'Vacaciones' },
  { icon: 'Star', label: 'Otro' },
];

export const ROUTINE_TEMPLATES: { kind: 'morning' | 'night'; title: string; icon: string; color: string; steps: { title: string; minutes: number }[] }[] = [
  {
    kind: 'morning',
    title: 'Rutina de mañana',
    icon: 'Sunrise',
    color: '#FBBF24',
    steps: [
      { title: 'Tomar un vaso de agua', minutes: 2 },
      { title: 'Estirar el cuerpo', minutes: 5 },
      { title: 'Ducha', minutes: 15 },
      { title: 'Desayunar', minutes: 15 },
      { title: 'Repasar la agenda del día', minutes: 5 },
    ],
  },
  {
    kind: 'night',
    title: 'Rutina de noche',
    icon: 'Moon',
    color: '#6366F1',
    steps: [
      { title: 'Dejar lista la ropa de mañana', minutes: 5 },
      { title: 'Anotar lo de hoy', minutes: 5 },
      { title: 'Lavarme los dientes', minutes: 3 },
      { title: 'Celular en modo descanso', minutes: 1 },
      { title: 'Leer un rato', minutes: 15 },
    ],
  },
];

export const SUBSCRIPTION_TEMPLATES: { name: string; icon: string; color: string; category: string; currency: 'ARS' | 'USD' }[] = [
  { name: 'Streaming de series', icon: 'Clapperboard', color: '#E11D48', category: 'Entretenimiento', currency: 'ARS' },
  { name: 'Música', icon: 'Music', color: '#22C55E', category: 'Entretenimiento', currency: 'ARS' },
  { name: 'Videos', icon: 'Play', color: '#EF4444', category: 'Entretenimiento', currency: 'ARS' },
  { name: 'Juegos online', icon: 'Gamepad2', color: '#3B82F6', category: 'Juegos', currency: 'USD' },
  { name: 'Nube', icon: 'Cloud', color: '#0EA5E9', category: 'Servicios', currency: 'ARS' },
  { name: 'Gimnasio', icon: 'Dumbbell', color: '#F97316', category: 'Salud', currency: 'ARS' },
  { name: 'Internet', icon: 'Wifi', color: '#8B5CF6', category: 'Hogar', currency: 'ARS' },
  { name: 'Celular', icon: 'Smartphone', color: '#06B6D4', category: 'Hogar', currency: 'ARS' },
  { name: 'Alquiler', icon: 'House', color: '#84CC16', category: 'Hogar', currency: 'ARS' },
  { name: 'Luz / gas / agua', icon: 'Zap', color: '#FBBF24', category: 'Hogar', currency: 'ARS' },
  { name: 'Curso', icon: 'GraduationCap', color: '#A78BFA', category: 'Estudio', currency: 'ARS' },
  { name: 'Otra', icon: 'Receipt', color: '#64748B', category: 'Otros', currency: 'ARS' },
];
