// Trae las cotizaciones del dólar de internet y las guarda en el celular.
// Fuentes (gratuitas, sin clave; sólo se envía el tipo de dólar, nunca datos del usuario):
//  - DolarAPI:        GET https://dolarapi.com/v1/dolares                         (cotización actual de cada casa)
//  - ArgentinaDatos:  GET https://api.argentinadatos.com/v1/cotizaciones/dolares/{casa}  (histórico por día)
// Si una fuente falla, se usa lo último guardado.

import { dollarRepo, dollarAlertsRepo, DOLLAR_CASAS } from '../db/repos';
import { CURRENCY_CASAS, evaluateAlerts, isCurrencyCasa, parseArgentinaDatos, parseCotizaciones, parseDolarApi, type AlertHit } from '../logic/dollar';
import { addDays, todayISO } from '../lib/dates';
import type { DollarCasa, DollarRate } from '../types';

export const DOLLAR_SOURCES = {
  current: 'https://dolarapi.com/v1/dolares',
  /** Euro, real, chileno y uruguayo (cotización oficial). */
  currencies: 'https://dolarapi.com/v1/cotizaciones',
  history: (casa: DollarCasa) => (isCurrencyCasa(casa) ? `https://api.argentinadatos.com/v1/cotizaciones/${casa}` : `https://api.argentinadatos.com/v1/cotizaciones/dolares/${casa}`),
};

const HISTORY_DAYS = 120;

export async function fetchJson(url: string, timeoutMs = 12000): Promise<unknown> {
  const ctrl = typeof AbortController !== 'undefined' ? new AbortController() : null;
  const timer = ctrl ? setTimeout(() => ctrl.abort(), timeoutMs) : null;
  try {
    const res = await fetch(url, { signal: ctrl?.signal, headers: { Accept: 'application/json' } });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return await res.json();
  } finally {
    if (timer) clearTimeout(timer);
  }
}

export interface RefreshResult {
  ok: boolean;
  rates: DollarRate[];
  error?: string;
  hits: AlertHit[];
}

/** Trae la cotización actual, la guarda y evalúa las alertas de todos los perfiles. */
export async function refreshDollar(opts: { evaluate?: boolean } = {}): Promise<RefreshResult> {
  let rates: DollarRate[] = [];
  let error: string | undefined;
  try {
    rates = parseDolarApi(await fetchJson(DOLLAR_SOURCES.current));
    if (rates.length) await dollarRepo.upsertMany(rates);
    else error = 'La fuente no devolvió cotizaciones';
  } catch (e: any) {
    error = String(e?.message ?? e);
  }
  // Otras monedas: si fallan, el dólar sigue andando igual.
  try {
    const cur = parseCotizaciones(await fetchJson(DOLLAR_SOURCES.currencies));
    if (cur.length) await dollarRepo.upsertMany(cur);
  } catch {}
  const latest = await dollarRepo.latest();
  let hits: AlertHit[] = [];
  if (opts.evaluate !== false && !error) {
    const all = await dollarRepo.series('blue', addDays(todayISO(), -3), todayISO());
    const casas = await Promise.all([...DOLLAR_CASAS, ...CURRENCY_CASAS].map((c) => dollarRepo.series(c, addDays(todayISO(), -7), todayISO())));
    const recent = ([] as DollarRate[]).concat(...casas, all);
    hits = evaluateAlerts(await dollarAlertsRepo.listAll(), recent, new Date());
  }
  return { ok: !error, rates: latest, error, hits };
}

/** Carga el histórico de una casa (una vez, o si hay pocos datos) para que el gráfico arranque completo. */
export async function ensureHistory(casa: DollarCasa, minDays = 20): Promise<boolean> {
  const n = await dollarRepo.count(casa);
  if (n >= minDays) return true;
  try {
    const parsed = parseArgentinaDatos(await fetchJson(DOLLAR_SOURCES.history(casa), 20000), casa, isCurrencyCasa(casa));
    const from = addDays(todayISO(), -HISTORY_DAYS);
    const recent = parsed.filter((r) => r.date >= from);
    if (recent.length) await dollarRepo.upsertMany(recent);
    return recent.length > 0;
  } catch {
    return false;
  }
}

export async function pruneOld(): Promise<void> {
  await dollarRepo.prune(addDays(todayISO(), -(HISTORY_DAYS + 10)));
}
