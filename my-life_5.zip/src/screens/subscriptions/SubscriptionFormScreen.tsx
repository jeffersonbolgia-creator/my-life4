import React, { useEffect, useState } from 'react';
import { Alert, Pressable, View } from 'react-native';
import { useApp, useProfile, useTheme } from '../../state/AppContext';
import { Button, Card, ChipGroup, DateField, Field, FormActions, Screen, Segmented, T, ToggleRow } from '../../ui/kit';
import { Icon } from '../../ui/Icon';
import { subscriptionsRepo } from '../../db/repos';
import { SUBSCRIPTION_TEMPLATES } from '../../db/defaults';
import { CATEGORY_COLORS } from '../../theme/theme';
import { formatMoney, parseAmount } from '../../lib/money';
import { todayISO } from '../../lib/dates';
import { success, toast } from '../../ui/haptics';
import type { SubscriptionCycle } from '../../types';

const REMIND = [
  { value: -1, label: 'Sin aviso' },
  { value: 0, label: 'El día del cobro' },
  { value: 1, label: '1 día antes' },
  { value: 2, label: '2 días antes' },
  { value: 5, label: '5 días antes' },
];

export default function SubscriptionFormScreen({ navigation, route }: any) {
  const t = useTheme();
  const profile = useProfile();
  const { bump } = useApp();
  const id: number | undefined = route.params?.id;
  const [name, setName] = useState('');
  const [icon, setIcon] = useState('Receipt');
  const [color, setColor] = useState('#8B5CF6');
  const [amount, setAmount] = useState('');
  const [currency, setCurrency] = useState<'ARS' | 'USD'>('ARS');
  const [cycle, setCycle] = useState<SubscriptionCycle>('monthly');
  const [nextDate, setNextDate] = useState<string | null>(todayISO());
  const [remind, setRemind] = useState(2);
  const [active, setActive] = useState(true);
  const [category, setCategory] = useState('Otros');
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!id) return;
    subscriptionsRepo.get(profile.id, id).then((s) => {
      if (!s) return;
      setName(s.name); setIcon(s.icon); setColor(s.color); setAmount(formatMoney(s.amount, s.currency).replace(/^[^\d]+/, ''));
      setCurrency(s.currency); setCycle(s.cycle); setNextDate(s.nextDate); setRemind(s.remindDaysBefore ?? -1); setActive(s.active); setCategory(s.category || 'Otros');
    });
  }, [id, profile.id]);

  const applyTemplate = (i: number) => {
    const tpl = SUBSCRIPTION_TEMPLATES[i];
    setName(tpl.name === 'Otra' ? '' : tpl.name); setIcon(tpl.icon); setColor(tpl.color); setCategory(tpl.category); setCurrency(tpl.currency);
    setError(null);
  };

  const save = async () => {
    if (!name.trim()) return setError('Escribí el nombre del servicio');
    const cents = parseAmount(amount);
    if (!cents || cents <= 0) return Alert.alert('Importe', 'Escribí cuánto se cobra.');
    if (!nextDate) return Alert.alert('Fecha', 'Elegí la fecha del próximo cobro.');
    setSaving(true);
    const data = { name: name.trim(), icon, color, amount: cents, currency, cycle, nextDate, remindDaysBefore: remind < 0 ? null : remind, active, category };
    try {
      if (id) await subscriptionsRepo.update(profile.id, id, data);
      else await subscriptionsRepo.create(profile.id, data);
      success();
      toast('Suscripción guardada');
      bump();
      navigation.goBack();
    } catch (e: any) {
      setSaving(false);
      Alert.alert('Error', String(e?.message ?? e));
    }
  };

  const remove = () =>
    Alert.alert('Eliminar', '¿Borrar esta suscripción?', [
      { text: 'Cancelar', style: 'cancel' },
      { text: 'Eliminar', style: 'destructive', onPress: async () => { await subscriptionsRepo.remove(profile.id, id!); bump(); navigation.goBack(); } },
    ]);

  return (
    <Screen title={id ? 'Editar suscripción' : 'Nueva suscripción'} back>
      {!id ? (
        <View style={{ gap: 8 }}>
          <T variant="caption" secondary>Elegí una para cargarla rápido</T>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
            {SUBSCRIPTION_TEMPLATES.map((tpl, i) => (
              <Pressable key={tpl.name} onPress={() => applyTemplate(i)} style={{ flexDirection: 'row', alignItems: 'center', gap: 6, paddingHorizontal: 12, height: 38, borderRadius: 19, backgroundColor: name === tpl.name ? tpl.color + '2E' : t.c.surface2, borderWidth: 1, borderColor: name === tpl.name ? tpl.color : t.c.border }}>
                <Icon name={tpl.icon} size={15} color={tpl.color} />
                <T variant="caption" color={name === tpl.name ? tpl.color : t.c.textSecondary}>{tpl.name}</T>
              </Pressable>
            ))}
          </View>
        </View>
      ) : null}
      <Field label="Nombre" value={name} onChangeText={(v) => { setName(v); setError(null); }} placeholder="Ej.: Streaming de series" error={error} maxLength={50} />
      <View style={{ flexDirection: 'row', gap: 10, alignItems: 'flex-end' }}>
        <Field label="Importe" value={amount} onChangeText={setAmount} keyboardType="decimal-pad" placeholder="0" prefix={currency === 'USD' ? 'US$' : '$'} style={{ flex: 1 }} />
        <View style={{ width: 150 }}>
          <Segmented<'ARS' | 'USD'> value={currency} onChange={setCurrency} options={[{ value: 'ARS', label: 'Pesos' }, { value: 'USD', label: 'Dólares' }]} />
        </View>
      </View>
      <View style={{ gap: 8 }}>
        <T variant="caption" secondary>Se cobra</T>
        <Segmented<SubscriptionCycle> value={cycle} onChange={setCycle} options={[{ value: 'weekly', label: 'Por semana' }, { value: 'monthly', label: 'Por mes' }, { value: 'yearly', label: 'Por año' }]} />
      </View>
      <DateField label="Próximo cobro" value={nextDate} onChange={setNextDate} clearable={false} placeholder="Elegir fecha" />
      <View style={{ gap: 8 }}>
        <T variant="caption" secondary>Avisarme</T>
        <ChipGroup options={REMIND} value={remind} onChange={setRemind} />
      </View>
      <View style={{ gap: 8 }}>
        <T variant="caption" secondary>Categoría</T>
        <ChipGroup options={['Entretenimiento', 'Juegos', 'Servicios', 'Hogar', 'Salud', 'Estudio', 'Otros'].map((c) => ({ value: c, label: c }))} value={category} onChange={setCategory} />
      </View>
      <View style={{ gap: 8 }}>
        <T variant="caption" secondary>Color</T>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 10 }}>
          {CATEGORY_COLORS.map((c) => (
            <Pressable key={c} onPress={() => setColor(c)} style={{ width: 36, height: 36, borderRadius: 18, backgroundColor: c, borderWidth: 3, borderColor: color === c ? t.c.text : 'transparent', alignItems: 'center', justifyContent: 'center' }}>
              {color === c ? <Icon name="Check" size={16} color="#fff" strokeWidth={3} /> : null}
            </Pressable>
          ))}
        </View>
      </View>
      {id ? (
        <Card padding={0} style={{ paddingHorizontal: 14 }}>
          <ToggleRow icon="Pause" title="Activa" subtitle="Si la pausás, no cuenta ni avisa" value={active} onChange={setActive} />
        </Card>
      ) : null}
      <FormActions onSave={save} saving={saving} onDelete={id ? remove : undefined} />
      {!id ? <Button title="Cancelar" variant="ghost" onPress={() => navigation.goBack()} /> : null}
    </Screen>
  );
}
