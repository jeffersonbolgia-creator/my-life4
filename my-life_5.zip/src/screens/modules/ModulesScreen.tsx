import React from 'react';
import { Pressable, Switch, View } from 'react-native';
import { useApp, useProfile, useTheme } from '../../state/AppContext';
import { Badge, Card, Screen, T } from '../../ui/kit';
import { Icon } from '../../ui/Icon';
import { MODULES } from '../../modules/registry';
import { tap } from '../../ui/haptics';
import type { ModuleKey } from '../../types';

export default function ModulesScreen({ navigation }: any) {
  const t = useTheme();
  const profile = useProfile();
  const { updateSettings } = useApp();
  const modules = profile.settings.modules;

  const toggle = (key: ModuleKey, on: boolean) => {
    tap();
    updateSettings({ modules: { ...modules, [key]: on } });
  };

  const available = MODULES.filter((m) => m.available);
  const soon = MODULES.filter((m) => !m.available);

  return (
    <Screen title="Módulos" subtitle="Activá solo lo que te interesa" back>
      <T secondary>Cada perfil tiene sus propios módulos. Lo que vos actives no cambia lo de nadie más.</T>
      <View style={{ gap: 10 }}>
        {available.map((m) => {
          const on = !!modules[m.key];
          return (
            <Card key={m.key} accentBorder={on} gradient={on} padding={14}>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 14 }}>
                <Pressable onPress={() => (on ? navigation.navigate(m.route) : toggle(m.key, true))} style={{ flexDirection: 'row', alignItems: 'center', gap: 14, flex: 1 }} accessibilityLabel={m.label}>
                  <View style={{ width: 46, height: 46, borderRadius: 15, backgroundColor: m.color + (t.dark ? '24' : '1A'), alignItems: 'center', justifyContent: 'center' }}>
                    <Icon name={m.icon} size={22} color={m.color} />
                  </View>
                  <View style={{ flex: 1 }}>
                    <T variant="bodyStrong">{m.label}</T>
                    <T variant="caption" secondary numberOfLines={2}>{m.description}</T>
                    {on ? <T variant="small" color={t.accent.base} style={{ marginTop: 2 }}>Tocá para abrir</T> : null}
                  </View>
                </Pressable>
                <Switch value={on} onValueChange={(v) => toggle(m.key, v)} trackColor={{ false: t.c.surface3, true: t.accent.base }} thumbColor="#fff" />
              </View>
            </Card>
          );
        })}
      </View>

      {soon.length ? (
      <>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8, marginTop: 6 }}>
        <T variant="label" muted>Próximamente</T>
        <Badge label="En la próxima versión" />
      </View>
      <View style={{ gap: 10 }}>
        {soon.map((m) => (
          <Card key={m.key} padding={14} style={{ opacity: 0.7 }}>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 14 }}>
              <View style={{ width: 46, height: 46, borderRadius: 15, backgroundColor: t.c.surface3, alignItems: 'center', justifyContent: 'center' }}>
                <Icon name={m.icon} size={22} color={t.c.textMuted} />
              </View>
              <View style={{ flex: 1 }}>
                <T variant="bodyStrong" secondary>{m.label}</T>
                <T variant="caption" muted numberOfLines={2}>{m.description}</T>
              </View>
              <Icon name="Lock" size={18} color={t.c.textMuted} />
            </View>
          </Card>
        ))}
      </View>
      </>
      ) : null}
      <T variant="small" muted>Dólar hoy, Feed, Sueldo e inflación y Feriados usan internet solo para traer cotizaciones, publicaciones y datos públicos. Nunca se envían tus datos.</T>
    </Screen>
  );
}
