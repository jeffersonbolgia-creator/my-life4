import React, { useEffect, useState } from 'react';
import { Alert, View } from 'react-native';
import { useApp, useProfile } from '../../state/AppContext';
import { ChipGroup, DateField, Field, FormActions, Screen, T, TimeField, ToggleRow, Card } from '../../ui/kit';
import { DayPicker } from '../../ui/DayPicker';
import { eventsRepo } from '../../db/repos';
import { EVENT_TYPES, REMIND_OPTIONS } from './shared';
import type { EventType, Recurrence } from '../../types';
import { todayISO, weekday, timeToMinutes } from '../../lib/dates';
import { success, toast } from '../../ui/haptics';

const RECURRENCES: { value: Recurrence; label: string }[] = [
  { value: 'none', label: 'No se repite' },
  { value: 'daily', label: 'Cada día' },
  { value: 'weekly', label: 'Cada semana' },
  { value: 'monthly', label: 'Cada mes' },
  { value: 'yearly', label: 'Cada año' },
];

export default function EventFormScreen({ navigation, route }: any) {
  const profile = useProfile();
  const { bump } = useApp();
  const id: number | undefined = route.params?.id;
  const [title, setTitle] = useState('');
  const [type, setType] = useState<EventType>((route.params?.type as EventType) ?? 'event');
  const [date, setDate] = useState<string | null>(route.params?.date ?? todayISO());
  const [allDay, setAllDay] = useState(false);
  const [start, setStart] = useState<string | null>(null);
  const [end, setEnd] = useState<string | null>(null);
  const [recurrence, setRecurrence] = useState<Recurrence>('none');
  const [weekdays, setWeekdays] = useState<number[]>([]);
  const [until, setUntil] = useState<string | null>(null);
  const [remind, setRemind] = useState(30);
  const [location, setLocation] = useState('');
  const [notes, setNotes] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!id) return;
    eventsRepo.get(profile.id, id).then((e) => {
      if (!e) return;
      setTitle(e.title);
      setType(e.type);
      setDate(e.date);
      setAllDay(e.allDay);
      setStart(e.startTime);
      setEnd(e.endTime);
      setRecurrence(e.recurrence);
      setWeekdays(e.weekdays);
      setUntil(e.untilDate);
      setRemind(e.remindMinutes ?? -1);
      setLocation(e.location);
      setNotes(e.notes);
    });
  }, [id, profile.id]);

  const changeType = (v: EventType) => {
    setType(v);
    if (!id) {
      if (v === 'birthday') { setRecurrence('yearly'); setAllDay(true); setRemind(0); }
      if (v === 'schedule') { setRecurrence('weekly'); setAllDay(false); if (date && !weekdays.length) setWeekdays([weekday(date)]); }
    }
  };

  const save = async () => {
    if (!title.trim()) return setError(type === 'birthday' ? 'Escribí de quién es el cumpleaños' : 'Escribí un título');
    if (!date) return Alert.alert('Falta la fecha', 'Elegí una fecha para el evento.');
    if (!allDay && start && end && timeToMinutes(end) < timeToMinutes(start)) return Alert.alert('Horario', 'La hora de fin es anterior a la de inicio.');
    setSaving(true);
    const data = {
      title: title.trim(),
      type,
      date,
      startTime: allDay ? null : start,
      endTime: allDay ? null : end,
      allDay: allDay || !start,
      recurrence,
      weekdays: recurrence === 'weekly' ? (weekdays.length ? weekdays : [weekday(date)]) : [],
      untilDate: recurrence === 'none' ? null : until,
      remindMinutes: remind < 0 ? null : remind,
      location: location.trim(),
      notes: notes.trim(),
    };
    try {
      if (id) await eventsRepo.update(profile.id, id, data);
      else await eventsRepo.create(profile.id, data);
      success();
      toast('Guardado en el calendario');
      bump();
      navigation.goBack();
    } catch (e: any) {
      setSaving(false);
      Alert.alert('Error', String(e?.message ?? e));
    }
  };

  const remove = () =>
    Alert.alert('Eliminar', recurrence !== 'none' ? 'Se eliminarán todas las repeticiones de este evento.' : '¿Eliminar este evento?', [
      { text: 'Cancelar', style: 'cancel' },
      { text: 'Eliminar', style: 'destructive', onPress: async () => { await eventsRepo.remove(profile.id, id!); bump(); navigation.goBack(); } },
    ]);

  return (
    <Screen title={id ? 'Editar evento' : 'Nuevo evento'} back>
      <ChipGroup options={EVENT_TYPES.map((e) => ({ value: e.value, label: e.label, icon: e.icon, color: e.color }))} value={type} onChange={changeType} />
      <Field
        label={type === 'birthday' ? '¿De quién es el cumpleaños?' : 'Título'}
        value={title}
        onChangeText={(v) => { setTitle(v); setError(null); }}
        placeholder={type === 'birthday' ? 'Ej.: Mamá' : type === 'schedule' ? 'Ej.: Colegio, Trabajo' : type === 'appointment' ? 'Ej.: Dentista' : 'Ej.: Cumple de Sofi'}
        error={error}
        autoFocus={!id}
      />
      <DateField label={type === 'birthday' ? 'Fecha de nacimiento (o del cumpleaños)' : recurrence === 'none' ? 'Fecha' : 'Empieza el'} value={date} onChange={setDate} clearable={false} />
      {type !== 'birthday' && (
        <Card padding={0} style={{ paddingHorizontal: 14 }}>
          <ToggleRow title="Todo el día" value={allDay} onChange={setAllDay} />
        </Card>
      )}
      {!allDay && (
        <View style={{ flexDirection: 'row', gap: 10 }}>
          <TimeField label="Inicio" value={start} onChange={setStart} />
          <TimeField label="Fin" value={end} onChange={setEnd} />
        </View>
      )}
      <View style={{ gap: 8 }}>
        <T variant="caption" secondary>Repetir</T>
        <ChipGroup options={RECURRENCES} value={recurrence} onChange={setRecurrence} />
      </View>
      {recurrence === 'weekly' && (
        <View style={{ gap: 8 }}>
          <T variant="caption" secondary>Días</T>
          <DayPicker value={weekdays} onChange={setWeekdays} />
        </View>
      )}
      {recurrence !== 'none' && type !== 'birthday' && <DateField label="Hasta (opcional)" value={until} onChange={setUntil} placeholder="Sin fecha de fin" />}
      <View style={{ gap: 8 }}>
        <T variant="caption" secondary>Recordatorio</T>
        <ChipGroup options={allDay || type === 'birthday' ? [{ value: -1, label: 'Sin aviso' }, { value: 0, label: 'Avisarme ese día' }] : REMIND_OPTIONS} value={allDay || type === 'birthday' ? (remind < 0 ? -1 : 0) : remind} onChange={setRemind} />
      </View>
      {type !== 'birthday' && <Field label="Lugar (opcional)" value={location} onChangeText={setLocation} placeholder="Dirección o lugar" />}
      <Field label="Notas (opcional)" value={notes} onChangeText={setNotes} multiline />
      <FormActions onSave={save} saving={saving} onDelete={id ? remove : undefined} />
    </Screen>
  );
}
