import React from 'react';
import { Pressable, View } from 'react-native';
import { useTheme } from '../../state/AppContext';
import { Button, Card, ProgressRing, T } from '../../ui/kit';
import { Icon } from '../../ui/Icon';
import { currentStep, routineHistory, routineProgress, routineStreak, stepTimes } from '../../logic/routines';
import { tap } from '../../ui/haptics';
import type { Routine, RoutineLog } from '../../types';

export function RoutineSummary({ r, log, logs, today, onPress }: { r: Routine; log: RoutineLog | undefined; logs: Map<string, RoutineLog> | undefined; today: string; onPress?: () => void }) {
  const t = useTheme();
  const p = routineProgress(r, log);
  const streak = routineStreak(r, logs, today);
  const next = currentStep(r, log);
  return (
    <Card onPress={onPress} gradient accentBorder>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 16 }}>
        <ProgressRing value={p.pct} size={72} stroke={8} color={r.color}>
          {p.completed ? <Icon name="Check" size={26} color={r.color} strokeWidth={3} /> : <T variant="heading">{p.done}/{p.total}</T>}
        </ProgressRing>
        <View style={{ flex: 1, gap: 4 }}>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
            <Icon name={r.icon} size={16} color={r.color} />
            <T variant="heading" numberOfLines={1} style={{ flex: 1 }}>{r.title}</T>
          </View>
          <T variant="caption" secondary numberOfLines={1}>
            {p.completed ? '¡Rutina completa!' : next ? `Ahora: ${next.title}` : 'Sin pasos'}
            {r.startTime ? ` · desde las ${r.startTime}` : ''}
          </T>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 4 }}>
            <Icon name="Flame" size={13} color={streak ? '#F97316' : t.c.textMuted} />
            <T variant="small" muted>{streak} {streak === 1 ? 'día seguido' : 'días seguidos'}</T>
          </View>
        </View>
      </View>
    </Card>
  );
}

/** Lista de pasos con línea de tiempo, para marcar uno por uno. */
export function RoutineSteps({ r, log, onToggle, onAll }: { r: Routine; log: RoutineLog | undefined; onToggle: (stepId: string) => void; onAll: (done: boolean) => void }) {
  const t = useTheme();
  const times = stepTimes(r);
  const done = new Set(log?.doneSteps ?? []);
  const next = currentStep(r, log);
  const p = routineProgress(r, log);
  return (
    <View style={{ gap: 2 }}>
      {r.steps.map((s, i) => {
        const isDone = done.has(s.id);
        const isNext = next?.id === s.id;
        const last = i === r.steps.length - 1;
        return (
          <Pressable key={s.id} onPress={() => { tap(); onToggle(s.id); }} style={{ flexDirection: 'row', gap: 14 }} accessibilityRole="checkbox" accessibilityState={{ checked: isDone }}>
            <View style={{ width: 28, alignItems: 'center' }}>
              <View style={{
                width: 28, height: 28, borderRadius: 14, alignItems: 'center', justifyContent: 'center',
                backgroundColor: isDone ? t.c.success : t.c.surface, borderWidth: 2, borderColor: isDone ? t.c.success : isNext ? r.color : t.c.borderStrong,
              }}>
                {isDone ? <Icon name="Check" size={15} color="#fff" strokeWidth={3} /> : null}
              </View>
              {!last ? <View style={{ flex: 1, width: 2, backgroundColor: isDone ? t.c.success : t.c.border, minHeight: 18 }} /> : null}
            </View>
            <View style={{ flex: 1, paddingBottom: last ? 0 : 14 }}>
              <View style={{
                flexDirection: 'row', alignItems: 'center', gap: 12, padding: isNext ? 12 : 4, borderRadius: t.radius.md,
                backgroundColor: isNext ? t.c.surface : 'transparent', borderWidth: isNext ? 1 : 0, borderColor: r.color + '80',
              }}>
                <T variant="small" color={isNext ? r.color : t.c.textMuted} style={{ width: 44 }}>{times[i] ?? ''}</T>
                <View style={{ flex: 1 }}>
                  <T variant={isNext ? 'bodyStrong' : 'body'} color={isDone ? t.c.textMuted : undefined} style={isDone ? { textDecorationLine: 'line-through' } : undefined} numberOfLines={2}>{s.title}</T>
                  {s.minutes ? <T variant="small" muted>{s.minutes} min</T> : null}
                </View>
                {isNext ? <Button title="Listo" size="sm" full={false} onPress={() => onToggle(s.id)} /> : null}
              </View>
            </View>
          </Pressable>
        );
      })}
      <View style={{ flexDirection: 'row', justifyContent: 'flex-end', marginTop: 6 }}>
        <Button title={p.completed ? 'Reiniciar el día' : 'Marcar todo'} variant="ghost" size="sm" full={false} icon={p.completed ? 'RotateCcw' : 'CheckCheck'} onPress={() => onAll(!p.completed)} />
      </View>
    </View>
  );
}

/** Últimos 14 días como cuadraditos. */
export function RoutineHistory({ r, logs, today }: { r: Routine; logs: Map<string, RoutineLog> | undefined; today: string }) {
  const t = useTheme();
  const hist = routineHistory(r, logs, today, 14);
  const done = hist.filter((h) => h.state === 'done').length;
  const total = hist.filter((h) => h.state === 'done' || h.state === 'missed').length;
  return (
    <Card>
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginBottom: 10 }}>
        <T variant="bodyStrong">Últimas 2 semanas</T>
        <T variant="caption" secondary>{done} de {total} completas</T>
      </View>
      <View style={{ flexDirection: 'row', gap: 5 }}>
        {hist.map((h) => (
          <View key={h.date} style={{
            flex: 1, height: 24, borderRadius: 6,
            backgroundColor: h.state === 'done' ? t.c.success : h.state === 'missed' ? t.c.surface3 : h.state === 'today' ? t.c.success + '55' : 'transparent',
            borderWidth: h.state === 'off' || h.state === 'today' ? 1 : 0, borderColor: h.state === 'today' ? t.c.success : t.c.border, borderStyle: h.state === 'today' ? 'dashed' : 'solid',
          }} />
        ))}
      </View>
    </Card>
  );
}
