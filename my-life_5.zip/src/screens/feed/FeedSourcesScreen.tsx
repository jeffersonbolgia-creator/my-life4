import React, { useCallback, useEffect, useState } from 'react';
import { Image, Pressable, ScrollView, View } from 'react-native';
import { useApp, useProfile, useTheme } from '../../state/AppContext';
import { Button, Card, Chip, Field, Screen, SectionHeader, Sheet, T, ToggleRow } from '../../ui/kit';
import { Icon } from '../../ui/Icon';
import { feedRepo, feedSourcesRepo } from '../../db/repos';
import { FEED_KIND_DEFS, kindDef } from '../../logic/feed';
import { LEAGUES } from '../../logic/sources/espn';
import { DEFAULT_COINS } from '../../logic/sources/coingecko';
import { type SearchHit, searchArtists, searchBluesky, searchCoins, searchGames, searchPodcasts, searchShows, searchTeams, searchYouTube } from '../../services/feedService';
import { hasRawg, hasTmdb } from '../../services/keys';
import { tap, toast } from '../../ui/haptics';
import { initials } from '../../lib/text';
import type { FeedKind, FeedSource, FeedSourceKind } from '../../types';

const PLACEHOLDER: Record<FeedSourceKind, string> = {
  bluesky: 'Nombre o @usuario.bsky.social', youtube: '@canal o enlace del canal', podcast: 'Nombre del podcast', team: '', game: 'Nombre del juego', show: 'Serie o película', artist: 'Nombre del artista', coin: 'Bitcoin, Ethereum, Solana…',
};

export default function FeedSourcesScreen({ navigation, route }: any) {
  const t = useTheme();
  const profile = useProfile();
  const { updateSettings } = useApp();
  const s = profile.settings;
  const [sources, setSources] = useState<FeedSource[]>([]);
  const [adding, setAdding] = useState<FeedKind | null>(route.params?.kind && kindDef(route.params.kind).source ? route.params.kind : null);

  const load = useCallback(async () => setSources(await feedSourcesRepo.list(profile.id)), [profile.id]);
  useEffect(() => { load(); }, [load]);

  const toggleTab = (k: FeedKind, on: boolean) => {
    tap();
    updateSettings({ feed: { ...s.feed, tabs: { ...s.feed.tabs, [k]: on } } });
  };
  const remove = async (src: FeedSource) => {
    await feedSourcesRepo.remove(profile.id, src.id);
    await feedRepo.hideTopic(profile.id, src.name);
    load();
  };
  const toggleMute = async (src: FeedSource) => {
    await feedSourcesRepo.setMuted(profile.id, src.id, !src.muted);
    load();
  };

  const active = FEED_KIND_DEFS.filter((d) => s.feed.tabs[d.kind]);

  return (
    <Screen title="Tu Feed" subtitle="Pestañas e intereses" back>
      <SectionHeader title="Pestañas" />
      <T secondary>Prendé solo las que te interesan. Cada perfil tiene las suyas.</T>
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
        {FEED_KIND_DEFS.map((d) => <Chip key={d.kind} label={d.label} icon={d.icon} color={d.color} selected={!!s.feed.tabs[d.kind]} onPress={() => toggleTab(d.kind, !s.feed.tabs[d.kind])} />)}
      </View>

      <SectionHeader title="Qué seguís" />
      <Card padding={0} style={{ paddingHorizontal: 14 }}>
        <Pressable onPress={() => navigation.navigate('FeedTopics')} style={{ flexDirection: 'row', alignItems: 'center', gap: 12, paddingVertical: 13 }}>
          <View style={{ width: 36, height: 36, borderRadius: 12, backgroundColor: '#F472B622', alignItems: 'center', justifyContent: 'center' }}><Icon name="Hash" size={18} color="#F472B6" /></View>
          <View style={{ flex: 1 }}>
            <T variant="bodyStrong">Temas de noticias</T>
            <T variant="caption" secondary numberOfLines={1}>{s.discover.topics.length ? s.discover.topics.join(', ') : 'Elegí temas para Noticias y Bluesky'}</T>
          </View>
          <Icon name="ChevronRight" size={18} color={t.c.textMuted} />
        </Pressable>
      </Card>

      {active.filter((d) => d.source).map((d) => {
        const mine = sources.filter((x) => x.kind === d.source);
        const keyMissing = (d.kind === 'show' && !hasTmdb());
        return (
          <View key={d.kind} style={{ gap: 8 }}>
            <SectionHeader title={d.label} action={keyMissing ? undefined : 'Agregar'} onAction={() => setAdding(d.kind)} />
            {keyMissing ? <T variant="small" muted>Próximamente: falta cargar la clave gratuita de TMDB en la app.</T> : null}
            {d.kind === 'game' && !hasRawg() ? <T variant="small" muted>Por ahora se buscan juegos en Steam. Los lanzamientos (RAWG) se activan cuando se cargue su clave.</T> : null}
            {d.kind === 'crypto' && !mine.length ? <T variant="small" muted>Sin elegir nada se muestran {DEFAULT_COINS.map((c) => c.name).join(' y ')}.</T> : null}
            {mine.length ? (
              <Card padding={6}>
                {mine.map((src) => (
                  <View key={src.id} style={{ flexDirection: 'row', alignItems: 'center', gap: 12, padding: 8 }}>
                    <Avatarish uri={src.imageUrl} label={src.name} color={d.color} />
                    <View style={{ flex: 1 }}>
                      <T variant="bodyStrong" numberOfLines={1} color={src.muted ? t.c.textMuted : undefined}>{src.name}</T>
                      <T variant="small" muted numberOfLines={1}>{src.kind === 'bluesky' ? `@${src.externalId}` : src.kind === 'team' ? String(src.extra.leagueId ?? '').split('/').pop() : src.muted ? 'Silenciado' : d.label}</T>
                    </View>
                    <Pressable onPress={() => toggleMute(src)} hitSlop={8} accessibilityLabel={src.muted ? 'Activar' : 'Silenciar'}><Icon name={src.muted ? 'BellOff' : 'Bell'} size={18} color={src.muted ? t.c.textMuted : t.c.textSecondary} /></Pressable>
                    <Pressable onPress={() => remove(src)} hitSlop={8} accessibilityLabel="Quitar"><Icon name="Trash2" size={18} color={t.c.danger} /></Pressable>
                  </View>
                ))}
              </Card>
            ) : !keyMissing ? (
              <Card onPress={() => setAdding(d.kind)}>
                <View style={{ flexDirection: 'row', gap: 12, alignItems: 'center' }}>
                  <Icon name="Plus" size={20} color={d.color} />
                  <T secondary style={{ flex: 1 }}>Todavía no seguís ningún {d.followLabel}. Agregá uno.</T>
                </View>
              </Card>
            ) : null}
          </View>
        );
      })}

      <SectionHeader title="Opciones" />
      <Card padding={0} style={{ paddingHorizontal: 14 }}>
        <ToggleRow icon="EyeOff" title="Sin spoilers" subtitle="Tapa resultados deportivos y títulos de episodios hasta que toques" value={s.feed.spoilerFree} onChange={(v) => updateSettings({ feed: { ...s.feed, spoilerFree: v } })} />
        <ToggleRow icon="Sparkles" title={`Resumen de ${s.assistant.name}`} subtitle="Un párrafo arriba de “Para vos” con lo importante del día" value={s.feed.summary} onChange={(v) => updateSettings({ feed: { ...s.feed, summary: v } })} />
        <ToggleRow icon="Wifi" title="Solo con Wi-Fi" subtitle="En segundo plano no usa datos móviles" value={s.discover.wifiOnly} onChange={(v) => updateSettings({ discover: { ...s.discover, wifiOnly: v } })} />
      </Card>
      <T variant="small" muted>El Feed usa internet solo para traer publicaciones, videos y cotizaciones de lo que elegiste. Nunca manda lo que cargás vos. Fuentes: Bluesky, Google News, YouTube, Apple Podcasts y Music, ESPN, Steam, RAWG, TMDB y CoinGecko.</T>

      <AddSheet kind={adding} onClose={() => { setAdding(null); load(); }} />
    </Screen>
  );
}

function Avatarish({ uri, label, color }: { uri: string | null; label: string; color: string }) {
  const [broken, setBroken] = useState(false);
  if (uri && !broken) return <Image source={{ uri }} style={{ width: 38, height: 38, borderRadius: 19 }} onError={() => setBroken(true)} />;
  return <View style={{ width: 38, height: 38, borderRadius: 19, backgroundColor: color + '33', alignItems: 'center', justifyContent: 'center' }}><T variant="caption" color={color}>{initials(label)}</T></View>;
}

/** Hoja para buscar y seguir (cuenta, canal, equipo, juego...). */
function AddSheet({ kind, onClose }: { kind: FeedKind | null; onClose: () => void }) {
  const t = useTheme();
  const profile = useProfile();
  const def = kind ? kindDef(kind) : null;
  const source = def?.source ?? null;
  const [q, setQ] = useState('');
  const [league, setLeague] = useState<string>(LEAGUES[0].id);
  const [hits, setHits] = useState<SearchHit[]>([]);
  const [busy, setBusy] = useState(false);
  const [added, setAdded] = useState<Set<string>>(new Set());

  useEffect(() => {
    setQ('');
    setHits([]);
    setAdded(new Set());
    if (source === 'team') runTeams(LEAGUES[0].id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [kind]);

  const runTeams = async (lid: string) => {
    setLeague(lid);
    setBusy(true);
    setHits(await searchTeams(lid));
    setBusy(false);
  };

  useEffect(() => {
    if (!source || source === 'team') return;
    const v = q.trim();
    if (v.length < 2) { setHits([]); return; }
    const tm = setTimeout(async () => {
      setBusy(true);
      const fn = source === 'bluesky' ? searchBluesky : source === 'youtube' ? searchYouTube : source === 'podcast' ? searchPodcasts : source === 'game' ? searchGames : source === 'show' ? searchShows : source === 'artist' ? searchArtists : searchCoins;
      try { setHits(await fn(v)); } catch { setHits([]); }
      setBusy(false);
    }, 450);
    return () => clearTimeout(tm);
  }, [q, source]);

  const follow = async (h: SearchHit) => {
    if (!source) return;
    tap();
    await feedSourcesRepo.add(profile.id, { kind: source, externalId: h.externalId, name: h.name, imageUrl: h.image, extra: h.extra ?? {} });
    setAdded((s) => new Set(s).add(h.externalId));
    toast(`Siguiendo ${h.name}`);
  };

  return (
    <Sheet visible={!!kind} onClose={onClose} title={def ? `Seguir ${def.followLabel}` : ''}>
      {source === 'team' ? (
        <View style={{ gap: 12 }}>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 6 }}>
            {LEAGUES.map((l) => <Chip key={l.id} label={l.short} selected={league === l.id} onPress={() => runTeams(l.id)} />)}
          </View>
        </View>
      ) : source ? (
        <Field value={q} onChangeText={setQ} placeholder={PLACEHOLDER[source]} autoFocus returnKeyType="search" autoCapitalize="none" />
      ) : null}
      <ScrollView style={{ maxHeight: 360, marginTop: 10 }} keyboardShouldPersistTaps="handled">
        {busy ? <T variant="small" muted style={{ padding: 8 }}>Buscando…</T> : null}
        {!busy && q.trim().length >= 2 && !hits.length && source !== 'team' ? <T variant="small" muted style={{ padding: 8 }}>{source === 'youtube' ? 'No se encontró el canal. Probá con el enlace completo del canal.' : 'Sin resultados. Probá con otro nombre.'}</T> : null}
        {hits.slice(0, 40).map((h) => {
          const done = added.has(h.externalId);
          return (
            <Pressable key={h.externalId} onPress={() => !done && follow(h)} style={{ flexDirection: 'row', alignItems: 'center', gap: 12, paddingVertical: 9 }}>
              <Avatarish uri={h.image} label={h.name} color={def?.color ?? t.accent.base} />
              <View style={{ flex: 1 }}>
                <T variant="bodyStrong" numberOfLines={1}>{h.name}</T>
                <T variant="small" muted numberOfLines={1}>{h.subtitle}</T>
              </View>
              <Icon name={done ? 'Check' : 'Plus'} size={20} color={done ? t.c.success : t.accent.base} />
            </Pressable>
          );
        })}
      </ScrollView>
      <Button title="Listo" variant="secondary" onPress={onClose} style={{ marginTop: 10 }} />
    </Sheet>
  );
}
