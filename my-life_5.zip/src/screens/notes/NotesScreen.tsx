import React, { useMemo, useState } from 'react';
import { Pressable, View } from 'react-native';
import { useProfile, useTheme } from '../../state/AppContext';
import { useData } from '../../state/useData';
import { ChipGroup, EmptyState, Field, IconButton, Screen, T } from '../../ui/kit';
import { Icon } from '../../ui/Icon';
import { notesRepo } from '../../db/repos';
import { matchesSearch } from '../../lib/text';
import { formatRelativeDay } from '../../lib/dates';
import type { Note } from '../../types';

export default function NotesScreen({ navigation }: any) {
  const t = useTheme();
  useProfile();
  const [q, setQ] = useState('');
  const [cat, setCat] = useState('Todas');
  const { data: notes } = useData<Note[]>((pid) => notesRepo.list(pid), []);
  const cats = useMemo(() => ['Todas', 'Favoritas', ...new Set(notes.map((n) => n.category).filter(Boolean))], [notes]);
  const list = notes.filter((n) => {
    if (cat === 'Favoritas' && !n.favorite) return false;
    if (cat !== 'Todas' && cat !== 'Favoritas' && n.category !== cat) return false;
    return !q || matchesSearch(`${n.title} ${n.body} ${n.items.map((i) => i.text).join(' ')}`, q);
  });
  const left = list.filter((_, i) => i % 2 === 0);
  const right = list.filter((_, i) => i % 2 === 1);

  const NoteCard = ({ n }: { n: Note }) => {
    const doneItems = n.items.filter((i) => i.done).length;
    return (
      <Pressable
        onPress={() => navigation.navigate('NoteEditor', { id: n.id })}
        style={({ pressed }) => ({ backgroundColor: t.c.surface, borderRadius: t.radius.lg, borderWidth: 1, borderColor: n.favorite ? t.accentSoft : t.c.border, padding: 14, gap: 8, opacity: pressed ? 0.85 : 1 })}
      >
        <View style={{ flexDirection: 'row', alignItems: 'flex-start', gap: 6 }}>
          <T variant="bodyStrong" numberOfLines={2} style={{ flex: 1 }}>{n.title || (n.isList ? 'Lista' : 'Sin título')}</T>
          {n.favorite ? <Icon name="Star" size={14} color="#F59E0B" /> : null}
        </View>
        {n.isList ? (
          <View style={{ gap: 4 }}>
            {n.items.slice(0, 5).map((i, k) => (
              <View key={k} style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
                <Icon name={i.done ? 'SquareCheck' : 'Square'} size={13} color={i.done ? t.accent.base : t.c.textMuted} />
                <T variant="caption" secondary numberOfLines={1} style={[{ flex: 1 }, i.done ? { textDecorationLine: 'line-through' } : null]}>{i.text}</T>
              </View>
            ))}
            {n.items.length > 5 ? <T variant="small" muted>+{n.items.length - 5} más</T> : null}
            <T variant="small" color={t.accent.base}>{doneItems}/{n.items.length} completados</T>
          </View>
        ) : (
          <T variant="caption" secondary numberOfLines={6}>{n.body}</T>
        )}
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginTop: 2 }}>
          <T variant="small" muted>{formatRelativeDay(n.updatedAt.slice(0, 10))}</T>
          {n.category ? <T variant="small" muted numberOfLines={1}>{n.category}</T> : null}
        </View>
      </Pressable>
    );
  };

  return (
    <Screen
      title="Notas"
      back
      right={
        <>
          <IconButton icon="ListChecks" label="Nueva lista" onPress={() => navigation.navigate('NoteEditor', { list: true })} />
          <IconButton icon="Plus" label="Nueva nota" filled onPress={() => navigation.navigate('NoteEditor')} />
        </>
      }
    >
      <Field value={q} onChangeText={setQ} placeholder="Buscar en tus notas" right={<Icon name="Search" size={18} color={t.c.textMuted} />} />
      <ChipGroup options={cats.map((c) => ({ value: c, label: c, icon: c === 'Favoritas' ? 'Star' : undefined }))} value={cat} onChange={setCat} />
      {list.length === 0 ? (
        <EmptyState icon="NotebookPen" title={q ? 'Sin resultados' : 'Sin notas'} text={q ? 'Probá con otras palabras.' : 'Anotá ideas, listas de compras o lo que necesites recordar.'} action={q ? undefined : 'Nueva nota'} onAction={() => navigation.navigate('NoteEditor')} />
      ) : (
        <View style={{ flexDirection: 'row', gap: 10, alignItems: 'flex-start' }}>
          <View style={{ flex: 1, gap: 10 }}>{left.map((n) => <NoteCard key={n.id} n={n} />)}</View>
          <View style={{ flex: 1, gap: 10 }}>{right.map((n) => <NoteCard key={n.id} n={n} />)}</View>
        </View>
      )}
    </Screen>
  );
}
