import React, { useMemo, useState } from 'react';
import { View } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { useApp, useProfile, useTheme } from '../../state/AppContext';
import { useData } from '../../state/useData';
import { Button, Card, Chip, EmptyState, Field, Screen, SectionHeader, Sheet, Stat, T, ToggleRow } from '../../ui/kit';
import { SimpleBars } from '../../ui/charts';
import { financeRepo, remindersRepo } from '../../db/repos';
import { isTransport, transportBreakdown, transportSeries } from '../../logic/transport';
import { addDays, monthKey, MONTHS_SHORT, todayISO, formatRelativeDay } from '../../lib/dates';
import { centsToInput, formatMoney, parseAmount } from '../../lib/money';
import { toast } from '../../ui/haptics';
import { TxRow } from '../finance/FinanceScreen';
import type { Reminder, Transaction } from '../../types';

const REMINDER_TITLE = 'Recargar la SUBE / transporte';

export default function TransportScreen() {
  const t = useTheme();
  const nav = useNavigation<any>();
  const profile = useProfile();
  const { updateSettings, bump } = useApp();
  const s = profile.settings;
  const today = todayISO();
  const month = monthKey(today);
  const { data, reload } = useData<{ txs: Transaction[]; rem: Reminder | null }>(async (pid) => {
    const [txs, rems] = await Promise.all([financeRepo.list(pid), remindersRepo.list(pid)]);
    return { txs, rem: rems.find((r) => r.title === REMINDER_TITLE && !r.done) ?? null };
  }, { txs: [], rem: null });
  const [sheet, setSheet] = useState(false);
  const [day, setDay] = useState(String(s.transport.rechargeDay ?? 1));
  const [amount, setAmount] = useState(s.transport.rechargeAmount ? centsToInput(s.transport.rechargeAmount) : '');

  const series = useMemo(() => transportSeries(data.txs, month, 6), [data.txs, month]);
  const cur = series[series.length - 1];
  const prev = series[series.length - 2];
  const breakdown = useMemo(() => transportBreakdown(data.txs, month), [data.txs, month]);
  const recent = useMemo(() => data.txs.filter((x) => isTransport(x)).slice(0, 6), [data.txs]);
  const avgTrip = cur && cur.trips ? Math.round(cur.total / cur.trips) : 0;

  const saveReminder = async () => {
    const d = Number(day);
    if (!Number.isInteger(d) || d < 1 || d > 28) return toast('Elegí un día del 1 al 28');
    const amt = amount.trim() ? parseAmount(amount) : null;
    // Próxima fecha con ese día
    let date = `${month}-${String(d).padStart(2, '0')}`;
    if (date < today) { const [y, m] = month.split('-').map(Number); const nm = m === 12 ? `${y + 1}-01` : `${y}-${String(m + 1).padStart(2, '0')}`; date = `${nm}-${String(d).padStart(2, '0')}`; }
    const input = { title: REMINDER_TITLE, kind: 'payment' as const, date, time: '09:00', repeat: 'monthly' as const, amount: amt, notes: 'Recordatorio del módulo Transporte' };
    if (data.rem) await remindersRepo.update(profile.id, data.rem.id, input);
    else await remindersRepo.create(profile.id, input);
    await updateSettings({ transport: { rechargeDay: d, rechargeAmount: amt } });
    setSheet(false);
    toast('Recordatorio guardado');
    reload();
    bump();
  };
  const removeReminder = async () => {
    if (data.rem) await remindersRepo.remove(profile.id, data.rem.id);
    await updateSettings({ transport: { rechargeDay: null, rechargeAmount: null } });
    reload();
    bump();
  };

  return (
    <Screen title="Transporte" subtitle="Lo que gastás en viajes" back>
      <Card gradient accentBorder>
        <T variant="label" muted>Este mes</T>
        <T variant="display" style={{ marginTop: 4 }}>{formatMoney(cur?.total ?? 0)}</T>
        <View style={{ flexDirection: 'row', gap: 10, marginTop: 14 }}>
          <Stat label="Viajes o cargas" value={String(cur?.trips ?? 0)} icon="Bus" />
          <Stat label="Promedio por carga" value={avgTrip ? formatMoney(avgTrip) : '—'} icon="Ticket" />
          <Stat label="Mes anterior" value={formatMoney(prev?.total ?? 0)} icon="History" />
        </View>
      </Card>

      <SectionHeader title="Últimos 6 meses" />
      <Card>
        {series.some((m) => m.total > 0) ? (
          <SimpleBars values={series.map((m) => m.total / 100)} labels={series.map((m) => MONTHS_SHORT[Number(m.month.slice(5, 7)) - 1])} color={t.c.warning} />
        ) : <T secondary>Cuando cargues gastos de transporte (categoría "Transporte", o con nombres como SUBE, colectivo, Uber, nafta) van a aparecer acá.</T>}
      </Card>

      {breakdown.length ? (
        <>
          <SectionHeader title="En qué" />
          <Card padding={6}>
            {breakdown.map((b) => (
              <View key={b.label} style={{ flexDirection: 'row', alignItems: 'center', gap: 12, padding: 10 }}>
                <T style={{ flex: 1 }}>{b.label}</T>
                <T variant="bodyStrong">{formatMoney(b.total)}</T>
              </View>
            ))}
          </Card>
        </>
      ) : null}

      <SectionHeader title="Recarga" />
      <Card padding={0} style={{ paddingHorizontal: 14 }}>
        <ToggleRow icon="BellRing" title="Recordarme recargar" subtitle={s.transport.rechargeDay ? `El día ${s.transport.rechargeDay} de cada mes${s.transport.rechargeAmount ? ` · ${formatMoney(s.transport.rechargeAmount)}` : ''}${data.rem ? ` · próximo ${formatRelativeDay(data.rem.date).toLowerCase()}` : ''}` : 'Un aviso mensual para no quedarte sin saldo'} value={!!s.transport.rechargeDay} onChange={(v) => (v ? setSheet(true) : removeReminder())} />
      </Card>
      <T variant="small" muted>El saldo de la SUBE no se puede leer desde otra app: por eso te recordamos recargar y llevamos la cuenta de lo que gastás.</T>

      <View style={{ flexDirection: 'row', gap: 10 }}>
        <Button title="Cargar viaje" icon="Plus" style={{ flex: 1 }} onPress={() => nav.navigate('TxForm', { kind: 'expense', prefill: { name: 'SUBE', category: 'Transporte', amount: s.transport.rechargeAmount ?? 0, date: today } })} />
      </View>

      <SectionHeader title="Últimos viajes" />
      {recent.length ? (
        <Card padding={2}>
          {recent.map((tx, i) => (
            <View key={tx.id} style={i ? { borderTopWidth: 1, borderTopColor: t.c.border } : undefined}>
              <TxRow tx={tx} onPress={() => nav.navigate('TxForm', { id: tx.id })} />
            </View>
          ))}
        </Card>
      ) : <Card><EmptyState icon="Bus" title="Sin viajes cargados" text="Cargá tu primera recarga o viaje." /></Card>}

      <Sheet visible={sheet} onClose={() => setSheet(false)} title="Recordatorio de recarga">
        <View style={{ gap: 14 }}>
          <T secondary>¿Qué día del mes querés el aviso?</T>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 6 }}>
            {[1, 5, 10, 15, 20, 25].map((d) => <Chip key={d} label={`Día ${d}`} selected={day === String(d)} onPress={() => setDay(String(d))} />)}
          </View>
          <Field label="Otro día (1 a 28)" value={day} onChangeText={setDay} keyboardType="number-pad" />
          <Field label="Cuánto solés cargar (opcional)" value={amount} onChangeText={setAmount} keyboardType="decimal-pad" prefix="$" placeholder="0" />
          <Button title="Guardar" icon="Check" onPress={saveReminder} />
        </View>
      </Sheet>
    </Screen>
  );
}
