import React, { useMemo, useState } from 'react';
import { Image, Pressable, View } from 'react-native';
import { useApp, useProfile, useTheme } from '../../state/AppContext';
import { useData } from '../../state/useData';
import { Card, Chip, EmptyState, IconButton, Screen, SectionHeader, T } from '../../ui/kit';
import { Icon } from '../../ui/Icon';
import { watchlistRepo } from '../../db/repos';
import { STATUS_LABELS, WATCH_KIND_LABELS } from '../../logic/watchlist';
import { formatRelativeDay, todayISO } from '../../lib/dates';
import { tap } from '../../ui/haptics';
import type { WatchItem, WatchKind, WatchStatus } from '../../types';

export function WatchRow({ w, onPress, onToggle }: { w: WatchItem; onPress: () => void; onToggle: () => void }) {
  const t = useTheme();
  const k = WATCH_KIND_LABELS[w.kind];
  const today = todayISO();
  return (
    <Pressable onPress={onPress} style={{ flexDirection: 'row', alignItems: 'center', gap: 12, padding: 10 }}>
      {w.imageUrl ? <Image source={{ uri: w.imageUrl }} style={{ width: 46, height: 62, borderRadius: 10, backgroundColor: t.c.surface2 }} /> : (
        <View style={{ width: 46, height: 62, borderRadius: 10, backgroundColor: k.color + '22', alignItems: 'center', justifyContent: 'center' }}><Icon name={k.icon} size={22} color={k.color} /></View>
      )}
      <View style={{ flex: 1, gap: 2 }}>
        <T variant="bodyStrong" numberOfLines={1} style={w.status === 'done' ? { textDecorationLine: 'line-through', opacity: 0.7 } : undefined}>{w.title}</T>
        <T variant="small" muted numberOfLines={1}>{k.one}{w.genres.length ? ` · ${w.genres.slice(0, 2).join(', ')}` : ''}{w.nextDate ? ` · ${w.nextDate >= today ? (w.kind === 'show' ? 'episodio ' : 'sale ') + formatRelativeDay(w.nextDate).toLowerCase() : ''}` : ''}</T>
        {w.rating ? <T variant="small" color={t.c.warning}>{'★'.repeat(w.rating)}{'☆'.repeat(5 - w.rating)}</T> : null}
      </View>
      <Pressable onPress={onToggle} hitSlop={8} accessibilityLabel={w.status === 'done' ? 'Volver a pendiente' : 'Marcar terminado'} style={{ width: 34, height: 34, borderRadius: 17, borderWidth: 2, borderColor: w.status === 'done' ? t.c.success : t.c.borderStrong, backgroundColor: w.status === 'done' ? t.c.success : 'transparent', alignItems: 'center', justifyContent: 'center' }}>
        {w.status === 'done' ? <Icon name="Check" size={18} color="#fff" /> : null}
      </Pressable>
    </Pressable>
  );
}

export default function WatchlistScreen({ navigation }: any) {
  const t = useTheme();
  const profile = useProfile();
  const { bump } = useApp();
  const { data: items, reload } = useData<WatchItem[]>((pid) => watchlistRepo.list(pid), []);
  const [kind, setKind] = useState<WatchKind | 'all'>('all');
  const filtered = useMemo(() => (kind === 'all' ? items : items.filter((i) => i.kind === kind)), [items, kind]);
  const groups: WatchStatus[] = ['current', 'pending', 'done'];

  const toggle = async (w: WatchItem) => {
    tap();
    await watchlistRepo.update(profile.id, w.id, { status: w.status === 'done' ? 'pending' : 'done' });
    reload();
    bump();
  };

  return (
    <Screen title="Pendientes" subtitle="Juegos, series y películas por ver" back right={<IconButton icon="Plus" label="Agregar" filled onPress={() => navigation.navigate('WatchForm')} />}>
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
        <Chip label="Todo" selected={kind === 'all'} onPress={() => setKind('all')} />
        {(Object.keys(WATCH_KIND_LABELS) as WatchKind[]).map((k) => <Chip key={k} label={WATCH_KIND_LABELS[k].many} icon={WATCH_KIND_LABELS[k].icon} color={WATCH_KIND_LABELS[k].color} selected={kind === k} onPress={() => setKind(k)} />)}
      </View>
      {!items.length ? (
        <EmptyState icon="ListVideo" title="Tu lista está vacía" text="Anotá lo que querés ver o jugar. Después le ponés puntaje y Nova te recomienda según tus gustos." action="Agregar el primero" onAction={() => navigation.navigate('WatchForm')} />
      ) : groups.map((g) => {
        const mine = filtered.filter((i) => i.status === g);
        if (!mine.length) return null;
        return (
          <View key={g} style={{ gap: 8 }}>
            <SectionHeader title={`${STATUS_LABELS[g]} (${mine.length})`} />
            <Card padding={4}>
              {mine.map((w, i) => (
                <View key={w.id} style={i ? { borderTopWidth: 1, borderTopColor: t.c.border } : undefined}>
                  <WatchRow w={w} onPress={() => navigation.navigate('WatchForm', { id: w.id })} onToggle={() => toggle(w)} />
                </View>
              ))}
            </Card>
          </View>
        );
      })}
      <T variant="small" muted>Desde el Feed podés tocar los tres puntos de una serie o un juego y mandarlo acá con un toque.</T>
    </Screen>
  );
}
