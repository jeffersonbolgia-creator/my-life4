import React, { useEffect, useState } from 'react';
import { Alert, Pressable, View } from 'react-native';
import { useApp, useProfile, useTheme } from '../../state/AppContext';
import { Chip, ChipGroup, Field, FormActions, Screen, Segmented, T } from '../../ui/kit';
import { Icon } from '../../ui/Icon';
import { watchlistRepo } from '../../db/repos';
import { STATUS_LABELS, WATCH_KIND_LABELS } from '../../logic/watchlist';
import { success, toast } from '../../ui/haptics';
import type { WatchKind, WatchStatus } from '../../types';

const GENRES: Record<WatchKind, string[]> = {
  show: ['Acción', 'Comedia', 'Drama', 'Terror', 'Suspenso', 'Ciencia ficción', 'Fantasía', 'Romance', 'Animación', 'Crimen', 'Documental', 'Anime'],
  movie: ['Acción', 'Comedia', 'Drama', 'Terror', 'Suspenso', 'Ciencia ficción', 'Fantasía', 'Romance', 'Animación', 'Crimen', 'Documental', 'Aventura'],
  game: ['Acción', 'Aventura', 'RPG', 'Shooter', 'Deportes', 'Estrategia', 'Carreras', 'Terror', 'Indie', 'Mundo abierto', 'Pelea', 'Simulación'],
};

export default function WatchFormScreen({ navigation, route }: any) {
  const t = useTheme();
  const profile = useProfile();
  const { bump } = useApp();
  const id: number | undefined = route.params?.id;
  const [kind, setKind] = useState<WatchKind>(route.params?.kind ?? 'show');
  const [title, setTitle] = useState('');
  const [status, setStatus] = useState<WatchStatus>('pending');
  const [rating, setRating] = useState<number | null>(null);
  const [genres, setGenres] = useState<string[]>([]);
  const [notes, setNotes] = useState('');
  const [imageUrl, setImageUrl] = useState<string | null>(null);
  const [externalId, setExternalId] = useState<string | null>(null);
  const [nextDate, setNextDate] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!id) return;
    watchlistRepo.get(profile.id, id).then((w) => {
      if (!w) return;
      setKind(w.kind); setTitle(w.title); setStatus(w.status); setRating(w.rating); setGenres(w.genres); setNotes(w.notes); setImageUrl(w.imageUrl); setExternalId(w.externalId); setNextDate(w.nextDate);
    });
  }, [id, profile.id]);

  const save = async () => {
    if (!title.trim()) return toast('Escribí el título');
    setSaving(true);
    try {
      const data = { kind, title, status, rating, genres, notes: notes.trim(), imageUrl, externalId, nextDate };
      if (id) await watchlistRepo.update(profile.id, id, data);
      else await watchlistRepo.create(profile.id, data);
      success();
      bump();
      navigation.goBack();
    } catch (e: any) {
      setSaving(false);
      Alert.alert('Error', String(e?.message ?? e));
    }
  };
  const remove = () => Alert.alert('Quitar de la lista', `¿Sacar "${title}"?`, [{ text: 'Cancelar', style: 'cancel' }, { text: 'Quitar', style: 'destructive', onPress: async () => { await watchlistRepo.remove(profile.id, id!); bump(); navigation.goBack(); } }]);

  return (
    <Screen title={id ? 'Editar' : 'Nuevo pendiente'} back>
      <Segmented<WatchKind> value={kind} onChange={(k) => { setKind(k); setGenres([]); }} options={(Object.keys(WATCH_KIND_LABELS) as WatchKind[]).map((k) => ({ value: k, label: WATCH_KIND_LABELS[k].one }))} />
      <Field label="Título" value={title} onChangeText={setTitle} placeholder={kind === 'game' ? 'Ej.: GTA VI' : kind === 'show' ? 'Ej.: The Bear' : 'Ej.: Dune'} autoFocus={!id} maxLength={120} />
      <View style={{ gap: 8 }}>
        <T variant="caption" secondary>Estado</T>
        <Segmented<WatchStatus> value={status} onChange={setStatus} options={(['pending', 'current', 'done'] as WatchStatus[]).map((s) => ({ value: s, label: STATUS_LABELS[s] }))} />
      </View>
      <View style={{ gap: 8 }}>
        <T variant="caption" secondary>Tu puntaje {status !== 'done' ? '(cuando lo termines)' : ''}</T>
        <View style={{ flexDirection: 'row', gap: 6 }}>
          {[1, 2, 3, 4, 5].map((n) => (
            <Pressable key={n} onPress={() => setRating(rating === n ? null : n)} hitSlop={6} accessibilityLabel={`${n} estrellas`}>
              <Icon name="Star" size={32} color={rating != null && n <= rating ? t.c.warning : t.c.borderStrong} />
            </Pressable>
          ))}
        </View>
        <T variant="small" muted>Con tus puntajes, {profile.settings.assistant.name} aprende qué te gusta para recomendarte.</T>
      </View>
      <View style={{ gap: 8 }}>
        <T variant="caption" secondary>Género (podés marcar varios)</T>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
          {[...new Set([...GENRES[kind], ...genres])].map((g) => <Chip key={g} label={g} selected={genres.includes(g)} onPress={() => setGenres((gs) => (gs.includes(g) ? gs.filter((x) => x !== g) : [...gs, g]))} />)}
        </View>
      </View>
      <Field label="Notas (opcional)" value={notes} onChangeText={setNotes} multiline placeholder="Quién te lo recomendó, en qué plataforma está…" />
      <FormActions onSave={save} saving={saving} onDelete={id ? remove : undefined} />
    </Screen>
  );
}
