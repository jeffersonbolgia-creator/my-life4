import React, { useMemo, useState } from 'react';
import { Alert, View } from 'react-native';
import { useApp, useProfile, useTheme } from '../../state/AppContext';
import { useData } from '../../state/useData';
import { Card, ChipGroup, EmptyState, Field, IconButton, Screen, SectionHeader, Segmented, T } from '../../ui/kit';
import { Icon } from '../../ui/Icon';
import { financeRepo } from '../../db/repos';
import { formatMonthYear, formatRelativeDay, monthKey, todayISO, addMonthsToKey } from '../../lib/dates';
import { matchesSearch } from '../../lib/text';
import { formatMoney } from '../../lib/money';
import { sumBy } from '../../logic/finance';
import { TxRow } from './FinanceScreen';
import { exportFinanceCsv } from '../../services/files';
import type { Transaction } from '../../types';

export default function FinanceHistoryScreen({ navigation, route }: any) {
  const t = useTheme();
  const profile = useProfile();
  const { bump, suspendAutoLock } = useApp();
  const [month, setMonth] = useState<string | 'all'>(route.params?.month ?? monthKey(todayISO()));
  const [kind, setKind] = useState<'all' | 'income' | 'expense'>('all');
  const [q, setQ] = useState('');
  const [cat, setCat] = useState('Todas');
  const { data: txs } = useData<Transaction[]>((pid) => financeRepo.list(pid), []);

  const cats = useMemo(() => ['Todas', ...new Set(txs.map((x) => x.category))], [txs]);
  const list = txs.filter((x) =>
    (month === 'all' || monthKey(x.date) === month) &&
    (kind === 'all' || x.kind === kind) &&
    (cat === 'Todas' || x.category === cat) &&
    (!q || matchesSearch(`${x.name} ${x.description} ${x.category}`, q)),
  );
  const groups = useMemo(() => {
    const m = new Map<string, Transaction[]>();
    for (const x of list) {
      if (!m.has(x.date)) m.set(x.date, []);
      m.get(x.date)!.push(x);
    }
    return [...m.entries()];
  }, [list]);

  const remove = (tx: Transaction) =>
    Alert.alert('Eliminar', `¿Eliminar "${tx.name}"?`, [
      { text: 'Cancelar', style: 'cancel' },
      { text: 'Eliminar', style: 'destructive', onPress: async () => { await financeRepo.remove(profile.id, tx.id); bump(); } },
    ]);

  const exportCsv = async () => {
    suspendAutoLock();
    const ok = await exportFinanceCsv(list, `movimientos-${month === 'all' ? 'todos' : month}`);
    if (!ok) Alert.alert('Exportar', 'No se pudo compartir el archivo en este dispositivo.');
  };

  const monthOptions = useMemo(() => {
    const cur = monthKey(todayISO());
    return [{ value: 'all', label: 'Todo' }, ...Array.from({ length: 6 }, (_, i) => {
      const k = addMonthsToKey(cur, -i);
      return { value: k, label: formatMonthYear(k).split(' ')[0] };
    })];
  }, []);

  return (
    <Screen title="Historial" back right={<IconButton icon="Download" label="Exportar CSV" onPress={exportCsv} />}>
      <Field value={q} onChangeText={setQ} placeholder="Buscar movimientos" right={<Icon name="Search" size={18} color={t.c.textMuted} />} />
      <Segmented value={kind} onChange={setKind} options={[{ value: 'all', label: 'Todos' }, { value: 'expense', label: 'Gastos' }, { value: 'income', label: 'Ingresos' }]} />
      <ChipGroup options={monthOptions} value={month} onChange={setMonth} />
      {cats.length > 2 && <ChipGroup options={cats.map((c) => ({ value: c, label: c }))} value={cat} onChange={setCat} />}
      <Card>
        <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
          <View>
            <T variant="small" secondary>Ingresos</T>
            <T variant="bodyStrong" color={t.c.success}>{formatMoney(sumBy(list, 'income'))}</T>
          </View>
          <View style={{ alignItems: 'flex-end' }}>
            <T variant="small" secondary>Gastos</T>
            <T variant="bodyStrong" color={t.c.danger}>{formatMoney(sumBy(list, 'expense'))}</T>
          </View>
        </View>
      </Card>
      {groups.length === 0 ? (
        <EmptyState icon="Receipt" title="No hay movimientos" text="Probá cambiar los filtros." />
      ) : groups.map(([date, items]) => (
        <View key={date} style={{ gap: 8 }}>
          <SectionHeader title={formatRelativeDay(date)} />
          <Card padding={2}>
            {items.map((tx, i) => (
              <View key={tx.id} style={i ? { borderTopWidth: 1, borderTopColor: t.c.border } : undefined}>
                <TxRow tx={tx} onPress={() => navigation.navigate('TxForm', { id: tx.id })} onLongPress={() => remove(tx)} />
              </View>
            ))}
          </Card>
        </View>
      ))}
    </Screen>
  );
}
