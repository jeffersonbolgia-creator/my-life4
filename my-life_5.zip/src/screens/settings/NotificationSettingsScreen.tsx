import React, { useCallback, useState } from 'react';
import { Alert, Platform, Pressable, View } from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { useApp, useProfile, useTheme } from '../../state/AppContext';
import { Button, Card, Chip, Group, Row, Screen, SectionHeader, T, TimeField, ToggleRow } from '../../ui/kit';
import { Icon } from '../../ui/Icon';
import {
  countScheduled, getPermission, openBatterySettings, openExactAlarmSettings, openSystemNotificationSettings, requestPermission, sendTestNotification, syncProfileNotifications, type PermissionState,
} from '../../notifications/notifications';
import { ALARM_SOUND_LABELS, ALARM_TYPE_LABELS } from '../../logic/alarms';
import { ALARM_SOUNDS, ALARM_TYPES } from '../../db/defaults';
import type { AlarmPrefs, AlarmSound, AlarmType, NotificationSettings } from '../../types';
import { tap, toast } from '../../ui/haptics';

export default function NotificationSettingsScreen() {
  const t = useTheme();
  const profile = useProfile();
  const { updateSettings, suspendAutoLock } = useApp();
  const n = profile.settings.notifications;
  const [perm, setPerm] = useState<PermissionState>('undetermined');
  const [count, setCount] = useState<number | null>(null);
  const [testSound, setTestSound] = useState<AlarmSound>(n.alarms.reminders.sound);

  const refresh = useCallback(() => {
    getPermission().then(setPerm);
    countScheduled(profile.id).then(setCount).catch(() => setCount(null));
  }, [profile.id]);
  useFocusEffect(refresh);

  const set = async (patch: Partial<NotificationSettings>) => {
    await updateSettings({ notifications: { ...n, ...patch } });
    setTimeout(refresh, 2000);
  };
  const setAlarm = async (type: AlarmType, patch: Partial<AlarmPrefs>) => {
    const wasOff = !Object.values(n.alarms).some((a) => a.alarm);
    await set({ alarms: { ...n.alarms, [type]: { ...n.alarms[type], ...patch } } });
    // La primera vez que se prende una alarma: guiar los permisos que Android pide aparte
    if (patch.alarm && wasOff && Platform.OS === 'android') {
      Alert.alert('Para que suene a tiempo', 'Android puede retrasar o apagar alarmas para ahorrar batería. Conviene permitir las alarmas exactas y sacar a MY LIFE de la optimización de batería.', [
        { text: 'Después', style: 'cancel' },
        { text: 'Alarmas exactas', onPress: () => { suspendAutoLock(); openExactAlarmSettings(); } },
        { text: 'Batería', onPress: () => { suspendAutoLock(); openBatterySettings(); } },
      ]);
    }
  };

  const ask = async () => {
    suspendAutoLock(30_000);
    const r = await requestPermission();
    setPerm(r);
    if (r === 'granted') {
      await syncProfileNotifications(profile.id);
      refresh();
    } else {
      Alert.alert('Permiso necesario', 'Para recibir avisos tenés que permitir las notificaciones de MY LIFE en los ajustes del teléfono.', [
        { text: 'Ahora no', style: 'cancel' },
        { text: 'Abrir ajustes', onPress: () => { suspendAutoLock(); openSystemNotificationSettings(); } },
      ]);
    }
  };

  const test = async (asAlarm: boolean) => {
    const ok = await sendTestNotification(profile.name.split(' ')[0], testSound, asAlarm);
    toast(ok ? (asAlarm ? 'En 5 segundos suena la alarma. Subí el volumen de alarma y bloqueá el celular.' : 'Te llegará una notificación en 5 segundos') : 'Primero permití las notificaciones');
  };

  return (
    <Screen title="Notificaciones" back>
      {perm !== 'granted' && (
        <Card accentBorder>
          <View style={{ flexDirection: 'row', gap: 12 }}>
            <Icon name="BellOff" size={22} color={t.c.warning} />
            <View style={{ flex: 1, gap: 6 }}>
              <T variant="bodyStrong">Las notificaciones están bloqueadas</T>
              <T variant="caption" secondary>MY LIFE necesita tu permiso para avisarte de tareas, eventos, hábitos y pagos aunque la app esté cerrada. No usa internet ni comparte nada.</T>
            </View>
          </View>
          <Button title="Permitir notificaciones" icon="Bell" style={{ marginTop: 14 }} onPress={ask} />
        </Card>
      )}

      <Group>
        <ToggleRow icon="Bell" title="Notificaciones de MY LIFE" subtitle="Activa o desactiva todos los avisos de tu perfil" value={n.enabled} onChange={(v) => set({ enabled: v })} />
      </Group>

      <SectionHeader title="Tipos de aviso" />
      <Group>
        <ToggleRow icon="CircleCheck" title="Tareas" subtitle="Según el aviso de cada tarea" value={n.tasks} disabled={!n.enabled} onChange={(v) => set({ tasks: v })} />
        <ToggleRow icon="CalendarDays" title="Eventos y cumpleaños" value={n.events} disabled={!n.enabled} onChange={(v) => set({ events: v })} />
        <ToggleRow icon="Repeat" title="Hábitos" subtitle="A la hora configurada en cada hábito" value={n.habits} disabled={!n.enabled} onChange={(v) => set({ habits: v })} />
        <ToggleRow icon="Receipt" title="Pagos" value={n.payments} disabled={!n.enabled} onChange={(v) => set({ payments: v })} />
        <ToggleRow icon="BellRing" title="Recordatorios" value={n.reminders} disabled={!n.enabled} onChange={(v) => set({ reminders: v })} />
        <ToggleRow icon="Target" title="Objetivos" subtitle="3 días antes y el día de la fecha límite" value={n.goals} disabled={!n.enabled} onChange={(v) => set({ goals: v })} />
        <ToggleRow icon="Sunrise" title="Resumen diario" subtitle="Un aviso por la mañana para revisar tu día" value={n.dailySummary} disabled={!n.enabled} onChange={(v) => set({ dailySummary: v })} />
        <ToggleRow icon="Tv" title="Episodios nuevos" subtitle="Aviso silencioso cuando sale un capítulo de una serie pendiente" value={n.episodes} disabled={!n.enabled} onChange={(v) => set({ episodes: v })} />
      </Group>

      <SectionHeader title="Alarmas" />
      <T variant="caption" secondary>Un aviso con alarma suena fuerte aunque el celular esté en silencio o en “No molestar”, y se puede repetir hasta que lo apagues (tope 5 minutos). Lo apagás con “Listo” o lo posponés 10 minutos. Usa el volumen de alarma del teléfono (el mismo del despertador): si está en cero, no se escucha.</T>
      {ALARM_TYPES.map((type) => {
        const a = n.alarms[type];
        const def = ALARM_TYPE_LABELS[type];
        return (
          <Card key={type} padding={0} style={{ paddingHorizontal: 14, paddingBottom: a.alarm ? 12 : 0 }}>
            <ToggleRow icon={def.icon} title={def.label} subtitle={a.alarm ? `Alarma · ${ALARM_SOUND_LABELS[a.sound]}${a.repeat ? ' · se repite' : ''}` : `Aviso normal · ${def.hint}`} value={a.alarm} disabled={!n.enabled} onChange={(v) => setAlarm(type, { alarm: v })} />
            {a.alarm ? (
              <View style={{ gap: 10 }}>
                <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 6 }}>
                  {ALARM_SOUNDS.map((snd) => <Chip key={snd} label={ALARM_SOUND_LABELS[snd]} icon="Music" selected={a.sound === snd} onPress={() => setAlarm(type, { sound: snd })} />)}
                </View>
                <Pressable onPress={() => { tap(); setAlarm(type, { repeat: !a.repeat }); }} style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }} accessibilityRole="checkbox" accessibilityState={{ checked: a.repeat }}>
                  <View style={{ width: 22, height: 22, borderRadius: 7, borderWidth: 2, borderColor: a.repeat ? t.accent.base : t.c.borderStrong, backgroundColor: a.repeat ? t.accent.base : 'transparent', alignItems: 'center', justifyContent: 'center' }}>
                    {a.repeat ? <Icon name="Check" size={14} color="#fff" /> : null}
                  </View>
                  <T variant="caption">Repetir hasta que la apague</T>
                </Pressable>
              </View>
            ) : null}
          </Card>
        );
      })}

      <SectionHeader title="Probar" />
      <Card>
        <T variant="caption" secondary>Elegí un sonido y probalo. Suena a los 5 segundos: bloqueá el celular para ver cómo llega.</T>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 6, marginTop: 10 }}>
          {ALARM_SOUNDS.map((snd) => <Chip key={snd} label={ALARM_SOUND_LABELS[snd]} selected={testSound === snd} onPress={() => setTestSound(snd)} />)}
        </View>
        <View style={{ flexDirection: 'row', gap: 10, marginTop: 12 }}>
          <Button title="Probar alarma" icon="BellRing" style={{ flex: 1 }} onPress={() => test(true)} />
          <Button title="Aviso normal" icon="Bell" variant="secondary" style={{ flex: 1 }} onPress={() => test(false)} />
        </View>
      </Card>

      <SectionHeader title="Horarios" />
      <View style={{ gap: 12 }}>
        {n.dailySummary && <TimeField label="Hora del resumen diario" value={n.dailySummaryTime} onChange={(v) => v && set({ dailySummaryTime: v })} clearable={false} />}
        <TimeField label="Hora para avisos sin horario (tareas con sólo fecha, cumpleaños, objetivos)" value={n.defaultTime} onChange={(v) => v && set({ defaultTime: v })} clearable={false} />
      </View>

      <SectionHeader title="Privacidad" />
      <Group>
        <ToggleRow icon="EyeOff" title="Avisos discretos" subtitle="Muestra “Tenés un aviso nuevo” sin el detalle, para que nadie más lo lea" value={n.discreet} onChange={(v) => set({ discreet: v })} />
      </Group>

      <SectionHeader title="Si no suenan a tiempo" />
      <Group>
        {Platform.OS === 'android' && <Row icon="BatteryCharging" title="Optimización de batería" subtitle="En Motorola y Samsung conviene excluir MY LIFE para que las alarmas lleguen a tiempo" chevron onPress={() => { suspendAutoLock(); openBatterySettings(); }} />}
        {Platform.OS === 'android' && <Row icon="AlarmClock" title="Alarmas exactas" subtitle="Permiso de Android para avisar a la hora justa" chevron onPress={() => { suspendAutoLock(); openExactAlarmSettings(); }} />}
        <Row icon="Settings2" title="Ajustes del sistema" subtitle="Sonido, vibración y canales de notificación" chevron onPress={() => { suspendAutoLock(); openSystemNotificationSettings(); }} />
      </Group>
      <T variant="small" muted align="center">
        {count != null && perm === 'granted' ? `${count} avisos programados para tu perfil.` : ''}
      </T>
    </Screen>
  );
}
