import React from 'react';
import { View } from 'react-native';
import Constants from 'expo-constants';
import { useTheme } from '../../state/AppContext';
import { Card, Screen, T } from '../../ui/kit';
import { LogoMark } from '../../ui/Logo';

export default function AboutScreen() {
  const t = useTheme();
  const version = Constants.expoConfig?.version ?? '1.0.0';
  return (
    <Screen title="Acerca de" back>
      <View style={{ alignItems: 'center', gap: 12, paddingVertical: 18 }}>
        <LogoMark size={76} from={t.accent.deep} to={t.accent.light} />
        <T variant="title" style={{ letterSpacing: 4 }}>MY LIFE</T>
        <T secondary>Versión {version}</T>
      </View>
      <Card>
        <View style={{ gap: 10 }}>
          <T variant="bodyStrong">Tu organizador personal</T>
          <T variant="caption" secondary>Tareas, calendario, objetivos, hábitos, notas, finanzas, Feed, dólar y más, con perfiles privados protegidos por PIN.</T>
        </View>
      </Card>
      <Card>
        <View style={{ gap: 8 }}>
          <T variant="bodyStrong">Privacidad</T>
          <T variant="caption" secondary>• Todo se guarda sólo en este teléfono, en una base de datos local.</T>
          <T variant="caption" secondary>• No necesita cuentas. No hay publicidad ni seguimiento. Internet se usa solo para traer cotizaciones, feriados, inflación y lo que elegís seguir en el Feed; nunca se envía lo que cargás.</T>
          <T variant="caption" secondary>• Las notificaciones son locales: las programa el propio teléfono.</T>
          <T variant="caption" secondary>• Los PIN se guardan cifrados en el almacenamiento seguro de Android.</T>
        </View>
      </Card>
      <Card>
        <View style={{ gap: 8 }}>
          <T variant="bodyStrong">Fuentes de datos</T>
          <T variant="caption" secondary>• Dólar y monedas: DolarAPI y ArgentinaDatos. Inflación y feriados: ArgentinaDatos.</T>
          <T variant="caption" secondary>• Feed: publicaciones de Bluesky, titulares de Google News, videos de YouTube, podcasts y música vía Apple, resultados de ESPN, precios de Steam, lanzamientos de RAWG.</T>
          <T variant="caption" secondary>• Series y películas: este producto usa la API de TMDB pero no está avalado ni certificado por TMDB.</T>
          <T variant="caption" secondary>• Criptomonedas: datos de CoinGecko.</T>
          <T variant="caption" secondary>• Las fuentes son de terceros y pueden cambiar; si una deja de responder, la pestaña avisa y el resto sigue funcionando.</T>
        </View>
      </Card>
      <T variant="small" muted align="center">Hecho con React Native y Expo · Íconos Lucide · Tipografía Inter</T>
    </Screen>
  );
}
