import React, { useState } from 'react';
import { Alert, Platform, View } from 'react-native';
import { useApp, useProfile, useTheme } from '../../state/AppContext';
import { Card, Group, Row, Screen, SectionHeader, T } from '../../ui/kit';
import { Icon } from '../../ui/Icon';
import { backupAndShare, backupToFolder, exportFinanceCsv, pickAndRestore } from '../../services/files';
import { financeRepo } from '../../db/repos';
import { success, toast } from '../../ui/haptics';

export default function BackupScreen() {
  const t = useTheme();
  const profile = useProfile();
  const { bump, refreshProfiles, suspendAutoLock } = useApp();
  const [busy, setBusy] = useState(false);

  const run = async (fn: () => Promise<void>) => {
    if (busy) return;
    setBusy(true);
    suspendAutoLock();
    try {
      await fn();
    } catch (e: any) {
      Alert.alert('No se pudo completar', String(e?.message ?? e));
    } finally {
      setBusy(false);
    }
  };

  const saveLocal = () => run(async () => {
    const r = await backupToFolder(profile.id, profile.name);
    if (r === 'saved') { success(); toast('Copia guardada'); }
  });

  const share = () => run(async () => {
    const ok = await backupAndShare(profile.id, profile.name);
    if (!ok) Alert.alert('Compartir', 'Este teléfono no permite compartir archivos.');
  });

  const csv = () => run(async () => {
    const txs = await financeRepo.list(profile.id);
    await exportFinanceCsv(txs, 'mylife-finanzas');
  });

  const restore = () =>
    Alert.alert(
      'Restaurar copia',
      'Se reemplazarán TODOS los datos actuales de tu perfil (tareas, finanzas, notas, hábitos, objetivos, eventos y recordatorios) por los de la copia. Tu PIN no cambia.',
      [
        { text: 'Cancelar', style: 'cancel' },
        {
          text: 'Elegir archivo',
          style: 'destructive',
          onPress: () => run(async () => {
            const r = await pickAndRestore(profile.id, true);
            if (r) {
              await refreshProfiles();
              bump();
              success();
              Alert.alert('Copia restaurada', `Se restauraron ${r.total} elementos.`);
            }
          }),
        },
      ],
    );

  return (
    <Screen title="Copias de seguridad" back>
      <Card>
        <View style={{ flexDirection: 'row', gap: 12 }}>
          <Icon name="ShieldCheck" size={22} color={t.accent.base} />
          <View style={{ flex: 1, gap: 6 }}>
            <T variant="bodyStrong">Tus datos viven en este teléfono</T>
            <T variant="caption" secondary>
              MY LIFE funciona sin internet y no sube nada a ningún servidor. Si cambiás o reseteás el teléfono, los datos se pierden: por eso conviene guardar una copia cada tanto (por ejemplo en Google Drive).
            </T>
          </View>
        </View>
      </Card>

      <SectionHeader title="Crear copia" />
      <Group>
        {Platform.OS === 'android' && <Row icon="FolderDown" title="Guardar en el teléfono" subtitle="Elegí una carpeta (por ejemplo Descargas)" chevron onPress={saveLocal} />}
        <Row icon="Share2" title="Compartir copia" subtitle="Enviarla a Google Drive, WhatsApp, correo…" chevron onPress={share} />
      </Group>

      <SectionHeader title="Restaurar" />
      <Group>
        <Row icon="RotateCcw" title="Restaurar desde un archivo" subtitle="Reemplaza los datos de tu perfil" chevron onPress={restore} />
      </Group>

      <SectionHeader title="Exportar" />
      <Group>
        <Row icon="FileSpreadsheet" title="Movimientos en CSV" subtitle="Para abrir en Excel o Google Sheets" chevron onPress={csv} />
      </Group>

      <T variant="small" muted>
        La copia incluye sólo los datos de tu perfil ({profile.name}) y nunca tu PIN. El archivo no está cifrado: guardalo en un lugar que sólo vos uses.
      </T>
    </Screen>
  );
}
