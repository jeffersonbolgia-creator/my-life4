import React, { useEffect, useState } from 'react';
import { Alert, View } from 'react-native';
import * as LocalAuthentication from 'expo-local-authentication';
import { useApp, useProfile, useTheme } from '../../state/AppContext';
import { Button, Card, ChipGroup, Chip, Field, Group, Row, Screen, SectionHeader, Segmented, Sheet, T, ToggleRow } from '../../ui/kit';
import { PinDots, PinPad } from '../../ui/PinPad';
import { checkPin, isWeakPin, pinInUse, setPin, setRecoveryAnswer, SECURITY_QUESTIONS } from '../../security/pin';
import { success, toast } from '../../ui/haptics';

const AUTOLOCK = [
  { value: 0, label: 'Al salir' },
  { value: 1, label: '1 min' },
  { value: 5, label: '5 min' },
  { value: 15, label: '15 min' },
  { value: -1, label: 'Nunca' },
];

type PinPhase = 'current' | 'new' | 'confirm';

export default function SecurityScreen() {
  const t = useTheme();
  const profile = useProfile();
  const { profiles, updateSettings, updateProfile, refreshProfiles } = useApp();
  const s = profile.settings;
  const [bio, setBio] = useState<{ available: boolean; enrolled: boolean }>({ available: false, enrolled: false });
  const [pinOpen, setPinOpen] = useState(false);
  const [phase, setPhase] = useState<PinPhase>('current');
  const [len, setLen] = useState<4 | 6>(s.pinLength);
  const [cur, setCur] = useState('');
  const [p1, setP1] = useState('');
  const [p2, setP2] = useState('');
  const [err, setErr] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [recOpen, setRecOpen] = useState(false);
  const [question, setQuestion] = useState(profile.securityQuestion || SECURITY_QUESTIONS[0]);
  const [answer, setAnswer] = useState('');

  useEffect(() => {
    (async () => {
      try {
        const available = await LocalAuthentication.hasHardwareAsync();
        const enrolled = available && (await LocalAuthentication.isEnrolledAsync());
        setBio({ available, enrolled });
      } catch {
        // sin biometría
      }
    })();
  }, []);

  const openPin = () => {
    setPhase('current');
    setCur(''); setP1(''); setP2(''); setErr(null);
    setLen(s.pinLength);
    setPinOpen(true);
  };

  const onDigit = async (d: string) => {
    setErr(null);
    if (phase === 'current') {
      const v = (cur + d).slice(0, s.pinLength);
      setCur(v);
      if (v.length === s.pinLength) {
        setBusy(true);
        setTimeout(async () => {
          const ok = await checkPin(profile.id, v);
          setBusy(false);
          if (ok) setPhase('new');
          else { setErr('PIN actual incorrecto'); setTimeout(() => setCur(''), 400); }
        }, 30);
      }
    } else if (phase === 'new') {
      const v = (p1 + d).slice(0, len);
      setP1(v);
      if (v.length === len) {
        if (isWeakPin(v)) { setErr('Muy fácil de adivinar'); setTimeout(() => setP1(''), 400); return; }
        if (await pinInUse(profiles.map((p) => p.id), v, profile.id)) { setErr('Ese PIN lo usa otro perfil'); setTimeout(() => setP1(''), 400); return; }
        setPhase('confirm');
      }
    } else {
      const v = (p2 + d).slice(0, len);
      setP2(v);
      if (v.length === len) {
        if (v !== p1) { setErr('No coinciden'); setTimeout(() => { setP1(''); setP2(''); setPhase('new'); }, 500); return; }
        await setPin(profile.id, v);
        await updateSettings({ pinLength: len });
        await refreshProfiles();
        success();
        setPinOpen(false);
        toast('PIN actualizado');
      }
    }
  };

  const saveRecovery = async () => {
    try {
      await setRecoveryAnswer(profile.id, answer);
      await updateProfile({ securityQuestion: question });
      setRecOpen(false);
      setAnswer('');
      toast('Pregunta de recuperación actualizada');
    } catch (e: any) {
      Alert.alert('Error', String(e?.message ?? e));
    }
  };

  const toggleBio = async (v: boolean) => {
    if (v) {
      if (!bio.enrolled) {
        Alert.alert('Huella', 'Primero registrá una huella en los ajustes del teléfono.');
        return;
      }
      const r = await LocalAuthentication.authenticateAsync({ promptMessage: 'Confirmá tu huella', cancelLabel: 'Cancelar', disableDeviceFallback: true });
      if (!r.success) return;
    }
    await updateSettings({ biometrics: v });
    await refreshProfiles();
  };

  const value = phase === 'current' ? cur : phase === 'new' ? p1 : p2;
  const dots = phase === 'current' ? s.pinLength : len;

  return (
    <Screen title="Seguridad" back>
      <Group>
        <Row icon="KeyRound" title="Cambiar PIN" subtitle={`Actual: ${s.pinLength} dígitos`} chevron onPress={openPin} />
        <Row icon="LifeBuoy" title="Pregunta de recuperación" subtitle={profile.securityQuestion || 'Sin configurar'} chevron onPress={() => setRecOpen(true)} />
      </Group>

      {bio.available && (
        <>
          <SectionHeader title="Biometría" />
          <Group>
            <ToggleRow icon="Fingerprint" title="Desbloquear con huella" subtitle={bio.enrolled ? 'Se ofrece al abrir la app si fuiste el último en usarla' : 'No hay huellas registradas en el teléfono'} value={s.biometrics} onChange={toggleBio} />
          </Group>
          <T variant="small" muted>El teléfono no distingue de quién es cada huella registrada. Activalo sólo si en este teléfono no hay huellas de otras personas.</T>
        </>
      )}

      <SectionHeader title="Bloqueo automático" />
      <Card>
        <T variant="caption" secondary style={{ marginBottom: 10 }}>Pedir el PIN cuando volvés a la app después de:</T>
        <ChipGroup options={AUTOLOCK} value={s.autoLockMinutes} onChange={(v: number) => updateSettings({ autoLockMinutes: v })} />
      </Card>

      <SectionHeader title="Protección" />
      <Card>
        <View style={{ gap: 8 }}>
          <T variant="caption" secondary>• Tu PIN se guarda cifrado (hash con sal) en el almacenamiento seguro de Android. Nunca se guarda como texto.</T>
          <T variant="caption" secondary>• Después de 5 intentos incorrectos la app se bloquea unos segundos, y el tiempo aumenta con cada nueva tanda de errores.</T>
          <T variant="caption" secondary>• Cada perfil sólo puede ver y modificar sus propios datos.</T>
        </View>
      </Card>

      <Sheet visible={pinOpen} onClose={() => setPinOpen(false)} title={phase === 'current' ? 'Ingresá tu PIN actual' : phase === 'new' ? 'Nuevo PIN' : 'Confirmá el nuevo PIN'}>
        <View style={{ gap: 16 }}>
          {phase === 'new' && (
            <Segmented value={String(len)} options={[{ value: '4', label: '4 dígitos' }, { value: '6', label: '6 dígitos' }]} onChange={(v) => { setLen(v === '6' ? 6 : 4); setP1(''); }} />
          )}
          <PinDots length={dots} filled={value.length} error={!!err} />
          <T variant="caption" align="center" color={t.c.danger} style={{ minHeight: 18 }}>{err ?? ''}</T>
          <PinPad onDigit={onDigit} disabled={busy} onDelete={() => (phase === 'current' ? setCur((x) => x.slice(0, -1)) : phase === 'new' ? setP1((x) => x.slice(0, -1)) : setP2((x) => x.slice(0, -1)))} />
        </View>
      </Sheet>

      <Sheet visible={recOpen} onClose={() => setRecOpen(false)} title="Pregunta de recuperación">
        <View style={{ gap: 12 }}>
          {SECURITY_QUESTIONS.map((q) => <Chip key={q} label={q} selected={q === question} onPress={() => setQuestion(q)} />)}
          <Field label="Nueva respuesta" value={answer} onChangeText={setAnswer} autoCapitalize="none" />
          <Button title="Guardar" onPress={saveRecovery} disabled={answer.trim().length < 2} />
        </View>
      </Sheet>
    </Screen>
  );
}
