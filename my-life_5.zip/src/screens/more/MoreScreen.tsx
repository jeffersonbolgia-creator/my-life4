import React from 'react';
import { Pressable, View } from 'react-native';
import { useApp, useProfile, useTheme } from '../../state/AppContext';
import { useData } from '../../state/useData';
import { Avatar, Card, Group, IconButton, Row, Screen, SectionHeader, T } from '../../ui/kit';
import { Icon } from '../../ui/Icon';
import { countdownsRepo, goalsRepo, habitsRepo, notesRepo, remindersRepo, routinesRepo, subscriptionsRepo } from '../../db/repos';
import { tap } from '../../ui/haptics';
import { MODULES, isModuleOn } from '../../modules/registry';
import { todayISO } from '../../lib/dates';

export default function MoreScreen({ navigation }: any) {
  const t = useTheme();
  const profile = useProfile();
  const { lock } = useApp();
  const modules = profile.settings.modules;
  const { data } = useData(
    async (pid) => {
      const today = todayISO();
      const [g, h, n, r, c, ru, su] = await Promise.all([goalsRepo.list(pid), habitsRepo.list(pid), notesRepo.list(pid), remindersRepo.list(pid), countdownsRepo.list(pid), routinesRepo.list(pid), subscriptionsRepo.list(pid, false)]);
      return {
        goals: g.filter((x) => !x.completedAt).length, habits: h.length, notes: n.length, reminders: r.filter((x) => !x.done).length,
        countdowns: c.filter((x) => x.date >= today).length, routines: ru.length, subscriptions: su.length,
      };
    },
    { goals: 0, habits: 0, notes: 0, reminders: 0, countdowns: 0, routines: 0, subscriptions: 0 },
  );

  const tiles: { label: string; icon: string; color: string; route: string; params?: any; count?: number }[] = [
    { label: 'Objetivos', icon: 'Target', color: '#D946EF', route: 'Goals', count: data.goals },
    { label: 'Hábitos', icon: 'Repeat', color: '#06B6D4', route: 'Habits', count: data.habits },
    { label: 'Notas', icon: 'NotebookPen', color: '#F59E0B', route: 'Notes', count: data.notes },
    { label: 'Recordatorios', icon: 'BellRing', color: '#F97316', route: 'Reminders', count: data.reminders },
    { label: 'Estadísticas', icon: 'ChartColumn', color: '#10B981', route: 'Stats' },
    { label: 'Calendario', icon: 'CalendarDays', color: '#3B82F6', route: 'Agenda', params: { view: 'calendar' } },
  ];
  const activeModules = MODULES.filter((m) => isModuleOn(modules, m.key));
  const moduleTiles = activeModules.map((m) => ({
    label: m.label, icon: m.icon, color: m.color, route: m.route,
    count: m.key === 'countdown' ? data.countdowns : m.key === 'routines' ? data.routines : m.key === 'subscriptions' ? data.subscriptions : undefined,
  }));

  return (
    <Screen title="Más" tabs right={<IconButton icon="Search" label="Buscar" onPress={() => navigation.navigate('Search')} />}>
      <Card onPress={() => navigation.navigate('ProfileEdit')} gradient>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 14 }}>
          <Avatar name={profile.name} color={profile.avatarColor} size={54} />
          <View style={{ flex: 1 }}>
            <T variant="heading">{profile.name}</T>
            <T variant="caption" secondary>{profile.age != null ? `${profile.age} años · ` : ''}Ver y editar perfil</T>
          </View>
          <Icon name="ChevronRight" size={20} color={t.c.textMuted} />
        </View>
      </Card>

      {moduleTiles.length ? (
        <>
          <SectionHeader title="Tus módulos" action="Configurar" onAction={() => navigation.navigate('Modules')} />
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 10 }}>
            {moduleTiles.map((x) => (
              <Pressable
                key={x.label}
                onPress={() => { tap(); navigation.navigate(x.route); }}
                style={({ pressed }) => ({ width: '48%', flexGrow: 1, backgroundColor: t.c.surface, borderRadius: t.radius.lg, borderWidth: 1, borderColor: x.color + '55', padding: 14, gap: 12, opacity: pressed ? 0.8 : 1 })}
              >
                <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                  <View style={{ width: 40, height: 40, borderRadius: 13, backgroundColor: x.color + (t.dark ? '24' : '18'), alignItems: 'center', justifyContent: 'center' }}>
                    <Icon name={x.icon} size={20} color={x.color} />
                  </View>
                  {x.count ? <T variant="small" muted>{x.count}</T> : null}
                </View>
                <T variant="bodyStrong" numberOfLines={1}>{x.label}</T>
              </Pressable>
            ))}
          </View>
        </>
      ) : (
        <Card onPress={() => navigation.navigate('Modules')} gradient accentBorder>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 14 }}>
            <View style={{ width: 44, height: 44, borderRadius: 14, backgroundColor: t.accentSoft, alignItems: 'center', justifyContent: 'center' }}>
              <Icon name="LayoutGrid" size={22} color={t.accent.base} />
            </View>
            <View style={{ flex: 1 }}>
              <T variant="bodyStrong">Activá módulos</T>
              <T variant="caption" secondary>Cuenta regresiva, rutinas y más</T>
            </View>
            <Icon name="ChevronRight" size={20} color={t.c.textMuted} />
          </View>
        </Card>
      )}

      <SectionHeader title="Secciones" />
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 10 }}>
        {tiles.map((x) => (
          <Pressable
            key={x.label}
            onPress={() => { tap(); navigation.navigate(x.route, x.params); }}
            style={({ pressed }) => ({ width: '31.5%', flexGrow: 1, backgroundColor: t.c.surface, borderRadius: t.radius.lg, borderWidth: 1, borderColor: t.c.border, padding: 14, gap: 12, opacity: pressed ? 0.8 : 1 })}
          >
            <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start' }}>
              <View style={{ width: 40, height: 40, borderRadius: 13, backgroundColor: x.color + (t.dark ? '24' : '18'), alignItems: 'center', justifyContent: 'center' }}>
                <Icon name={x.icon} size={20} color={x.color} />
              </View>
              {x.count ? <T variant="small" muted>{x.count}</T> : null}
            </View>
            <T variant="bodyStrong" numberOfLines={1}>{x.label}</T>
          </Pressable>
        ))}
      </View>

      <SectionHeader title="Cuenta" />
      <Group>
        <Row icon="LayoutGrid" title="Módulos" subtitle="Elegí qué secciones querés usar" chevron onPress={() => navigation.navigate('Modules')} />
        <Row icon="Settings" title="Configuración" subtitle="Apariencia, notificaciones, seguridad, copias" chevron onPress={() => navigation.navigate('Settings')} />
        <Row icon="LockKeyhole" title="Bloquear / cambiar de perfil" subtitle="Vuelve a la pantalla de PIN" onPress={lock} />
      </Group>
    </Screen>
  );
}
