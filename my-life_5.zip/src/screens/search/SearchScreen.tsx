import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Pressable, ScrollView, TextInput, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useApp, useProfile, useTheme } from '../../state/AppContext';
import { Card, EmptyState, IconBox, IconButton, T } from '../../ui/kit';
import { Icon } from '../../ui/Icon';
import { FONT } from '../../theme/theme';
import { groupResults, loadSearchData, searchItems, SEARCH_KIND_LABELS, type SearchData } from '../../logic/search';
import { tap } from '../../ui/haptics';

export default function SearchScreen({ navigation }: any) {
  const t = useTheme();
  const insets = useSafeAreaInsets();
  const profile = useProfile();
  const { dataVersion } = useApp();
  const [q, setQ] = useState('');
  const [data, setData] = useState<SearchData | null>(null);
  const input = useRef<TextInput>(null);

  useEffect(() => {
    let alive = true;
    loadSearchData(profile.id).then((d) => { if (alive) setData(d); }).catch(() => {});
    return () => { alive = false; };
  }, [profile.id, dataVersion]);

  useEffect(() => {
    const id = setTimeout(() => input.current?.focus(), 250);
    return () => clearTimeout(id);
  }, []);

  const results = useMemo(() => (data ? searchItems(data, q) : []), [data, q]);
  const groups = useMemo(() => groupResults(results), [results]);
  const total = data ? Object.values(data).reduce((a, arr) => a + arr.length, 0) : 0;

  return (
    <View style={{ flex: 1, backgroundColor: t.c.bg, paddingTop: insets.top + 8 }}>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10, paddingHorizontal: 18, paddingBottom: 12 }}>
        <IconButton icon="ChevronLeft" label="Volver" onPress={() => navigation.goBack()} />
        <View style={{ flex: 1, flexDirection: 'row', alignItems: 'center', gap: 10, height: 50, paddingHorizontal: 14, borderRadius: t.radius.md, backgroundColor: t.c.surface2, borderWidth: 1, borderColor: q ? t.accent.base : t.c.border }}>
          <Icon name="Search" size={18} color={q ? t.accent.base : t.c.textMuted} />
          <TextInput
            ref={input}
            value={q}
            onChangeText={setQ}
            placeholder="Buscar en todo lo tuyo…"
            placeholderTextColor={t.c.textMuted}
            selectionColor={t.accent.base}
            cursorColor={t.accent.base}
            autoCapitalize="none"
            autoCorrect={false}
            returnKeyType="search"
            style={{ flex: 1, color: t.c.text, fontFamily: FONT.regular, fontSize: 15.5, paddingVertical: 0 }}
            accessibilityLabel="Buscar"
          />
          {q ? (
            <Pressable onPress={() => setQ('')} hitSlop={10} accessibilityLabel="Borrar"><Icon name="X" size={16} color={t.c.textMuted} /></Pressable>
          ) : null}
        </View>
      </View>
      <ScrollView contentContainerStyle={{ paddingHorizontal: 18, paddingBottom: insets.bottom + 30, gap: 14 }} keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false}>
        {q.trim().length < 2 ? (
          <EmptyState icon="Search" title="¿Qué buscás?" text={`Escribí al menos 2 letras. Buscamos en tus ${total} tareas, eventos, notas, movimientos, hábitos, objetivos, recordatorios, cuentas regresivas y rutinas.`} />
        ) : groups.length === 0 ? (
          <EmptyState icon="SearchX" title="Sin resultados" text={`No encontramos nada con "${q.trim()}" en tu perfil.`} />
        ) : (
          groups.map((g) => {
            const meta = SEARCH_KIND_LABELS[g.kind];
            return (
              <View key={g.kind} style={{ gap: 8 }}>
                <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
                  <T variant="label" muted>{meta.label}</T>
                  <T variant="small" muted>{g.items.length}</T>
                </View>
                <Card padding={6}>
                  {g.items.map((r) => (
                    <Pressable
                      key={`${r.kind}-${r.id}`}
                      onPress={() => { tap(); navigation.navigate(r.route, r.params); }}
                      android_ripple={{ color: t.accentSofter }}
                      style={{ flexDirection: 'row', alignItems: 'center', gap: 12, padding: 10 }}
                    >
                      <IconBox icon={meta.icon} size={36} color={meta.color} />
                      <View style={{ flex: 1 }}>
                        <T variant="bodyStrong" numberOfLines={1}>{r.title}</T>
                        <T variant="small" muted numberOfLines={1}>{r.subtitle}</T>
                      </View>
                      <Icon name="ChevronRight" size={16} color={t.c.textMuted} />
                    </Pressable>
                  ))}
                </Card>
              </View>
            );
          })
        )}
      </ScrollView>
    </View>
  );
}
