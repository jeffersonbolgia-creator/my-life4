// Timbre de alarma dentro de la app (expo-audio), en bucle hasta que se apague.
// Es un respaldo: el sonido principal lo pone el canal de notificación de Android. Si la app está
// abierta cuando suena la alarma, esto garantiza que se escuche aunque el canal del sistema fallara.
// Si expo-audio no estuviera, no pasa nada: la pantalla de alarma funciona igual, sin sonido propio.

import type { AlarmSound } from '../../types';

let Audio: any = null;
try {
  // eslint-disable-next-line @typescript-eslint/no-var-requires
  Audio = require('expo-audio');
} catch {
  Audio = null;
}

// Los mismos archivos que usa el canal de notificación (assets/sounds), empaquetados en la app.
/* eslint-disable @typescript-eslint/no-var-requires */
const ASSETS: Record<AlarmSound, any> = {
  classic: require('../../../assets/sounds/alarm.wav'),
  soft: require('../../../assets/sounds/alarm_soft.wav'),
  chime: require('../../../assets/sounds/alarm_chime.wav'),
  bell: require('../../../assets/sounds/alarm_bell.wav'),
};
/* eslint-enable @typescript-eslint/no-var-requires */

let player: any = null;
let stopTimer: ReturnType<typeof setTimeout> | null = null;

/** Tope de seguridad: si nadie la apaga, deja de sonar sola (igual que la repetición de avisos). */
const MAX_RING_MS = 5 * 60_000;

export function ringerAvailable(): boolean {
  return !!Audio && typeof Audio.createAudioPlayer === 'function';
}

export async function startRinging(sound: AlarmSound = 'classic'): Promise<boolean> {
  if (!ringerAvailable()) return false;
  stopRinging();
  try {
    if (Audio.setAudioModeAsync) await Audio.setAudioModeAsync({ playsInSilentMode: true, shouldPlayInBackground: false, interruptionMode: 'doNotMix', interruptionModeAndroid: 'doNotMix' }).catch(() => {});
    player = Audio.createAudioPlayer(ASSETS[sound] ?? ASSETS.classic);
    try { player.loop = true; } catch {}
    try { player.volume = 1; } catch {}
    player.play();
    stopTimer = setTimeout(stopRinging, MAX_RING_MS);
    return true;
  } catch {
    player = null;
    return false;
  }
}

export function stopRinging() {
  if (stopTimer) clearTimeout(stopTimer);
  stopTimer = null;
  if (!player) return;
  try { player.pause?.(); } catch {}
  try { player.remove?.(); } catch {}
  player = null;
}
