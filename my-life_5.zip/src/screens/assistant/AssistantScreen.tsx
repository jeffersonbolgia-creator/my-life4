import React, { useCallback, useEffect, useRef, useState } from 'react';
import { Alert, FlatList, KeyboardAvoidingView, Pressable, TextInput, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useApp, useProfile, useTheme } from '../../state/AppContext';
import { Button, Field, IconButton, ProgressBar, Segmented, Sheet, T, ToggleRow } from '../../ui/kit';
import { Icon } from '../../ui/Icon';
import { FONT } from '../../theme/theme';
import { assistantRepo } from '../../db/repos';
import { dailyMessage, loadAssistantData, respond, type ReplyPayload } from '../../assistant/engine';
import { applyConfirm, editRoute } from '../../assistant/actions';
import { QUICK_PROMPTS } from '../../assistant/intents';
import { todayISO } from '../../lib/dates';
import { success, tap, toast } from '../../ui/haptics';
import type { AssistantMessage, AssistantPersonality } from '../../types';

function Bubble({ m, onChip, onConfirm, onEdit, onCancel }: { m: AssistantMessage; onChip: (s: string) => void; onConfirm: (m: AssistantMessage) => void; onEdit: (m: AssistantMessage) => void; onCancel: (m: AssistantMessage) => void }) {
  const t = useTheme();
  const mine = m.role === 'user';
  const p = m.payload as ReplyPayload | null;
  return (
    <View style={{ alignItems: mine ? 'flex-end' : 'flex-start', marginBottom: 10 }}>
      <View style={{
        maxWidth: '86%', paddingHorizontal: 14, paddingVertical: 10, gap: 10,
        borderRadius: 18, borderBottomRightRadius: mine ? 4 : 18, borderBottomLeftRadius: mine ? 18 : 4,
        backgroundColor: mine ? t.accent.base : t.c.surface, borderWidth: mine ? 0 : 1, borderColor: t.c.border,
      }}>
        <T color={mine ? '#fff' : undefined} style={{ lineHeight: 21 }}>{m.text}</T>
        {p?.kind === 'bars' ? (
          <View style={{ gap: 6 }}>
            {p.items.map((it, i) => {
              const max = Math.max(1, ...p.items.map((x) => x.value));
              return (
                <View key={i} style={{ gap: 3 }}>
                  <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
                    <T variant="small" secondary numberOfLines={1} style={{ flex: 1 }}>{it.label}</T>
                    <T variant="small">{it.display}</T>
                  </View>
                  <ProgressBar value={(it.value / max) * 100} height={6} color={it.color} />
                </View>
              );
            })}
          </View>
        ) : null}
        {p?.kind === 'chips' ? (
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 6 }}>
            {p.items.map((c) => (
              <Pressable key={c} onPress={() => onChip(c)} style={{ paddingHorizontal: 10, height: 32, borderRadius: 16, backgroundColor: t.accentSoft, alignItems: 'center', justifyContent: 'center' }}>
                <T variant="small" color={t.accent.light}>{c}</T>
              </Pressable>
            ))}
          </View>
        ) : null}
        {p?.kind === 'confirm' ? (
          p.status === 'pending' ? (
            <View style={{ flexDirection: 'row', gap: 8 }}>
              <Button title="Guardar" size="sm" full={false} icon="Check" onPress={() => onConfirm(m)} />
              <Button title="Cambiar" size="sm" full={false} variant="secondary" onPress={() => onEdit(m)} />
              <IconButton icon="X" label="Cancelar" size={40} onPress={() => onCancel(m)} />
            </View>
          ) : (
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
              <Icon name={p.status === 'done' ? 'CircleCheck' : 'CircleX'} size={16} color={p.status === 'done' ? t.c.success : t.c.textMuted} />
              <T variant="small" color={p.status === 'done' ? t.c.success : t.c.textMuted}>{p.status === 'done' ? 'Guardado' : 'Cancelado'}</T>
            </View>
          )
        ) : null}
      </View>
    </View>
  );
}

export default function AssistantScreen({ navigation }: any) {
  const t = useTheme();
  const insets = useSafeAreaInsets();
  const profile = useProfile();
  const { updateSettings, bump } = useApp();
  const a = profile.settings.assistant;
  const [messages, setMessages] = useState<AssistantMessage[]>([]);
  const [text, setText] = useState('');
  const [busy, setBusy] = useState(false);
  const [settings, setSettings] = useState(false);
  const [nameDraft, setNameDraft] = useState(a.name);
  const list = useRef<FlatList<AssistantMessage>>(null);

  const load = useCallback(async () => setMessages(await assistantRepo.list(profile.id)), [profile.id]);

  useEffect(() => {
    (async () => {
      await load();
      // Mensaje del día (una vez por día)
      if (a.proactive) {
        const msgs = await assistantRepo.list(profile.id, 50);
        const last = [...msgs].reverse().find((m) => m.role === 'assistant' && (m.payload as any)?.daily);
        if (!last || last.createdAt.slice(0, 10) !== todayISO()) {
          const data = await loadAssistantData(profile);
          const dm = dailyMessage(data);
          if (dm) {
            await assistantRepo.add(profile.id, 'assistant', dm, { daily: true, kind: 'chips', items: ['¿Qué hice ayer?', 'Pendientes de hoy', '¿Cuánto gasté esta semana?'] } as any);
            await load();
          }
        }
      }
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [profile.id]);

  useEffect(() => {
    const id = setTimeout(() => list.current?.scrollToEnd({ animated: true }), 120);
    return () => clearTimeout(id);
  }, [messages.length]);

  const send = async (raw?: string) => {
    const msg = (raw ?? text).trim();
    if (!msg || busy) return;
    setText('');
    setBusy(true);
    tap();
    try {
      await assistantRepo.add(profile.id, 'user', msg);
      await load();
      const data = await loadAssistantData(profile);
      const reply = respond(msg, data);
      await assistantRepo.add(profile.id, 'assistant', reply.text, (reply.payload as any) ?? null);
      if (reply.payload?.kind === 'settings') {
        if (reply.payload.name) updateSettings({ assistant: { ...a, name: reply.payload.name } });
        if (reply.payload.personality) updateSettings({ assistant: { ...a, personality: reply.payload.personality } });
        if (reply.payload.clear) {
          Alert.alert('Borrar historial', '¿Borro toda la conversación?', [
            { text: 'Cancelar', style: 'cancel' },
            { text: 'Borrar', style: 'destructive', onPress: async () => { await assistantRepo.clear(profile.id); await load(); } },
          ]);
        }
      }
      await load();
    } catch (e: any) {
      Alert.alert('Error', String(e?.message ?? e));
    } finally {
      setBusy(false);
    }
  };

  const confirm = async (m: AssistantMessage) => {
    const p = m.payload as ReplyPayload;
    if (p.kind !== 'confirm') return;
    try {
      const msg = await applyConfirm(profile.id, p);
      await assistantRepo.setPayload(profile.id, m.id, { ...p, status: 'done' });
      await assistantRepo.add(profile.id, 'assistant', `${msg}. ${a.personality === 'fun' ? '¡Seguimos!' : a.personality === 'direct' ? '' : '¿Algo más?'}`.trim());
      success();
      bump();
      await load();
    } catch (e: any) {
      Alert.alert('No se pudo guardar', String(e?.message ?? e));
    }
  };
  const cancel = async (m: AssistantMessage) => {
    const p = m.payload as ReplyPayload;
    if (p.kind !== 'confirm') return;
    await assistantRepo.setPayload(profile.id, m.id, { ...p, status: 'cancelled' });
    await load();
  };
  const edit = async (m: AssistantMessage) => {
    const p = m.payload as ReplyPayload;
    if (p.kind !== 'confirm') return;
    await cancel(m);
    const { route, params } = editRoute(p);
    navigation.navigate(route, params);
  };

  const saveSettings = (patch: Partial<typeof a>) => updateSettings({ assistant: { ...a, ...patch } });

  return (
    <View style={{ flex: 1, backgroundColor: t.c.bg }}>
      <View style={{ paddingTop: insets.top + 8, paddingHorizontal: 18, paddingBottom: 10, flexDirection: 'row', alignItems: 'center', gap: 12, borderBottomWidth: 1, borderBottomColor: t.c.border }}>
        <IconButton icon="ChevronLeft" label="Volver" onPress={() => navigation.goBack()} />
        <View style={{ width: 42, height: 42, borderRadius: 14, backgroundColor: t.accent.base, alignItems: 'center', justifyContent: 'center', ...t.glow() }}>
          <Icon name="Sparkles" size={22} color="#fff" />
        </View>
        <View style={{ flex: 1 }}>
          <T variant="heading">{a.name}</T>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 5 }}>
            <View style={{ width: 7, height: 7, borderRadius: 4, backgroundColor: t.c.success }} />
            <T variant="small" secondary>Solo en tu celular · sin internet</T>
          </View>
        </View>
        <IconButton icon="Settings2" label="Opciones" onPress={() => { setNameDraft(a.name); setSettings(true); }} />
      </View>
      <KeyboardAvoidingView style={{ flex: 1 }} behavior="padding" keyboardVerticalOffset={0}>
        <FlatList
          ref={list}
          data={messages}
          keyExtractor={(m) => String(m.id)}
          renderItem={({ item }) => <Bubble m={item} onChip={(s) => send(s)} onConfirm={confirm} onEdit={edit} onCancel={cancel} />}
          contentContainerStyle={{ padding: 18, paddingBottom: 8 }}
          ListEmptyComponent={
            <View style={{ alignItems: 'center', paddingVertical: 40, gap: 10 }}>
              <Icon name="Sparkles" size={36} color={t.accent.base} />
              <T variant="heading" align="center">Hola, soy {a.name}</T>
              <T secondary align="center">Conozco lo que anotás en MY LIFE. Preguntame qué hiciste, cuánto gastaste o qué tenés pendiente, o decime algo para anotar.</T>
            </View>
          }
          onContentSizeChange={() => list.current?.scrollToEnd({ animated: false })}
          keyboardShouldPersistTaps="handled"
        />
        <View style={{ paddingHorizontal: 18, paddingBottom: 8, flexDirection: 'row', flexWrap: 'nowrap', gap: 6 }}>
          {QUICK_PROMPTS.slice(0, 3).map((q) => (
            <Pressable key={q} onPress={() => send(q)} style={{ paddingHorizontal: 10, height: 32, borderRadius: 16, backgroundColor: t.c.surface, borderWidth: 1, borderColor: t.c.border, alignItems: 'center', justifyContent: 'center' }}>
              <T variant="small" secondary numberOfLines={1}>{q}</T>
            </Pressable>
          ))}
        </View>
        <View style={{ paddingHorizontal: 18, paddingBottom: insets.bottom + 14, flexDirection: 'row', gap: 10, alignItems: 'center' }}>
          <View style={{ flex: 1, height: 50, borderRadius: t.radius.md, backgroundColor: t.c.surface2, borderWidth: 1, borderColor: t.c.border, paddingHorizontal: 14, justifyContent: 'center' }}>
            <TextInput
              value={text}
              onChangeText={setText}
              placeholder={`Escribile a ${a.name}…`}
              placeholderTextColor={t.c.textMuted}
              selectionColor={t.accent.base}
              cursorColor={t.accent.base}
              onSubmitEditing={() => send()}
              returnKeyType="send"
              blurOnSubmit={false}
              style={{ color: t.c.text, fontFamily: FONT.regular, fontSize: 15.5, paddingVertical: 0 }}
              accessibilityLabel="Mensaje"
            />
          </View>
          <IconButton icon="ArrowUp" label="Enviar" filled size={50} onPress={() => send()} />
        </View>
      </KeyboardAvoidingView>

      <Sheet visible={settings} onClose={() => setSettings(false)} title="Tu amigo">
        <View style={{ gap: 14 }}>
          <Field label="Nombre" value={nameDraft} onChangeText={setNameDraft} maxLength={20} onBlur={() => nameDraft.trim() && saveSettings({ name: nameDraft.trim() })} />
          <View style={{ gap: 8 }}>
            <T variant="caption" secondary>Personalidad</T>
            <Segmented<AssistantPersonality> value={a.personality} onChange={(v) => saveSettings({ personality: v })} options={[{ value: 'warm', label: 'Cálido' }, { value: 'direct', label: 'Directo' }, { value: 'fun', label: 'Divertido' }]} />
          </View>
          <ToggleRow icon="Sunrise" title="Mensaje del día" subtitle="Un resumen cuando abrís el chat cada día" value={a.proactive} onChange={(v) => saveSettings({ proactive: v })} />
          <Button title="Borrar historial del chat" icon="Trash2" variant="ghost" onPress={() => {
            Alert.alert('Borrar historial', 'Se borra la conversación. Tus datos de la app no se tocan.', [
              { text: 'Cancelar', style: 'cancel' },
              { text: 'Borrar', style: 'destructive', onPress: async () => { await assistantRepo.clear(profile.id); setSettings(false); await load(); toast('Historial borrado'); } },
            ]);
          }} />
          <T variant="small" muted>{a.name} no usa internet ni inteligencia artificial: responde con lo que anotás en la app. Tus datos nunca salen del celular.</T>
        </View>
      </Sheet>
    </View>
  );
}
