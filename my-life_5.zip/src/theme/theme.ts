import type { AccentKey, BgStyle, FontScale, GlowLevel, RadiusStyle } from '../types';

export interface AccentDef {
  key: AccentKey;
  name: string;
  base: string;
  deep: string;
  light: string;
}

export const ACCENTS: Record<AccentKey, AccentDef> = {
  violet: { key: 'violet', name: 'Violeta', base: '#8B5CF6', deep: '#6D28D9', light: '#C4B5FD' },
  indigo: { key: 'indigo', name: 'Índigo', base: '#6366F1', deep: '#4338CA', light: '#A5B4FC' },
  fuchsia: { key: 'fuchsia', name: 'Fucsia', base: '#D946EF', deep: '#A21CAF', light: '#F0ABFC' },
  blue: { key: 'blue', name: 'Azul', base: '#3B82F6', deep: '#1D4ED8', light: '#93C5FD' },
  emerald: { key: 'emerald', name: 'Esmeralda', base: '#10B981', deep: '#047857', light: '#6EE7B7' },
  amber: { key: 'amber', name: 'Ámbar', base: '#F59E0B', deep: '#B45309', light: '#FCD34D' },
  rose: { key: 'rose', name: 'Rosa', base: '#F43F5E', deep: '#BE123C', light: '#FDA4AF' },
};

export interface Palette {
  bg: string;
  bgElevated: string;
  surface: string;
  surface2: string;
  surface3: string;
  border: string;
  borderStrong: string;
  text: string;
  textSecondary: string;
  textMuted: string;
  overlay: string;
  success: string;
  danger: string;
  warning: string;
  info: string;
  tabBar: string;
  shadow: string;
}

// Negro profundo con violeta: superficies apenas levantadas del fondo, bordes finos, nada de adornos.
const DARK: Palette = {
  bg: '#050507',
  bgElevated: '#0A0A0F',
  surface: '#0F0E15',
  surface2: '#15131D',
  surface3: '#1F1C2A',
  border: 'rgba(255,255,255,0.07)',
  borderStrong: 'rgba(255,255,255,0.13)',
  text: '#F4F2FA',
  textSecondary: '#A6A1B8',
  textMuted: '#767188',
  overlay: 'rgba(3,3,6,0.78)',
  success: '#34D399',
  danger: '#FB7185',
  warning: '#FBBF24',
  info: '#60A5FA',
  tabBar: 'rgba(10,10,15,0.97)',
  shadow: '#000000',
};

const LIGHT: Palette = {
  bg: '#F5F4F9',
  bgElevated: '#FBFAFD',
  surface: '#FFFFFF',
  surface2: '#F1EFF7',
  surface3: '#E7E4F0',
  border: 'rgba(22,16,40,0.07)',
  borderStrong: 'rgba(22,16,40,0.14)',
  text: '#15121E',
  textSecondary: '#5C5769',
  textMuted: '#9893A6',
  overlay: 'rgba(15,12,25,0.45)',
  success: '#059669',
  danger: '#DC2626',
  warning: '#D97706',
  info: '#2563EB',
  tabBar: 'rgba(255,255,255,0.97)',
  shadow: '#2A1B5C',
};

export interface Theme {
  dark: boolean;
  c: Palette;
  accent: AccentDef;
  accentSoft: string;
  accentSofter: string;
  onAccent: string;
  gradient: [string, string];
  heroGradient: [string, string, string];
  gradients: boolean;
  radius: { sm: number; md: number; lg: number; xl: number; pill: number };
  space: (n: number) => number;
  compact: boolean;
  /** Multiplicador del tamaño de letra elegido por el perfil. */
  fontScale: number;
  glowLevel: GlowLevel;
  bgStyle: BgStyle;
  /** Sombra/brillo de color para resaltar un elemento (vacío si el brillo está apagado). */
  glow: (color?: string) => { shadowColor?: string; shadowOpacity?: number; shadowRadius?: number; shadowOffset?: { width: number; height: number }; elevation?: number };
}

export interface ThemeOptions {
  gradients?: boolean;
  compact?: boolean;
  fontScale?: FontScale;
  radiusStyle?: RadiusStyle;
  glow?: GlowLevel;
  bgStyle?: BgStyle;
}

const FONT_SCALES: Record<FontScale, number> = { small: 0.92, normal: 1, large: 1.12 };
const RADII: Record<RadiusStyle, Theme['radius']> = {
  sharp: { sm: 6, md: 10, lg: 14, xl: 18, pill: 999 },
  soft: { sm: 10, md: 14, lg: 20, xl: 26, pill: 999 },
  round: { sm: 14, md: 18, lg: 26, xl: 32, pill: 999 },
};

export function hexToRgba(hex: string, a: number): string {
  const h = hex.replace('#', '');
  const v = h.length === 3 ? h.split('').map((x) => x + x).join('') : h;
  const n = parseInt(v, 16);
  return `rgba(${(n >> 16) & 255},${(n >> 8) & 255},${n & 255},${a})`;
}

export function buildTheme(dark: boolean, accentKey: AccentKey, gradientsOrOpts: boolean | ThemeOptions = true, compactArg = false): Theme {
  const opts: ThemeOptions = typeof gradientsOrOpts === 'boolean' ? { gradients: gradientsOrOpts, compact: compactArg } : gradientsOrOpts;
  const gradients = opts.gradients ?? true;
  const compact = opts.compact ?? false;
  const glowLevel: GlowLevel = opts.glow ?? 'soft';
  const accent = ACCENTS[accentKey] ?? ACCENTS.violet;
  const c = dark ? DARK : LIGHT;
  const glow = (color?: string) => {
    if (glowLevel === 'off') return {};
    const strong = glowLevel === 'strong';
    return {
      shadowColor: color ?? accent.base,
      shadowOpacity: dark ? (strong ? 0.6 : 0.35) : strong ? 0.3 : 0.16,
      shadowRadius: strong ? 22 : 14,
      shadowOffset: { width: 0, height: strong ? 8 : 5 },
      elevation: strong ? 10 : 5,
    };
  };
  return {
    dark,
    c,
    accent,
    accentSoft: hexToRgba(accent.base, dark ? 0.16 : 0.12),
    accentSofter: hexToRgba(accent.base, dark ? 0.08 : 0.06),
    onAccent: '#FFFFFF',
    gradient: [accent.deep, accent.base],
    heroGradient: dark
      ? [hexToRgba(accent.deep, 0.34), hexToRgba(accent.base, 0.1), 'rgba(5,5,7,0)']
      : [hexToRgba(accent.base, 0.22), hexToRgba(accent.light, 0.12), 'rgba(245,244,249,0)'],
    gradients,
    radius: RADII[opts.radiusStyle ?? 'soft'],
    space: (n: number) => n * (compact ? 3.5 : 4),
    compact,
    fontScale: FONT_SCALES[opts.fontScale ?? 'normal'],
    glowLevel,
    bgStyle: opts.bgStyle ?? 'gradient',
    glow,
  };
}

export const FONT = {
  regular: 'Inter_400Regular',
  medium: 'Inter_500Medium',
  semibold: 'Inter_600SemiBold',
  bold: 'Inter_700Bold',
};

export const CATEGORY_COLORS = ['#8B5CF6', '#3B82F6', '#10B981', '#F59E0B', '#F43F5E', '#06B6D4', '#D946EF', '#84CC16', '#F97316', '#64748B'];
