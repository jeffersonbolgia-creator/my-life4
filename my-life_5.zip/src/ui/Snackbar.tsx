import React, { useEffect, useRef, useState } from 'react';
import { Animated, Pressable, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useTheme } from '../state/AppContext';
import { T } from './kit';
import { setSnackHandler, type SnackMessage } from './haptics';

/** Barra de aviso con botón de acción (por ejemplo "Deshacer"). Se monta una vez en la app. */
export function Snackbar() {
  const t = useTheme();
  const insets = useSafeAreaInsets();
  const [msg, setMsg] = useState<SnackMessage | null>(null);
  const y = useRef(new Animated.Value(80)).current;
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    setSnackHandler((m) => {
      setMsg(m);
      if (timer.current) clearTimeout(timer.current);
      timer.current = setTimeout(() => setMsg(null), 5000);
    });
    return () => setSnackHandler(null);
  }, []);

  useEffect(() => {
    Animated.spring(y, { toValue: msg ? 0 : 80, useNativeDriver: true, damping: 18, stiffness: 200 }).start();
  }, [msg, y]);

  if (!msg) return null;
  return (
    <Animated.View pointerEvents="box-none" style={{ position: 'absolute', left: 16, right: 16, bottom: insets.bottom + 96, transform: [{ translateY: y }] }}>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12, backgroundColor: t.c.bgElevated, borderWidth: 1, borderColor: t.c.borderStrong, borderRadius: 16, paddingVertical: 12, paddingHorizontal: 16, ...t.glow() }}>
        <T variant="caption" style={{ flex: 1 }} numberOfLines={2}>{msg.text}</T>
        {msg.action ? (
          <Pressable onPress={() => { msg.action?.(); setMsg(null); }} hitSlop={8}>
            <T variant="bodyStrong" color={t.accent.light}>{msg.actionLabel ?? 'Deshacer'}</T>
          </Pressable>
        ) : null}
      </View>
    </Animated.View>
  );
}
