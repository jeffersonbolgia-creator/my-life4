import React from 'react';
import { View } from 'react-native';
import Svg, { Circle, G, Path, Rect, Line, Defs, LinearGradient, Stop } from 'react-native-svg';
import { useTheme } from '../state/AppContext';
import { hexToRgba } from '../theme/theme';
import { T } from './kit';

/** Barras agrupadas (ej. ingresos vs. gastos por mes). */
export function GroupedBars({
  labels, series, height = 150,
}: {
  labels: string[]; series: { color: string; values: number[]; name: string }[]; height?: number;
}) {
  const t = useTheme();
  const [width, setWidth] = React.useState(0);
  const max = Math.max(1, ...series.flatMap((s) => s.values));
  const n = labels.length;
  const groupW = n ? width / n : 0;
  const barW = Math.max(4, Math.min(16, (groupW - 14) / series.length));
  const chartH = height - 22;
  return (
    <View onLayout={(e) => setWidth(e.nativeEvent.layout.width)} style={{ height }}>
      {width > 0 && (
        <Svg width={width} height={chartH}>
          {[0.25, 0.5, 0.75, 1].map((p) => (
            <Line key={p} x1={0} x2={width} y1={chartH - chartH * p * 0.92} y2={chartH - chartH * p * 0.92} stroke={t.c.border} strokeWidth={1} />
          ))}
          {labels.map((_, i) => {
            const gx = i * groupW + (groupW - barW * series.length - 4 * (series.length - 1)) / 2;
            return (
              <G key={i}>
                {series.map((s, j) => {
                  const v = s.values[i] ?? 0;
                  const h = v > 0 ? Math.max(3, (v / max) * chartH * 0.92) : 0;
                  return <Rect key={j} x={gx + j * (barW + 4)} y={chartH - h} width={barW} height={h} rx={Math.min(5, barW / 2)} fill={s.color} />;
                })}
              </G>
            );
          })}
        </Svg>
      )}
      <View style={{ flexDirection: 'row', marginTop: 6 }}>
        {labels.map((l, i) => (
          <T key={i} variant="small" muted align="center" style={{ width: groupW || undefined, flex: groupW ? undefined : 1 }}>{l}</T>
        ))}
      </View>
    </View>
  );
}

/** Barras simples (ej. tareas completadas por día). */
export function SimpleBars({ values, labels, color, height = 110 }: { values: number[]; labels: string[]; color?: string; height?: number }) {
  const t = useTheme();
  const c = color ?? t.accent.base;
  return (
    <GroupedBars
      labels={labels}
      height={height}
      series={[{ name: 'v', color: c, values }]}
    />
  );
}

function arcPath(cx: number, cy: number, r: number, start: number, end: number): string {
  const s = { x: cx + r * Math.cos(start), y: cy + r * Math.sin(start) };
  const e = { x: cx + r * Math.cos(end), y: cy + r * Math.sin(end) };
  const large = end - start > Math.PI ? 1 : 0;
  return `M ${s.x} ${s.y} A ${r} ${r} 0 ${large} 1 ${e.x} ${e.y}`;
}

/** Gráfico de anillo por categorías. */
export function Donut({ data, size = 150, stroke = 18, children }: { data: { value: number; color: string }[]; size?: number; stroke?: number; children?: React.ReactNode }) {
  const t = useTheme();
  const total = data.reduce((s, d) => s + d.value, 0);
  const r = (size - stroke) / 2;
  const cx = size / 2;
  let angle = -Math.PI / 2;
  const gap = data.length > 1 ? 0.04 : 0;
  return (
    <View style={{ width: size, height: size, alignItems: 'center', justifyContent: 'center' }}>
      <Svg width={size} height={size} style={{ position: 'absolute' }}>
        <Circle cx={cx} cy={cx} r={r} stroke={t.c.surface3} strokeWidth={stroke} fill="none" />
        {total > 0 && data.map((d, i) => {
          const sweep = (d.value / total) * Math.PI * 2;
          const start = angle + gap / 2;
          const end = angle + sweep - gap / 2;
          angle += sweep;
          if (sweep >= Math.PI * 2 - 0.001) return <Circle key={i} cx={cx} cy={cx} r={r} stroke={d.color} strokeWidth={stroke} fill="none" />;
          if (end <= start) return null;
          return <Path key={i} d={arcPath(cx, cx, r, start, end)} stroke={d.color} strokeWidth={stroke} fill="none" strokeLinecap="round" />;
        })}
      </Svg>
      {children}
    </View>
  );
}

export function Legend({ items }: { items: { color: string; label: string }[] }) {
  return (
    <View style={{ flexDirection: 'row', gap: 16, flexWrap: 'wrap' }}>
      {items.map((i) => (
        <View key={i.label} style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
          <View style={{ width: 10, height: 10, borderRadius: 3, backgroundColor: i.color }} />
          <T variant="small" secondary>{i.label}</T>
        </View>
      ))}
    </View>
  );
}


// ---------------- Líneas ----------------

export interface LinePoint { date: string; value: number; label?: string }

/**
 * Gráfico de líneas con área, mínimo y máximo marcados y punto seleccionable al tocar.
 * `format` da formato al valor (ej. pesos). Los puntos van en orden cronológico.
 */
export function LineChart({
  points, color, height = 170, format, axisLabels = 4, selectedIndex, onSelect, hideAxis,
}: {
  points: LinePoint[]; color?: string; height?: number; format?: (v: number) => string; axisLabels?: number;
  selectedIndex?: number | null; onSelect?: (i: number | null) => void; hideAxis?: boolean;
}) {
  const t = useTheme();
  const c = color ?? t.accent.base;
  const [width, setWidth] = React.useState(0);
  const [internalSel, setInternalSel] = React.useState<number | null>(null);
  const sel = selectedIndex === undefined ? internalSel : selectedIndex;
  const setSel = (i: number | null) => { setInternalSel(i); onSelect?.(i); };
  const fmt = format ?? ((v: number) => String(Math.round(v)));
  const padTop = hideAxis ? 4 : 30;
  const padBottom = hideAxis ? 4 : 24;
  const chartH = height - padBottom;
  const n = points.length;
  const vals = points.map((p) => p.value);
  const max = n ? Math.max(...vals) : 1;
  const min = n ? Math.min(...vals) : 0;
  const span = max - min || Math.max(1, Math.abs(max) * 0.02);
  const lo = min - span * 0.12;
  const hi = max + span * 0.12;
  const x = (i: number) => (n <= 1 ? width / 2 : (i / (n - 1)) * (width - 2) + 1);
  const y = (v: number) => padTop + (1 - (v - lo) / (hi - lo)) * (chartH - padTop);
  const pathD = n ? points.map((p, i) => `${i ? 'L' : 'M'} ${x(i).toFixed(1)} ${y(p.value).toFixed(1)}`).join(' ') : '';
  const areaD = n ? `${pathD} L ${x(n - 1).toFixed(1)} ${chartH} L ${x(0).toFixed(1)} ${chartH} Z` : '';
  const iMax = vals.indexOf(max);
  const iMin = vals.indexOf(min);
  const gid = React.useMemo(() => `lc${Math.random().toString(36).slice(2, 7)}`, []);

  const pick = (locationX: number) => {
    if (!n || !width) return;
    const i = Math.max(0, Math.min(n - 1, Math.round((locationX / width) * (n - 1))));
    setSel(i);
  };

  const labelIdx: number[] = [];
  if (n > 1 && !hideAxis) {
    const k = Math.max(2, Math.min(axisLabels, n));
    for (let j = 0; j < k; j++) labelIdx.push(Math.round((j / (k - 1)) * (n - 1)));
  }
  const dayLabel = (d: string) => `${Number(d.slice(8, 10))}/${Number(d.slice(5, 7))}`;

  return (
    <View
      onLayout={(e) => setWidth(e.nativeEvent.layout.width)}
      style={{ height }}
      onTouchStart={(e) => pick(e.nativeEvent.locationX)}
      onTouchMove={(e) => pick(e.nativeEvent.locationX)}
      onTouchEnd={() => { /* dejamos el punto marcado */ }}
      accessibilityLabel="Gráfico de líneas"
    >
      {width > 0 && n > 0 && (
        <Svg width={width} height={chartH}>
          <Defs>
            <LinearGradient id={gid} x1="0" y1="0" x2="0" y2="1">
              <Stop offset="0" stopColor={c} stopOpacity={t.dark ? 0.32 : 0.22} />
              <Stop offset="1" stopColor={c} stopOpacity={0} />
            </LinearGradient>
          </Defs>
          {[0.25, 0.5, 0.75].map((p) => (
            <Line key={p} x1={0} x2={width} y1={padTop + (chartH - padTop) * p} y2={padTop + (chartH - padTop) * p} stroke={t.c.border} strokeWidth={1} />
          ))}
          {n > 1 && <Path d={areaD} fill={`url(#${gid})`} />}
          <Path d={pathD} fill="none" stroke={c} strokeWidth={2.5} strokeLinecap="round" strokeLinejoin="round" />
          {n > 2 && iMax !== sel && <Circle cx={x(iMax)} cy={y(max)} r={3.5} fill={t.c.bg} stroke={t.c.success} strokeWidth={2} />}
          {n > 2 && iMin !== sel && <Circle cx={x(iMin)} cy={y(min)} r={3.5} fill={t.c.bg} stroke={t.c.danger} strokeWidth={2} />}
          {sel != null && points[sel] && (
            <G>
              <Line x1={x(sel)} x2={x(sel)} y1={padTop - 4} y2={chartH} stroke={hexToRgba(c, 0.6)} strokeWidth={1} strokeDasharray="3 3" />
              <Circle cx={x(sel)} cy={y(points[sel].value)} r={5.5} fill={c} stroke={t.c.text} strokeWidth={2} />
            </G>
          )}
          {sel == null && n > 0 && <Circle cx={x(n - 1)} cy={y(points[n - 1].value)} r={4} fill={c} stroke={t.c.bg} strokeWidth={2} />}
        </Svg>
      )}
      {width > 0 && n > 0 && !hideAxis && (
        <View pointerEvents="none" style={{ position: 'absolute', top: 0, left: 0, right: 0, flexDirection: 'row', justifyContent: sel != null ? (x(sel) > width * 0.6 ? 'flex-end' : x(sel) < width * 0.4 ? 'flex-start' : 'center') : 'space-between', paddingHorizontal: 2 }}>
          {sel != null && points[sel] ? (
            <View style={{ paddingHorizontal: 10, paddingVertical: 4, borderRadius: 8, backgroundColor: t.c.surface2, borderWidth: 1, borderColor: hexToRgba(c, 0.6) }}>
              <T variant="small">{points[sel].label ?? dayLabel(points[sel].date)} · {fmt(points[sel].value)}</T>
            </View>
          ) : (
            <>
              <T variant="small" color={t.c.danger}>mín {fmt(min)}</T>
              <T variant="small" color={t.c.success}>máx {fmt(max)}</T>
            </>
          )}
        </View>
      )}
      {!hideAxis && (
        <View style={{ position: 'absolute', left: 0, right: 0, bottom: 0, flexDirection: 'row', justifyContent: 'space-between' }}>
          {labelIdx.map((i) => <T key={i} variant="small" muted>{points[i].label ?? dayLabel(points[i].date)}</T>)}
        </View>
      )}
      {n === 0 && <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}><T variant="small" muted>Sin datos todavía</T></View>}
    </View>
  );
}
