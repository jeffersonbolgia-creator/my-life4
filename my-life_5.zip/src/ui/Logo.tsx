import React from 'react';
import Svg, { Defs, LinearGradient, Stop, Rect, Circle, Path } from 'react-native-svg';

/** Trazo de la "M": una sola línea que sube y baja, como un latido. */
export const LOGO_PATH = 'M22 84 L40 36 L55 68 L60 56 L65 68 L80 36 L98 84';

/**
 * Isotipo de MY LIFE: una M dibujada como un latido en violeta sobre negro profundo.
 * `from`/`to` controlan el degradado del trazo (se usan los colores de acento del perfil).
 */
export function LogoMark({ size = 72, from = '#7C3AED', to = '#C4B5FD', plain = false }: { size?: number; from?: string; to?: string; plain?: boolean }) {
  const id = React.useMemo(() => `lg${Math.random().toString(36).slice(2, 8)}`, []);
  return (
    <Svg width={size} height={size} viewBox="0 0 120 120">
      <Defs>
        <LinearGradient id={`${id}s`} x1="0" y1="0" x2="1" y2="0">
          <Stop offset="0" stopColor={from} />
          <Stop offset="1" stopColor={to} />
        </LinearGradient>
        <LinearGradient id={`${id}b`} x1="0" y1="0" x2="1" y2="1">
          <Stop offset="0" stopColor="#15121F" />
          <Stop offset="1" stopColor="#07060B" />
        </LinearGradient>
      </Defs>
      {!plain && (
        <>
          <Rect x="2" y="2" width="116" height="116" rx="30" fill={`url(#${id}b)`} />
          <Rect x="2.75" y="2.75" width="114.5" height="114.5" rx="29.5" fill="none" stroke={from} strokeOpacity={0.55} strokeWidth="1.5" />
        </>
      )}
      <Path d={LOGO_PATH} fill="none" stroke={`url(#${id}s)`} strokeWidth="8.5" strokeLinecap="round" strokeLinejoin="round" />
      <Circle cx="60" cy="56" r="3.2" fill="#FFFFFF" />
    </Svg>
  );
}
